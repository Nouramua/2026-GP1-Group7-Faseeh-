<?php

declare(strict_types=1);

namespace Faseeh\Tests\Support;

use Faseeh\Firebase\AuthGateway;
use Faseeh\Firebase\EmailAlreadyRegistered;
use Faseeh\Firebase\InvalidCredentials;
use Faseeh\Firebase\InvalidResetLink;
use Faseeh\Firebase\InvalidSession;
use Faseeh\Firebase\ProfileStore;
use Faseeh\Firebase\ProfileWriteFailed;

/**
 * TEST DOUBLE ONLY — never used by the application.
 *
 * An in-memory stand-in that imitates the Firebase behaviours the controller
 * depends on (duplicate e-mails, credential checks, session expiry/revocation,
 * single-use reset links), so the backend's own logic can be tested without a
 * Firebase project. Passing these tests says nothing about the real Firebase
 * project; those tests are listed separately in docs/TESTING.md.
 */
final class InMemoryFirebase implements AuthGateway, ProfileStore
{
    /** @var array<string,array{uid:string,email:string,password:string,revokedBefore:int}> by lower-case email */
    public array $accounts = [];
    /** @var array<string,array{uid:string,email:string,createdAt:string}> */
    public array $profiles = [];
    /** @var array<string,array{uid:string,expires:int,issued:int}> */
    private array $sessions = [];
    /** @var array<string,array{email:string,used:bool,expires:int}> */
    public array $resetCodes = [];
    /** @var list<string> */
    public array $sentResetEmails = [];
    public int $now;
    public bool $failProfileWrites = false;
    public bool $failAccountDeletes = false;

    public function __construct()
    {
        $this->now = 1_800_000_000;
    }

    public function createAccount(string $email, string $password): string
    {
        $k = strtolower($email);
        if (isset($this->accounts[$k])) {
            throw new EmailAlreadyRegistered();
        }
        $uid = 'uid_' . substr(md5($k), 0, 10);
        $this->accounts[$k] = ['uid' => $uid, 'email' => $email, 'password' => password_hash($password, PASSWORD_DEFAULT), 'revokedBefore' => 0];
        return $uid;
    }

    public function deleteAccount(string $uid): void
    {
        if ($this->failAccountDeletes) {
            throw new \RuntimeException('simulated outage');
        }
        foreach ($this->accounts as $k => $a) {
            if ($a['uid'] === $uid) {
                unset($this->accounts[$k]);
            }
        }
    }

    public function signIn(string $email, string $password): string
    {
        $a = $this->accounts[strtolower($email)] ?? null;
        if ($a === null || !password_verify($password, $a['password'])) {
            throw new InvalidCredentials();
        }
        return 'idtoken:' . $a['uid'];
    }

    public function startSession(string $idToken, int $ttlSeconds): string
    {
        $this->now++; // each new sign-in happens after any earlier revocation
        $cookie = 'session_' . bin2hex(random_bytes(8));
        $this->sessions[$cookie] = ['uid' => substr($idToken, 8), 'expires' => $this->now + $ttlSeconds, 'issued' => $this->now];
        return $cookie;
    }

    public function verifySession(string $sessionCookie): array
    {
        $s = $this->sessions[$sessionCookie] ?? null;
        if ($s === null || $s['expires'] <= $this->now) {
            throw new InvalidSession();
        }
        $acct = $this->byUid($s['uid']);
        if ($acct === null || $s['issued'] < $acct['revokedBefore']) {
            throw new InvalidSession();
        }
        return ['uid' => $acct['uid'], 'email' => $acct['email']];
    }

    public function endSessions(string $uid): void
    {
        foreach ($this->accounts as $k => $a) {
            if ($a['uid'] === $uid) {
                $this->accounts[$k]['revokedBefore'] = $this->now + 1;
            }
        }
    }

    public function isEmailRegistered(string $email): bool
    {
        return isset($this->accounts[strtolower($email)]);
    }

    public function sendPasswordResetEmail(string $email): void
    {
        $this->sentResetEmails[] = $email;
        $this->resetCodes['oob_' . count($this->resetCodes)] = ['email' => strtolower($email), 'used' => false, 'expires' => $this->now + 3600];
    }

    public function verifyPasswordResetLink(string $oobCode): string
    {
        $c = $this->resetCodes[$oobCode] ?? null;
        if ($c === null || $c['used'] || $c['expires'] <= $this->now) {
            throw new InvalidResetLink();
        }
        return $c['email'];
    }

    public function updatePassword(string $oobCode, string $newPassword): void
    {
        $email = $this->verifyPasswordResetLink($oobCode);
        $this->resetCodes[$oobCode]['used'] = true;
        $this->accounts[$email]['password'] = password_hash($newPassword, PASSWORD_DEFAULT);
        $this->accounts[$email]['revokedBefore'] = $this->now + 1; // like invalidatePreviousSessions
    }

    public function changeEmail(string $uid, string $newEmail): void
    {
        $k = strtolower($newEmail);
        if (isset($this->accounts[$k]) && $this->accounts[$k]['uid'] !== $uid) {
            throw new EmailAlreadyRegistered();
        }
        foreach ($this->accounts as $old => $a) {
            if ($a['uid'] === $uid) {
                unset($this->accounts[$old]);
                $a['email'] = $newEmail;
                $this->accounts[$k] = $a;
            }
        }
    }

    public function createProfile(string $uid, string $email, ?string $createdAt = null): void
    {
        if ($this->failProfileWrites) {
            throw new ProfileWriteFailed('simulated outage');
        }
        $this->profiles[$uid] = ['uid' => $uid, 'email' => $email, 'createdAt' => $createdAt ?? gmdate('c', $this->now)];
    }

    public function deleteProfile(string $uid): void
    {
        if ($this->failProfileWrites) {
            throw new ProfileWriteFailed('simulated outage');
        }
        unset($this->profiles[$uid]);
    }

    public function getProfile(string $uid): ?array
    {
        $p = $this->profiles[$uid] ?? null;
        return $p === null ? null : ['email' => $p['email'], 'createdAt' => $p['createdAt']];
    }

    public function updateEmail(string $uid, string $email): void
    {
        if ($this->failProfileWrites) {
            throw new ProfileWriteFailed('simulated outage');
        }
        if (isset($this->profiles[$uid])) {
            $this->profiles[$uid]['email'] = $email;
        }
    }

    /** @return array{uid:string,email:string,password:string,revokedBefore:int}|null */
    private function byUid(string $uid): ?array
    {
        foreach ($this->accounts as $a) {
            if ($a['uid'] === $uid) {
                return $a;
            }
        }
        return null;
    }
}
