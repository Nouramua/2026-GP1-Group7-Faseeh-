<?php

declare(strict_types=1);

/**
 * TEST-ONLY entry point for browser tests of the interface.
 *
 * Runs the real PHP backend (router, controller, validation, cookies) but with
 * Firebase replaced by the InMemoryFirebase TEST DOUBLE, whose state is kept in
 * a file between requests. It is never used by the application and proves
 * nothing about the real Firebase project.
 *
 *   FASEEH_UI_TEST_STATE=/tmp/state.bin php -S 127.0.0.1:8080 tests/Support/ui-test-server.php
 */

use Faseeh\App;
use Faseeh\Config;
use Faseeh\Http\Request;
use Faseeh\Tests\Support\InMemoryFirebase;

require dirname(__DIR__, 2) . '/vendor/autoload.php';

$stateFile = getenv('FASEEH_UI_TEST_STATE') ?: sys_get_temp_dir() . '/faseeh-ui-test.state';
$fh = fopen($stateFile, 'c+');
flock($fh, LOCK_EX);
$raw = stream_get_contents($fh);
$fb = $raw ? unserialize($raw) : new InMemoryFirebase();

$config = new Config('development', 'http://localhost:5173', 'ui-test', null, '(default)', 'users', 3600, 'faseeh_session', null, null, null);
(new App($config, $fb, $fb))->handle(Request::fromGlobals())->send();

ftruncate($fh, 0);
rewind($fh);
fwrite($fh, serialize($fb));
flock($fh, LOCK_UN);
fclose($fh);
