<?php

declare(strict_types=1);

namespace Faseeh\Tests\Emulator;

use Faseeh\App;
use Faseeh\Config;
use Faseeh\Http\Request;
use Faseeh\Http\Response;
use PHPUnit\Framework\TestCase;

/**
 * Runs the real backend (Admin SDK gateway + Firestore REST profile store)
 * against the Firebase Emulator Suite. Skipped unless both emulator hosts are
 * set, e.g.
 *
 *   FIREBASE_AUTH_EMULATOR_HOST=127.0.0.1:9099 FIRESTORE_EMULATOR_HOST=127.0.0.1:8085 \
 *   FIREBASE_PROJECT_ID=demo-faseeh vendor/bin/phpunit --testsuite emulator
 *
 * Results from this suite are labelled "emulator" — they are not tests of the
 * team's real Firebase project.
 */
final class FirebaseEmulatorTest extends TestCase
{
    private App $app;
    private string $cookie = '';
    private string $project;

    protected function setUp(): void
    {
        $auth = getenv('FIREBASE_AUTH_EMULATOR_HOST') ?: '';
        $fs = getenv('FIRESTORE_EMULATOR_HOST') ?: '';
        if ($auth === '' || $fs === '') {
            self::markTestSkipped('Firebase emulators not configured.');
        }
        $this->project = getenv('FIREBASE_PROJECT_ID') ?: 'demo-faseeh';
        $config = new Config('development', 'http://localhost:5173', $this->project, null, '(default)', 'users', 600, 'faseeh_session', $auth, $fs, null);
        $this->app = App::create($config);
    }

    /** @param array<string,mixed> $body */
    private function call(string $method, string $path, array $body = []): Response
    {
        $cookies = $this->cookie !== '' ? ['faseeh_session' => $this->cookie] : [];
        $res = $this->app->handle(new Request($method, $path, $body, $cookies, ['content-type' => 'application/json']));
        foreach ($res->cookies as $c) {
            if (preg_match('/^faseeh_session=([^;]*)/', $c, $m)) {
                $this->cookie = rawurldecode($m[1]);
            }
        }
        return $res;
    }

    private function profile(string $uid): ?array
    {
        $host = getenv('FIRESTORE_EMULATOR_HOST');
        $url = "http://{$host}/v1/projects/{$this->project}/databases/(default)/documents/users/{$uid}";
        $ctx = stream_context_create(['http' => ['header' => "Authorization: Bearer owner\r\n", 'ignore_errors' => true]]);
        $json = json_decode((string) file_get_contents($url, false, $ctx), true);
        return isset($json['fields']) ? $json['fields'] : null;
    }

    private function oobCodeFor(string $email): ?string
    {
        $host = getenv('FIREBASE_AUTH_EMULATOR_HOST');
        $json = json_decode((string) file_get_contents("http://{$host}/emulator/v1/projects/{$this->project}/oobCodes"), true);
        $codes = array_values(array_filter($json['oobCodes'] ?? [], fn ($c) => strcasecmp($c['email'], $email) === 0 && $c['requestType'] === 'PASSWORD_RESET'));
        return $codes ? end($codes)['oobCode'] : null;
    }

    public function testFullAuthenticationCycle(): void
    {
        $email = 'e2e' . bin2hex(random_bytes(4)) . '@example.com';
        $pw = 'Faseeh#2026';

        // PBI 1: register → account + Firestore profile + session
        $res = $this->call('POST', '/api/auth/register', ['email' => $email, 'password' => $pw, 'confirm' => $pw]);
        self::assertSame(201, $res->status, json_encode($res->json, JSON_UNESCAPED_UNICODE));
        $uid = $res->json['user']['uid'];
        $profile = $this->profile($uid);
        self::assertSame($email, $profile['email']['stringValue'] ?? null);
        self::assertSame($uid, $this->call('GET', '/api/auth/session')->json['user']['uid']);

        // PBI 1 AC5: duplicate
        $old = $this->cookie;
        $this->cookie = '';
        self::assertSame(409, $this->call('POST', '/api/auth/register', ['email' => $email, 'password' => $pw, 'confirm' => $pw])->status);

        // PBI 3: logout ends the session; replaying the old cookie fails
        $this->cookie = $old;
        self::assertSame(200, $this->call('POST', '/api/auth/logout')->status);
        $this->cookie = $old;
        self::assertNull($this->call('GET', '/api/auth/session')->json['user']);

        // PBI 2: wrong password vs unknown e-mail → identical error; right password → session
        $this->cookie = '';
        sleep(1); // Firebase compares revocation times in whole seconds
        $a = $this->call('POST', '/api/auth/login', ['email' => $email, 'password' => 'Wrong#2026']);
        $b = $this->call('POST', '/api/auth/login', ['email' => 'nobody' . $email, 'password' => 'Wrong#2026']);
        self::assertSame(401, $a->status);
        self::assertSame($a->json, $b->json);
        self::assertSame(200, $this->call('POST', '/api/auth/login', ['email' => $email, 'password' => $pw])->status);

        // PBI 16: unregistered vs registered, then reset with the emailed code
        self::assertSame(404, $this->call('POST', '/api/auth/password-reset/request', ['email' => 'nobody' . $email])->status);
        self::assertSame(200, $this->call('POST', '/api/auth/password-reset/request', ['email' => $email])->status);
        $code = $this->oobCodeFor($email);
        self::assertNotNull($code);
        self::assertSame(strtolower($email), strtolower($this->call('POST', '/api/auth/password-reset/verify', ['oobCode' => $code])->json['email']));
        self::assertSame(200, $this->call('POST', '/api/auth/password-reset/confirm', ['oobCode' => $code, 'password' => 'New#Pass2026', 'confirm' => 'New#Pass2026'])->status);
        self::assertSame(400, $this->call('POST', '/api/auth/password-reset/verify', ['oobCode' => $code])->status, 'link cannot be reused');
        $this->cookie = '';
        self::assertSame(401, $this->call('POST', '/api/auth/login', ['email' => $email, 'password' => $pw])->status);
        self::assertSame(200, $this->call('POST', '/api/auth/login', ['email' => $email, 'password' => 'New#Pass2026'])->status);
    }
}
