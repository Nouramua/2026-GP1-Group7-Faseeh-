<?php

declare(strict_types=1);

namespace Faseeh\Tests\Unit;

use Faseeh\App;
use Faseeh\Config;
use Faseeh\Http\Request;
use Faseeh\Http\Response;
use Faseeh\Tests\Support\InMemoryFirebase;
use PHPUnit\Framework\TestCase;

/**
 * Backlog items 30 (Edit Profile) and 31 (Delete Account), docs/BACKLOG_UPDATES.md,
 * exercised through the real router and controllers with the Firebase TEST DOUBLE.
 */
final class AccountFlowTest extends TestCase
{
    private const PW = 'Faseeh#2026';
    private InMemoryFirebase $fb;
    private App $app;
    private string $cookie = '';

    protected function setUp(): void
    {
        $this->fb = new InMemoryFirebase();
        $config = new Config('development', 'http://localhost:5173', 'test-project', null, '(default)', 'users', 3600, 'faseeh_session', null, null, null);
        $this->app = new App($config, $this->fb, $this->fb);
    }

    /** @param array<string,mixed> $body */
    private function call(string $method, string $path, array $body = []): Response
    {
        $cookies = $this->cookie !== '' ? ['faseeh_session' => $this->cookie] : [];
        $res = $this->app->handle(new Request($method, $path, $body, $cookies, ['content-type' => 'application/json', 'host' => 'localhost:5173']));
        foreach ($res->cookies as $c) {
            if (preg_match('/^faseeh_session=([^;]*)/', $c, $m)) {
                $this->cookie = rawurldecode($m[1]);
            }
        }
        return $res;
    }

    private function register(string $email = 'reader@example.com'): string
    {
        $res = $this->call('POST', '/api/auth/register', ['email' => $email, 'password' => self::PW, 'confirm' => self::PW]);
        self::assertSame(201, $res->status);
        return $res->json['user']['uid'];
    }

    // ── access restriction (PBI 30 AC1, PBI 31 AC1; NFR 2 AC1) ──────────
    public function testAccountEndpointsRequireASession(): void
    {
        self::assertSame(401, $this->call('GET', '/api/account')->status);
        self::assertSame(401, $this->call('POST', '/api/account/email', ['newEmail' => 'x@example.com', 'currentPassword' => self::PW])->status);
        self::assertSame(401, $this->call('POST', '/api/account/delete', ['currentPassword' => self::PW])->status);
    }

    public function testPbi30Ac1ProfileShowsTheSignedInAccountOnly(): void
    {
        $this->register('other@example.com');
        $this->call('POST', '/api/auth/logout');
        $uid = $this->register();
        $res = $this->call('GET', '/api/account');
        self::assertSame(200, $res->status);
        self::assertSame('reader@example.com', $res->json['profile']['email']);
        self::assertSame($this->fb->profiles[$uid]['createdAt'], $res->json['profile']['createdAt']);
    }

    // ── PBI 30 Edit Profile ───────────────────────────────────────────
    public function testPbi30Ac2Ac3ValidationAndCurrentPasswordAreRequired(): void
    {
        $this->register();
        $r = $this->call('POST', '/api/account/email', ['newEmail' => 'bad', 'currentPassword' => '']);
        self::assertSame(['newEmail', 'currentPassword'], array_keys($r->json['fields']));
        $same = $this->call('POST', '/api/account/email', ['newEmail' => 'READER@example.com', 'currentPassword' => self::PW]);
        self::assertArrayHasKey('newEmail', $same->json['fields']);
        $wrong = $this->call('POST', '/api/account/email', ['newEmail' => 'new@example.com', 'currentPassword' => 'Wrong#2026']);
        self::assertSame(400, $wrong->status);
        self::assertArrayHasKey('currentPassword', $wrong->json['fields']);
        self::assertArrayHasKey('reader@example.com', $this->fb->accounts, 'nothing changed');
    }

    public function testPbi30Ac4EmailOfAnotherAccountIsRejected(): void
    {
        $this->register('taken@example.com');
        $this->call('POST', '/api/auth/logout');
        $this->register();
        $r = $this->call('POST', '/api/account/email', ['newEmail' => 'taken@example.com', 'currentPassword' => self::PW]);
        self::assertSame(409, $r->status);
        self::assertArrayHasKey('newEmail', $r->json['fields']);
    }

    public function testPbi30Ac5ChangeUpdatesAccountProfileAndSignIn(): void
    {
        $uid = $this->register();
        $r = $this->call('POST', '/api/account/email', ['newEmail' => 'new@example.com', 'currentPassword' => self::PW]);
        self::assertSame(200, $r->status);
        self::assertSame('new@example.com', $r->json['user']['email']);
        self::assertSame('new@example.com', $this->fb->profiles[$uid]['email'], 'Firestore profile updated');
        self::assertSame('new@example.com', $this->call('GET', '/api/auth/session')->json['user']['email'], 'session reflects the change');
        $this->call('POST', '/api/auth/logout');
        self::assertSame(401, $this->call('POST', '/api/auth/login', ['email' => 'reader@example.com', 'password' => self::PW])->status);
        self::assertSame(200, $this->call('POST', '/api/auth/login', ['email' => 'new@example.com', 'password' => self::PW])->status);
    }

    public function testPbi30Ac6FailureLeavesAccountAndProfileUnchanged(): void
    {
        $uid = $this->register();
        $this->fb->failProfileWrites = true;
        $r = $this->call('POST', '/api/account/email', ['newEmail' => 'new@example.com', 'currentPassword' => self::PW]);
        self::assertSame(502, $r->status);
        self::assertArrayHasKey('reader@example.com', $this->fb->accounts, 'account e-mail restored');
        self::assertSame('reader@example.com', $this->fb->profiles[$uid]['email']);
    }

    // ── PBI 31 Delete Account ─────────────────────────────────────────
    public function testPbi31Ac2Ac3PasswordIsRequiredAndWrongPasswordDeletesNothing(): void
    {
        $uid = $this->register();
        self::assertSame(400, $this->call('POST', '/api/account/delete', ['currentPassword' => ''])->status);
        $r = $this->call('POST', '/api/account/delete', ['currentPassword' => 'Wrong#2026']);
        self::assertArrayHasKey('currentPassword', $r->json['fields']);
        self::assertCount(1, $this->fb->accounts);
        self::assertArrayHasKey($uid, $this->fb->profiles);
    }

    public function testPbi31Ac4Ac5DeletionRemovesEverythingAndEndsTheSession(): void
    {
        $this->register('keep@example.com');
        $this->call('POST', '/api/auth/logout');
        $uid = $this->register();
        $old = $this->cookie;
        $r = $this->call('POST', '/api/account/delete', ['currentPassword' => self::PW]);
        self::assertSame(200, $r->status);
        self::assertSame('', $this->cookie, 'cookie cleared');
        self::assertArrayNotHasKey('reader@example.com', $this->fb->accounts);
        self::assertArrayNotHasKey($uid, $this->fb->profiles);
        self::assertArrayHasKey('keep@example.com', $this->fb->accounts, 'other accounts untouched');
        // the old session cannot be replayed, and the credentials no longer work
        $this->cookie = $old;
        self::assertNull($this->call('GET', '/api/auth/session')->json['user']);
        $this->cookie = '';
        self::assertSame(401, $this->call('POST', '/api/auth/login', ['email' => 'reader@example.com', 'password' => self::PW])->status);
        // the e-mail can be registered again afterwards
        self::assertSame(201, $this->call('POST', '/api/auth/register', ['email' => 'reader@example.com', 'password' => self::PW, 'confirm' => self::PW])->status);
    }

    public function testPbi31Ac6FailureDeletesNothing(): void
    {
        $uid = $this->register();
        $createdAt = $this->fb->profiles[$uid]['createdAt'];
        $this->fb->failAccountDeletes = true;
        $r = $this->call('POST', '/api/account/delete', ['currentPassword' => self::PW]);
        self::assertSame(502, $r->status);
        self::assertArrayHasKey('reader@example.com', $this->fb->accounts);
        self::assertSame($createdAt, $this->fb->profiles[$uid]['createdAt'] ?? null, 'profile restored unchanged');
        self::assertSame($uid, $this->call('GET', '/api/auth/session')->json['user']['uid'], 'still signed in');
    }
}
