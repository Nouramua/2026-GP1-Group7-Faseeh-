<?php

declare(strict_types=1);

namespace Faseeh\Tests\Unit;

use Faseeh\Validation\AuthValidator as V;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

/** PBI 1 AC2–AC4 and PBI 16 AC2/AC5/AC6 (pp. 25, 34). */
final class AuthValidatorTest extends TestCase
{
    public function testEmailRules(): void
    {
        self::assertNull(V::email('reader@example.com'));
        self::assertNotNull(V::email(''));
        self::assertNotNull(V::email('   '));
        self::assertNotNull(V::email('reader@'));
        self::assertNotNull(V::email('reader example.com'));
        self::assertNotNull(V::email('reader@example'));
    }

    /** @return array<string,array{string,bool}> */
    public static function passwords(): array
    {
        return [
            'meets policy' => ['Faseeh#2026', true],
            'seven chars' => ['Fa#2026', false],
            'no uppercase' => ['faseeh#2026', false],
            'no lowercase' => ['FASEEH#2026', false],
            'no digit' => ['Faseeh#abcd', false],
            'no special' => ['Faseeh2026', false],
            'empty' => ['', false],
        ];
    }

    #[DataProvider('passwords')]
    public function testPasswordPolicy(string $pw, bool $valid): void
    {
        self::assertSame($valid, V::password($pw) === null);
    }

    public function testConfirmation(): void
    {
        self::assertNull(V::confirm('Faseeh#2026', 'Faseeh#2026'));
        self::assertNotNull(V::confirm('Faseeh#2026', 'Faseeh#2025'));
        self::assertNotNull(V::confirm('Faseeh#2026', ''));
    }
}
