<?php

declare(strict_types=1);

namespace Faseeh\Tests\Unit;

use Faseeh\App;
use Faseeh\Config;
use Faseeh\Http\Request;
use Faseeh\Http\Response;
use Faseeh\Tests\Support\InMemoryFirebase;
use PHPUnit\Framework\TestCase;

/**
 * Backend logic for Sprint 2 authentication, exercised through the real router,
 * controller, validation and cookie handling, with Firebase replaced by the
 * in-memory TEST DOUBLE. Each test names the acceptance criterion it checks.
 */
final class AuthFlowTest extends TestCase
{
    private const PW = 'Faseeh#2026';
    private InMemoryFirebase $fb;
    private App $app;
    private string $cookie = '';

    protected function setUp(): void
    {
        $this->fb = new InMemoryFirebase();
        $config = new Config(
            appEnv: 'development',
            appUrl: 'http://localhost:5173',
            firebaseProjectId: 'test-project',
            firebaseCredentialsPath: null,
            firestoreDatabaseId: '(default)',
            usersCollection: 'users',
            sessionTtlSeconds: 3600,
            sessionCookieName: 'faseeh_session',
            authEmulatorHost: null,
            firestoreEmulatorHost: null,
            frontendDist: null,
        );
        $this->app = new App($config, $this->fb, $this->fb);
    }

    /** @param array<string,mixed> $body */
    private function call(string $method, string $path, array $body = [], array $headers = []): Response
    {
        $headers += ['content-type' => 'application/json', 'host' => 'localhost:5173'];
        $cookies = $this->cookie !== '' ? ['faseeh_session' => $this->cookie] : [];
        $res = $this->app->handle(new Request($method, $path, $body, $cookies, $headers));
        foreach ($res->cookies as $c) {
            if (preg_match('/^faseeh_session=([^;]*)/', $c, $m)) {
                $this->cookie = rawurldecode($m[1]);
            }
        }
        return $res;
    }

    private function register(string $email = 'reader@example.com'): Response
    {
        return $this->call('POST', '/api/auth/register', ['email' => $email, 'password' => self::PW, 'confirm' => self::PW]);
    }

    // ── PBI 1 Create an Account ─────────────────────────────────────────
    public function testPbi1Ac2IncompleteFieldsAreRejectedAndNoAccountIsCreated(): void
    {
        $res = $this->call('POST', '/api/auth/register', ['email' => '', 'password' => '', 'confirm' => '']);
        self::assertSame(400, $res->status);
        self::assertArrayHasKey('email', $res->json['fields']);
        self::assertArrayHasKey('password', $res->json['fields']);
        self::assertArrayHasKey('confirm', $res->json['fields']);
        self::assertSame([], $this->fb->accounts);
    }

    public function testPbi1Ac3InvalidEmailOrMismatchIdentifiesTheError(): void
    {
        $res = $this->call('POST', '/api/auth/register', ['email' => 'bad-email', 'password' => self::PW, 'confirm' => self::PW]);
        self::assertSame(['email'], array_keys($res->json['fields']));
        $res = $this->call('POST', '/api/auth/register', ['email' => 'a@example.com', 'password' => self::PW, 'confirm' => 'Faseeh#2025']);
        self::assertSame(['confirm'], array_keys($res->json['fields']));
        self::assertSame([], $this->fb->accounts);
    }

    public function testPbi1Ac4PasswordPolicyIsEnforcedOnTheServer(): void
    {
        $res = $this->call('POST', '/api/auth/register', ['email' => 'a@example.com', 'password' => 'weakpass', 'confirm' => 'weakpass']);
        self::assertSame(400, $res->status);
        self::assertStringContainsString('لا تستوفي الشروط', $res->json['fields']['password']);
        self::assertSame([], $this->fb->accounts);
    }

    public function testPbi1Ac5DuplicateEmailCannotCreateASecondAccount(): void
    {
        $this->register();
        $this->cookie = '';
        $res = $this->register('READER@example.com');
        self::assertSame(409, $res->status);
        self::assertSame('email_in_use', $res->json['error']);
        self::assertCount(1, $this->fb->accounts);
    }

    public function testPbi1Ac6ValidRegistrationCreatesOneAccountProfileAndSession(): void
    {
        $res = $this->register();
        self::assertSame(201, $res->status);
        self::assertSame('reader@example.com', $res->json['user']['email']);
        self::assertCount(1, $this->fb->accounts);
        // C2b: "Create user profile in Cloud Firestore", keyed by the Firebase UID
        $uid = $res->json['user']['uid'];
        self::assertSame('reader@example.com', $this->fb->profiles[$uid]['email']);
        // C2b/C2a: "Firebase starts the session"
        self::assertNotSame('', $this->cookie);
        self::assertSame($uid, $this->call('GET', '/api/auth/session')->json['user']['uid']);
    }

    public function testPbi1Ac7FailedProfileCreationReportsFailureAndLeavesNoAccount(): void
    {
        $this->fb->failProfileWrites = true;
        $res = $this->register();
        self::assertSame(502, $res->status);
        self::assertSame([], $this->fb->accounts, 'account rolled back');
        self::assertSame([], $this->fb->profiles);
        self::assertSame('', $this->cookie, 'no session is started');
    }

    public function testNfr2Ac2PasswordsAreNotStoredByFaseeh(): void
    {
        $this->register();
        foreach ($this->fb->profiles as $profile) {
            self::assertSame(['uid', 'email', 'createdAt'], array_keys($profile));
            self::assertNotContains(self::PW, $profile);
        }
    }

    // ── PBI 2 Log In ───────────────────────────────────────────────────
    public function testPbi2Ac2MissingCredentialsShowValidation(): void
    {
        $res = $this->call('POST', '/api/auth/login', ['email' => '', 'password' => '']);
        self::assertSame(400, $res->status);
        self::assertArrayHasKey('email', $res->json['fields']);
        self::assertArrayHasKey('password', $res->json['fields']);
    }

    public function testPbi2Ac3ValidCredentialsEstablishASession(): void
    {
        $this->register();
        $this->call('POST', '/api/auth/logout');
        $res = $this->call('POST', '/api/auth/login', ['email' => 'reader@example.com', 'password' => self::PW]);
        self::assertSame(200, $res->status);
        self::assertSame('reader@example.com', $this->call('GET', '/api/auth/session')->json['user']['email']);
    }

    public function testPbi2Ac4WrongPasswordAndUnknownEmailGiveTheSameGeneralError(): void
    {
        $this->register();
        $this->call('POST', '/api/auth/logout');
        $a = $this->call('POST', '/api/auth/login', ['email' => 'reader@example.com', 'password' => 'Wrong#2026']);
        $b = $this->call('POST', '/api/auth/login', ['email' => 'nobody@example.com', 'password' => 'Wrong#2026']);
        self::assertSame(401, $a->status);
        self::assertSame($a->status, $b->status);
        self::assertSame($a->json, $b->json);
        self::assertSame('البريد الإلكتروني أو كلمة المرور غير صحيحة.', $a->json['message']);
    }

    public function testPbi2Ac5FailedAttemptGrantsNoSession(): void
    {
        $this->register();
        $this->call('POST', '/api/auth/logout');
        $this->call('POST', '/api/auth/login', ['email' => 'reader@example.com', 'password' => 'Wrong#2026']);
        self::assertNull($this->call('GET', '/api/auth/session')->json['user']);
    }

    public function testPbi2Ac6ProtectedAccessWithoutSessionIsRejected(): void
    {
        try {
            $this->app->auth()->requireUser(new Request('GET', '/x', [], [], []));
            self::fail('expected 401');
        } catch (\Faseeh\Http\ApiException $e) {
            self::assertSame(401, $e->status);
        }
    }

    // ── PBI 3 Log Out ──────────────────────────────────────────────────
    public function testPbi3Ac2LogoutInvalidatesTheSessionAndAc3KeepsTheAccount(): void
    {
        $this->register();
        $old = $this->cookie;
        $res = $this->call('POST', '/api/auth/logout');
        self::assertSame(200, $res->status);
        self::assertSame('', $this->cookie, 'cookie cleared');
        // NFR 2 AC1: the old session value is rejected after logout, even if replayed
        $this->cookie = $old;
        self::assertNull($this->call('GET', '/api/auth/session')->json['user']);
        try {
            $this->app->auth()->requireUser(new Request('GET', '/x', [], ['faseeh_session' => $old], []));
            self::fail('expected 401 after logout');
        } catch (\Faseeh\Http\ApiException $e) {
            self::assertSame(401, $e->status);
        }
        self::assertCount(1, $this->fb->accounts, 'account information preserved');
        self::assertCount(1, $this->fb->profiles);
    }

    // ── C2a: session expiry ────────────────────────────────────────────
    public function testC2aExpiredSessionReturnsTheUserToGuest(): void
    {
        $this->register();
        $this->fb->now += 3601;
        $res = $this->call('GET', '/api/auth/session');
        self::assertNull($res->json['user']);
        self::assertTrue($res->json['expired']);
        self::assertSame('', $this->cookie, 'expired cookie removed');
    }

    // ── PBI 16 Recover a Forgotten Password ────────────────────────────
    public function testPbi16Ac2InvalidEmailShowsValidation(): void
    {
        $res = $this->call('POST', '/api/auth/password-reset/request', ['email' => 'not-an-email']);
        self::assertSame(400, $res->status);
        self::assertSame([], $this->fb->sentResetEmails);
    }

    public function testPbi16Ac3RegisteredEmailReceivesAResetLink(): void
    {
        $this->register();
        $res = $this->call('POST', '/api/auth/password-reset/request', ['email' => 'reader@example.com']);
        self::assertSame(200, $res->status);
        self::assertSame(['reader@example.com'], $this->fb->sentResetEmails);
    }

    public function testPbi16Ac4UnregisteredEmailIsToldAndNoEmailIsSent(): void
    {
        $res = $this->call('POST', '/api/auth/password-reset/request', ['email' => 'nobody@example.com']);
        self::assertSame(404, $res->status);
        self::assertSame('لا يوجد حساب مرتبط بهذا البريد الإلكتروني.', $res->json['message']);
        self::assertSame([], $this->fb->sentResetEmails);
    }

    public function testPbi16Ac5Ac6NewPasswordMustMeetPolicyAndMatch(): void
    {
        $this->register();
        $this->call('POST', '/api/auth/password-reset/request', ['email' => 'reader@example.com']);
        $weak = $this->call('POST', '/api/auth/password-reset/confirm', ['oobCode' => 'oob_0', 'password' => 'weak', 'confirm' => 'weak']);
        self::assertSame(400, $weak->status);
        $mismatch = $this->call('POST', '/api/auth/password-reset/confirm', ['oobCode' => 'oob_0', 'password' => 'New#Pass2026', 'confirm' => 'New#Pass2027']);
        self::assertSame(['confirm'], array_keys($mismatch->json['fields']));
        self::assertFalse($this->fb->resetCodes['oob_0']['used'], 'link still unused after rejected attempts');
    }

    public function testPbi16Ac7Ac8ResetChangesPasswordAndLinkCannotBeReused(): void
    {
        $this->register();
        $sessionBefore = $this->cookie;
        $this->call('POST', '/api/auth/password-reset/request', ['email' => 'reader@example.com']);
        self::assertSame('reader@example.com', $this->call('POST', '/api/auth/password-reset/verify', ['oobCode' => 'oob_0'])->json['email']);

        $ok = $this->call('POST', '/api/auth/password-reset/confirm', ['oobCode' => 'oob_0', 'password' => 'New#Pass2026', 'confirm' => 'New#Pass2026']);
        self::assertSame(200, $ok->status);

        // AC7/AC8: the used link no longer works
        self::assertSame('invalid_reset_link', $this->call('POST', '/api/auth/password-reset/verify', ['oobCode' => 'oob_0'])->json['error']);
        self::assertSame(400, $this->call('POST', '/api/auth/password-reset/confirm', ['oobCode' => 'oob_0', 'password' => 'Other#Pass2026', 'confirm' => 'Other#Pass2026'])->status);
        // AC8: new password works, old one does not
        $this->cookie = '';
        self::assertSame(401, $this->call('POST', '/api/auth/login', ['email' => 'reader@example.com', 'password' => self::PW])->status);
        self::assertSame(200, $this->call('POST', '/api/auth/login', ['email' => 'reader@example.com', 'password' => 'New#Pass2026'])->status);
        // sessions opened with the old password were ended
        $this->cookie = $sessionBefore;
        self::assertNull($this->call('GET', '/api/auth/session')->json['user']);
    }

    public function testPbi16Ac7ExpiredOrUnknownLinksAreRejected(): void
    {
        $this->register();
        $this->call('POST', '/api/auth/password-reset/request', ['email' => 'reader@example.com']);
        $this->fb->now += 3601;
        self::assertSame(400, $this->call('POST', '/api/auth/password-reset/verify', ['oobCode' => 'oob_0'])->status);
        self::assertSame(400, $this->call('POST', '/api/auth/password-reset/verify', ['oobCode' => 'made-up'])->status);
    }

    // ── Request guard ──────────────────────────────────────────────────
    public function testCrossSiteRequestsAreRefused(): void
    {
        $form = $this->call('POST', '/api/auth/logout', [], ['content-type' => 'application/x-www-form-urlencoded']);
        self::assertSame(415, $form->status);
        $foreign = $this->call('POST', '/api/auth/login', ['email' => 'a@b.co', 'password' => 'x'], ['origin' => 'https://evil.example']);
        self::assertSame(403, $foreign->status);
    }

    public function testSessionCookieIsHttpOnlyAndSameSite(): void
    {
        $res = $this->register();
        self::assertMatchesRegularExpression('/HttpOnly/', $res->cookies[0]);
        self::assertMatchesRegularExpression('/SameSite=Lax/', $res->cookies[0]);
        self::assertMatchesRegularExpression('/Max-Age=3600/', $res->cookies[0]);
    }
}
