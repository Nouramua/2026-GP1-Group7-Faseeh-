# Release 1 browser tests

`release1.e2e.cjs` runs 110 end-to-end checks in Google Chrome. It drives the real frontend against the **real PHP backend**, which is wired to the **in-memory Firebase test double** (`tests/Support/InMemoryFirebase.php`).

**It never contacts a Firebase project**, and it needs no `backend/.env` or service-account key. The email addresses and passwords in the test are fake fixtures that exist only inside the test double.

## What it covers

| Area | Checks |
|---|---|
| Public pages | No horizontal overflow at 1366×768 |
| Workspace | No input length limit, counter, Clear, validation, demonstration labels, no rating (Release 2) |
| Help («نقطة») | Keyboard (Tab, Enter, Space, Esc), FAQ, new-guidance indicator, first-visit greeting |
| Registration | Validation, Firestore profile creation (in the double), cookie flags |
| Logout | Session revocation, replay of the old cookie |
| Login | Identical error for a wrong password and an unknown email |
| Session expiry | Including expiry while My Account is open |
| Password recovery | Unregistered email, used and invalid links |
| Edit email | Including simulated update failure |
| Delete account | Including simulated deletion failure |
| Security | Spot checks |

`test-double-control.php` changes the test double between steps:
- moves its clock forward (to expire a session);
- switches simulated failures on and off;
- lists reset codes and accounts.

## One-time setup

1. Have Google Chrome installed, and the backend's dependencies installed (`composer install` in `backend/`).
2. Install `playwright-core` in the `website/` folder. It isn't a project dependency; `--no-save` keeps `package.json` unchanged:

   ```bash
   npm install --no-save playwright-core
   ```

## Run (three terminals, starting in the `website/` folder)

**Terminal 1: backend with the Firebase test double, on port 8091**

```bash
cd backend
```

```bash
php -S 127.0.0.1:8091 tests/Support/ui-test-server.php
```

**Terminal 2: frontend pointed at that backend, on port 5175**

Git Bash / macOS / Linux:

```bash
cd frontend
```

```bash
FASEEH_BACKEND_URL=http://127.0.0.1:8091 npx vite --port 5175 --strictPort
```

Windows PowerShell:

```powershell
cd frontend
```

```powershell
$env:FASEEH_BACKEND_URL = "http://127.0.0.1:8091"; npx vite --port 5175 --strictPort
```

**Terminal 3: the checks**

Git Bash / macOS / Linux:

```bash
CHROME_PATH="C:/Program Files/Google/Chrome/Application/chrome.exe" FASEEH_E2E_URL=http://localhost:5175 node backend/tests/Browser/release1.e2e.cjs
```

Windows PowerShell:

```powershell
$env:CHROME_PATH = "C:\Program Files\Google\Chrome\Application\chrome.exe"; $env:FASEEH_E2E_URL = "http://localhost:5175"; node backend/tests/Browser/release1.e2e.cjs
```

On macOS the Chrome path is usually `/Applications/Google Chrome.app/Contents/MacOS/Google Chrome`.

The run ends with `110/110 passed`. Results are written to `faseeh-e2e/e2e-results.json` in the system temp folder; set `FASEEH_E2E_OUT` to change this.

## Notes

- **State reset:** every run starts from an empty test double. The script deletes the double's state file (`faseeh-ui-test.state` in the system temp folder), which the PHP test server and the script both use by default. If you set `FASEEH_UI_TEST_STATE` for the server, set the same value for the script.
- **Playwright elsewhere:** if `playwright-core` is installed somewhere else, point `PLAYWRIGHT_CORE` at its folder.
- **Last result:** 110 of 110 passed (23 Nov 2026).
