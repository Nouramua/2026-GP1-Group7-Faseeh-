// End-to-end browser checks for Faseeh Release 1 (105 checks), against the real PHP
// backend wired to the in-memory Firebase TEST DOUBLE. It never touches the real
// Firebase project. How to run: see backend/tests/Browser/README.md.
const { chromium } = require(process.env.PLAYWRIGHT_CORE || 'playwright-core');
const { execFileSync } = require('child_process');
const fs = require('fs'), path = require('path');
const DIR = __dirname;
const WORK = process.env.FASEEH_E2E_OUT || path.join(require('os').tmpdir(), 'faseeh-e2e');
const STATE = process.env.FASEEH_UI_TEST_STATE || path.join(require('os').tmpdir(), 'faseeh-ui-test.state');
const SHOTS = path.join(WORK, 'shots');
fs.mkdirSync(SHOTS, { recursive: true });
// Start every run from an empty test double: the PHP test server re-creates it when the state file is missing.
try { fs.unlinkSync(STATE); } catch {}
const BASE = process.env.FASEEH_E2E_URL || 'http://localhost:5173';
const tweak = (...a) => execFileSync('php', [path.join(DIR, 'test-double-control.php'), STATE, ...a.map(String)], { encoding: 'utf8' });
const results = [];
let cur = '';
const ok = (name, cond, detail = '') => { results.push({ group: cur, name, pass: !!cond, detail: String(detail ?? '') }); console.log(`${cond ? 'PASS' : 'FAIL'} [${cur}] ${name}${detail ? ' — ' + detail : ''}`); };
const group = (g) => { cur = g; };
// Home page final section («جرّب فصيح على نصّك الآن»): returns its prompt text and button labels.
const finalCta = async (page) => {
  const sec = page.locator('.final-cta');
  await sec.locator('.btn').first().waitFor({ timeout: 5000 });
  return { lede: (await sec.locator('.section-lede').allTextContents()).join(''), buttons: (await sec.locator('.btn').allTextContents()).map((t) => t.trim()) };
};
const isGuestCta = (c) => c.lede.includes('لا تحتاج إلى حساب') && c.buttons.join('|') === 'التجربة كزائر|إنشاء حساب';
const isUserCta = (c) => c.lede === '' && c.buttons.join('|') === 'ابدأ التجربة';
const PW = 'Faseeh#2026', PW2 = 'Faseeh#2027';
const ar = (n) => n.toLocaleString('ar-SA');

(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROME_PATH || undefined });
  const ctx = await browser.newContext({ viewport: { width: 1366, height: 768 }, locale: 'ar' });
  const page = await ctx.newPage();
  const consoleErrors = [];
  page.on('console', (m) => { if (m.type() === 'error' && !/status of (4[0-9][0-9]|502)/.test(m.text())) consoleErrors.push(m.text()); });
  page.on('pageerror', (e) => consoleErrors.push(e.message));
  // mark the first-visit greeting as seen for the main context (tested separately below)
  await page.addInitScript(() => { try { localStorage.setItem('faseeh:assistant-seen', '1'); } catch {} });
  const go = async (p) => { await page.goto(BASE + p); await page.waitForLoadState('networkidle'); };
  const header = () => page.locator('.site-header__account');
  const fill = async (label, v, scope = page) => { await scope.getByLabel(label, { exact: true }).fill(v); };
  const toastText = async () => (await page.locator('.toast, [class*=toast]').allTextContents()).join(' | ');

  // ── Public pages ─────────────────────────────────────────────
  group('Public pages (PBI 7, 10)');
  for (const [p, h] of [['/', null], ['/about', null], ['/workspace', 'مساحة العمل'], ['/login', 'تسجيل الدخول'], ['/register', null], ['/forgot-password', null]]) {
    await go(p);
    const ovf = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    ok(`${p} loads for a guest, no horizontal overflow at 1366×768`, (await page.locator('h1').count()) > 0 && ovf <= 0, `overflow ${ovf}px`);
    if (h) ok(`${p} heading`, (await page.locator('h1').first().textContent()).includes(h));
    await page.screenshot({ path: path.join(SHOTS, `page${p.replace(/\//g, '_') || '_home'}.png`), fullPage: false });
  }
  await go('/');
  const homeText = await page.locator('main').innerText();
  ok('Home explains the four levels and workflow', /المستوى|مستوى/.test(homeText) && homeText.includes('اختر المستوى'));
  ok('Home no longer states a 3,000-character limit', !homeText.includes('٣٬٠٠٠') && !homeText.includes('3,000'));
  ok('Home offers Workspace and account creation', (await page.locator('a[href="/workspace"]').count()) > 0 && (await page.locator('a[href="/register"]').count()) > 0);
  await go('/about');
  ok('About reachable from header and footer', (await page.locator('header a[href="/about"]').count()) > 0 && (await page.locator('footer a[href="/about"]').count()) > 0);

  // ── Workspace: limit removed, counter, clear, validation, no ratings ──
  group('Workspace input (limit removed)');
  await go('/workspace');
  const ta = page.locator('#ws-text');
  const long = ('ذهب الطالب إلى المكتبة ليقرأ كتابًا جديدًا عن تاريخ العلوم العربية. ').repeat(60); // > 3,000 chars
  const n = [...long].length;
  await ta.fill(long);
  await ta.blur();
  const counter = await page.locator('.counter').innerText();
  ok(`Text of ${n} characters is accepted (no limit error)`, n > 3000 && (await page.locator('#ws-text-err').innerText()).trim() === '', `counter "${counter}"`);
  ok('Character counter shows the full length with no maximum', counter.includes(ar(n)) && !counter.includes('/'), counter);
  ok('Text is not truncated', (await ta.inputValue()).length === long.length);
  await page.getByRole('button', { name: 'حلّل المقروئية' }).click();
  await page.locator('.analysis__level').waitFor({ timeout: 15000 });
  ok('Analysis of the long text completes (demonstration)', await page.locator('.analysis__level').isVisible());
  ok('Analysis result carries a demonstration label', /محاكاة|عيّنة/.test(await page.locator('.demo-note').first().innerText()));
  await page.getByRole('button', { name: 'مسح' }).click();
  ok('Clear empties the text and the result', (await ta.inputValue()) === '' && (await page.locator('.analysis__level').count()) === 0);
  ok('Counter returns to zero', (await page.locator('.counter').innerText()).includes(ar(0)));
  await page.getByRole('button', { name: 'حلّل المقروئية' }).click();
  ok('Empty input is rejected with a message', (await page.locator('#ws-text-err').innerText()).includes('اكتب نصًّا'));
  await ta.fill('This is an English text only');
  await page.getByRole('button', { name: 'حلّل المقروئية' }).click();
  ok('Non-Arabic input is rejected with a message', (await page.locator('#ws-text-err').innerText()).includes('العربية فقط'));
  ok('Rejected input stays available for correction', (await ta.inputValue()) === 'This is an English text only');
  // sample → simplify → comparison; verify rating is not offered (Release 2)
  await page.locator('.sample-chip').first().click();
  await page.getByRole('button', { name: 'حلّل المقروئية' }).click();
  await page.locator('.analysis__level').waitFor({ timeout: 15000 });
  const enabled = page.locator('.level-picker input:not([disabled]), [role=radio]:not([aria-disabled=true])');
  const pick = page.locator('.panel--target label, .panel--target [role=radio], .panel--target button').filter({ hasNot: page.locator('[disabled]') });
  const radios = page.locator('.panel--target input[type=radio]:not([disabled])');
  if (await radios.count()) await radios.first().check({ force: true }); else await pick.first().click();
  await page.locator('.panel--target .btn--primary').click();
  await page.locator('.compare').waitFor({ timeout: 15000 });
  ok('Simplification comparison is shown (demonstration)', await page.locator('.compare').isVisible());
  ok('No rating / feedback form is offered (Release 2, story 21)', (await page.locator('form.rating, .rating__stars').count()) === 0);
  ok('Saving is marked "available in Release 2"', (await page.locator('.saved-pill--later').first().innerText()).includes('الإصدار الثاني'));
  await page.screenshot({ path: path.join(SHOTS, 'workspace_compare.png'), fullPage: false });

  // ── Contextual help & keyboard (FSEEH-52, 100, 101, 114, 115) ──
  group('Contextual help (FSEEH-52/100/101/114/115)');
  await go('/workspace');
  await ta.fill('نص تجريبي قصير للتحقق من المساعدة.');
  const btn = page.locator('.assistant__btn');
  ok('Help button present on the page', await btn.isVisible());
  await btn.focus();
  ok('Help button is keyboard-focusable', await btn.evaluate((e) => e === document.activeElement));
  const outline = await btn.evaluate((e) => { const s = getComputedStyle(e); return s.outlineStyle + ' ' + s.outlineWidth; });
  ok('Visible focus indicator on the help button', !/none|0px/.test(outline), outline);
  await page.keyboard.press('Enter');
  ok('Enter opens the panel', await page.locator('.assistant__panel').isVisible());
  ok('Focus moves into the panel when it opens', await page.evaluate(() => !!document.activeElement?.closest('.assistant__panel')));
  await page.keyboard.press('Tab');
  ok('Tab reaches the close button next', await page.evaluate(() => document.activeElement?.classList.contains('assistant__close')));
  await page.keyboard.press('Tab');
  const onQ = await page.evaluate(() => document.activeElement?.classList.contains('assistant__q'));
  ok('Tab reaches the first FAQ question', onQ);
  await page.keyboard.press('Space');
  ok('Space expands the FAQ answer', (await page.locator('.assistant__q').first().getAttribute('aria-expanded')) === 'true' && (await page.locator('.assistant__a').count()) === 1);
  await page.keyboard.press('Enter');
  ok('Enter collapses it again', (await page.locator('.assistant__q').first().getAttribute('aria-expanded')) === 'false');
  await page.keyboard.press('Escape');
  ok('Esc closes the panel', (await page.locator('.assistant__panel').count()) === 0);
  ok('Focus returns to the help button after Esc', await btn.evaluate((e) => e === document.activeElement));
  await btn.click();
  await page.locator('.assistant__close').click();
  ok('Close button closes the panel', (await page.locator('.assistant__panel').count()) === 0);
  await btn.click(); await btn.click();
  ok('Help button toggles the panel closed', (await page.locator('.assistant__panel').count()) === 0);
  ok('Opening/closing help keeps the entered text', (await ta.inputValue()) === 'نص تجريبي قصير للتحقق من المساعدة.');
  ok('Panel is a labelled dialog; button has aria-expanded', (await btn.getAttribute('aria-expanded')) === 'false');
  // One real state change while the panel is closed: emptying the text changes the help topic.
  // (Emptying and immediately retyping could land in one render and correctly show no change.)
  await ta.fill('');
  const nudged = await page.locator('.assistant__nudge').waitFor({ state: 'visible', timeout: 3000 }).then(() => true, () => false);
  ok('New-guidance indicator appears when the state changes while closed', nudged);
  for (const p of ['/', '/about', '/login']) { await go(p); ok(`Help button in the same corner on ${p}`, await page.locator('.assistant__btn').isVisible()); }
  // first-visit greeting in a fresh context
  const fresh = await browser.newContext({ viewport: { width: 1366, height: 768 } });
  const fp = await fresh.newPage();
  await fp.goto(BASE + '/'); await fp.waitForTimeout(4000);
  const greetVisible = await fp.locator('.assistant__intro').isVisible();
  await fp.waitForTimeout(7500);
  ok('First-visit greeting appears and disappears within 11 s', greetVisible && (await fp.locator('.assistant__intro').count()) === 0);
  await fresh.close();

  // ── Registration (FSEEH-6, 77–80) ────────────────────────────
  group('Registration (FSEEH-6)');
  await go('/register');
  await page.locator('form button[type=submit]').click();
  ok('Empty form shows field errors, no account created', (await page.locator('.field__error:visible').count()) >= 2 && !tweak('dump').includes('@'));
  await fill('البريد الإلكتروني', 'bad-email'); await fill('كلمة المرور', 'weak'); await fill('تأكيد كلمة المرور', 'other');
  await page.locator('form button[type=submit]').click();
  const regErrs = (await page.locator('.field__error').allTextContents()).join(' ');
  ok('Invalid email, weak password and mismatch are identified', regErrs.includes('صيغة') && regErrs.includes('الشروط') && regErrs.includes('متطابقتين'), regErrs);
  await fill('البريد الإلكتروني', 'sara.test@example.com'); await fill('كلمة المرور', PW); await fill('تأكيد كلمة المرور', PW);
  const respP = page.waitForResponse((r) => r.url().includes('/api/auth/register'));
  await page.locator('form button[type=submit]').click();
  const regResp = await respP;
  const sc = (await regResp.headerValue('set-cookie')) || '';
  await page.waitForURL(BASE + '/');
  ok('Valid registration → home page, account in header', (await header().innerText()).includes('sara.test@example.com'));
  const ctaIn = await finalCta(page);
  ok('Home final section when signed in: only «ابدأ التجربة», no guest prompt', isUserCta(ctaIn), JSON.stringify(ctaIn));
  ok('«ابدأ التجربة» links to the Workspace', (await page.locator('.final-cta .btn').first().getAttribute('href')) === '/workspace');
  ok('Session cookie: HttpOnly, SameSite=Lax, Path=/, Max-Age', /HttpOnly/i.test(sc) && /SameSite=Lax/i.test(sc) && /Path=\//i.test(sc) && /Max-Age=\d+/i.test(sc), sc.replace(/=[^;]{12,}/, '=<redacted>'));
  const cookies = await ctx.cookies();
  ok('Session cookie not readable from page scripts', !(await page.evaluate(() => document.cookie)).includes('faseeh_session') && cookies.some((c) => c.name === 'faseeh_session' && c.httpOnly));
  const dump1 = JSON.parse(tweak('dump'));
  const acct = Object.values(dump1.accounts).find((a) => a.email === 'sara.test@example.com');
  ok('Firestore profile created, keyed by UID, with email + createdAt only', acct && dump1.profiles[acct.uid] && Object.keys(dump1.profiles[acct.uid]).sort().join() === 'createdAt,email,uid', JSON.stringify(dump1.profiles[acct?.uid]));

  // ── Logout (FSEEH-12, 89–91) ──────────────────────────────────
  group('Logout (FSEEH-12)');
  const oldCookie = (await ctx.cookies()).find((c) => c.name === 'faseeh_session');
  await page.locator('.account__btn').click();
  ok('Clearly labelled logout control in the account menu', await page.getByRole('menuitem', { name: 'تسجيل الخروج' }).isVisible());
  await page.getByRole('menuitem', { name: 'تسجيل الخروج' }).click();
  await page.waitForTimeout(600);
  ok('After logout the header shows guest controls', (await header().innerText()).includes('تسجيل الدخول'));
  ok('Home final section after logout: guest prompt and both buttons again', isGuestCta(await finalCta(page)));
  ok('Session cookie removed', !(await ctx.cookies()).some((c) => c.name === 'faseeh_session'));
  // replay the old cookie
  await ctx.addCookies([oldCookie]);
  const replay = await page.evaluate(() => fetch('/api/account').then((r) => r.status));
  ok('Replaying the old session cookie is rejected (401)', replay === 401, replay);
  await ctx.clearCookies();
  ok('Account and profile kept after logout', JSON.parse(tweak('dump')).profiles[acct.uid] !== undefined);
  await go('/profile');
  ok('Protected page after logout → login page', page.url().endsWith('/login'));
  await go('/history');
  ok('History (protected) after logout → login page', page.url().endsWith('/login'));

  // ── Login (FSEEH-7, 81–84) ────────────────────────────────────
  group('Login (FSEEH-7)');
  await go('/login');
  ok('Login page links to password recovery', (await page.locator('a[href="/forgot-password"]').count()) > 0);
  await page.locator('form button[type=submit]').click();
  ok('Missing credentials show validation', (await page.locator('.field__error:visible').count()) >= 2);
  await fill('البريد الإلكتروني', 'sara.test@example.com'); await fill('كلمة المرور', 'Wrong#2026');
  await Promise.all([page.waitForResponse(r=>r.url().includes('/api/auth/login')), page.locator('form button[type=submit]').click()]); await page.waitForTimeout(300);
  const e1 = await page.locator('form').innerText();
  await fill('البريد الإلكتروني', 'nobody@example.com'); await fill('كلمة المرور', 'Wrong#2026');
  await Promise.all([page.waitForResponse(r=>r.url().includes('/api/auth/login')), page.locator('form button[type=submit]').click()]); await page.waitForTimeout(300);
  const e2 = await page.locator('form').innerText();
  ok('Wrong password and unknown email show the same general error', e1.includes('غير صحيحة') && e1 === e2);
  ok('Failed login grants no session', (await page.evaluate(() => fetch('/api/auth/session').then((r) => r.json()))).user === null);
  await fill('البريد الإلكتروني', 'sara.test@example.com'); await fill('كلمة المرور', PW);
  await page.locator('form button[type=submit]').click(); await page.waitForURL(BASE + '/');
  ok('Valid credentials → session + home page', (await header().innerText()).includes('sara.test@example.com'));
  ok('Home final section after login: only «ابدأ التجربة»', isUserCta(await finalCta(page)));

  // ── Session expiry (FSEEH-113, 84) ─────────────────────────────
  group('Session expiry (FSEEH-113)');
  await go('/profile');
  ok('My Account opens with a valid session', page.url().endsWith('/profile') && (await page.locator('.profile__facts').innerText()).includes('sara.test@example.com'));
  tweak('advance', 4000); // the test configuration's session TTL is 3600 s
  const s = await page.evaluate(() => fetch('/api/auth/session').then((r) => r.json()));
  ok('Backend reports the expired session as guest (expired: true)', s.user === null && s.expired === true, JSON.stringify(s));
  await go('/profile');
  ok('Expired session: protected page → login page (no loop)', page.url().endsWith('/login') && (await page.locator('h1').innerText()).includes('تسجيل الدخول'));
  ok('Expired session: header returns to guest', (await header().innerText()).includes('تسجيل الدخول'));
  await go('/');
  ok('Home final section after session expiry: guest version', isGuestCta(await finalCta(page)));
  await go('/login');
  ok('Expired session: private data not returned', (await page.evaluate(() => fetch('/api/account').then((r) => r.status))) === 401);
  // expiry while My Account is open (the corrected gap)
  await fill('البريد الإلكتروني', 'sara.test@example.com'); await fill('كلمة المرور', PW);
  await page.locator('form button[type=submit]').click(); await page.waitForURL(BASE + '/');
  await go('/profile');
  tweak('advance', 4000);
  await fill('البريد الإلكتروني الجديد', 'sara.new@example.com'); await fill('كلمة المرور الحالية', PW);
  await page.getByRole('button', { name: 'احفظ البريد الجديد' }).click();
  await page.waitForURL(BASE + '/login', { timeout: 5000 }).catch(() => {});
  await page.waitForTimeout(400);
  ok('Expiry while My Account is open → interface returns to guest and login page', page.url().endsWith('/login') && (await header().innerText()).includes('تسجيل الدخول'));
  ok('"Session ended" message shown', (await toastText()).includes('انتهت'), await toastText());
  ok('Email unchanged after the rejected request', JSON.parse(tweak('dump')).profiles[acct.uid].email === 'sara.test@example.com');

  // ── Password recovery (FSEEH-26, 85–88) ────────────────────────
  group('Password recovery (FSEEH-26)');
  await go('/forgot-password');
  await page.locator('form button[type=submit]').click();
  ok('Empty email → validation', (await page.locator('.field__error:visible').count()) >= 1);
  await fill('البريد الإلكتروني', 'nobody@example.com'); await page.locator('form button[type=submit]').click(); await page.waitForTimeout(500);
  ok('Unregistered email → "no account is associated", no email sent', (await page.locator('main').innerText()).includes('لا يوجد حساب مرتبط') && JSON.parse(tweak('codes')).length === 0);
  await fill('البريد الإلكتروني', 'sara.test@example.com'); await page.locator('form button[type=submit]').click(); await page.waitForTimeout(500);
  const codes = JSON.parse(tweak('codes'));
  ok('Registered email → link sent and confirmation shown', codes.length === 1 && /أرسلنا|أُرسل|رابط/.test(await page.locator('main').innerText()));
  await go(`/reset-password?mode=resetPassword&oobCode=${codes[0]}`);
  await page.getByLabel('كلمة المرور الجديدة', { exact: true }).waitFor();
  await fill('كلمة المرور الجديدة', 'weakpass'); await fill('تأكيد كلمة المرور', 'weakpass');
  await page.locator('form button[type=submit]').click();
  ok('New password must meet the policy', (await page.locator('.field__error').allTextContents()).join().includes('الشروط'));
  await fill('كلمة المرور الجديدة', PW2); await fill('تأكيد كلمة المرور', 'Faseeh#9999');
  await page.locator('form button[type=submit]').click();
  ok('Mismatched passwords prevent the reset', (await page.locator('.field__error').allTextContents()).join().includes('متطابقتين'));
  await fill('تأكيد كلمة المرور', PW2);
  await page.locator('form button[type=submit]').click();
  await page.waitForURL(BASE + '/login');
  ok('Valid reset → login page with notice', (await page.locator('main').innerText()).includes('تم تغيير كلمة المرور'));
  await go(`/reset-password?mode=resetPassword&oobCode=${codes[0]}`); await page.waitForTimeout(800);
  ok('Used link cannot be reused', (await page.locator('main').innerText()).includes('غير صالح'));
  await go('/reset-password?mode=resetPassword&oobCode=forged'); await page.waitForTimeout(800);
  ok('Invalid link rejected', (await page.locator('main').innerText()).includes('غير صالح'));
  const stOld = await page.evaluate(([pw]) => fetch('/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: 'sara.test@example.com', password: pw }) }).then((r) => r.status), [PW]);
  ok('Old password no longer works', stOld === 401, stOld);
  await go('/login');
  await fill('البريد الإلكتروني', 'sara.test@example.com'); await fill('كلمة المرور', PW2);
  await page.locator('form button[type=submit]').click(); await page.waitForURL(BASE + '/');
  ok('New password works', (await header().innerText()).includes('sara.test@example.com'));

  // ── Edit Profile (FSEEH-49, 92–94, 116) ───────────────────────
  group('Edit Profile (FSEEH-49)');
  // second account to test duplicates/isolation
  const other = await browser.newContext(); const op = await other.newPage();
  await op.goto(BASE + '/register');
  await op.getByLabel('البريد الإلكتروني', { exact: true }).fill('other.user@example.com'); await op.getByLabel('كلمة المرور', { exact: true }).fill(PW); await op.getByLabel('تأكيد كلمة المرور', { exact: true }).fill(PW);
  await op.locator('form button[type=submit]').click(); await op.waitForURL(BASE + '/'); await other.close();
  await page.locator('.account__btn').click();
  await page.getByRole('menuitem', { name: 'حسابي' }).click(); await page.waitForURL(BASE + '/profile');
  const facts = await page.locator('.profile__facts').innerText();
  ok('My Account from the account menu shows email and creation date', facts.includes('sara.test@example.com') && facts.includes('عضو منذ'));
  ok('Only the email can be edited', (await page.locator('.profile__form input:not([type=password])').count()) === 1);
  await page.getByRole('button', { name: 'احفظ البريد الجديد' }).click();
  ok('Empty email / missing password → field validation', (await page.locator('.profile__form .field__error:visible').count()) === 2);
  await fill('البريد الإلكتروني الجديد', 'sara.test@example.com'); await fill('كلمة المرور الحالية', PW2);
  await Promise.all([page.waitForResponse(r=>r.url().includes('/api/account/email')), page.getByRole('button', { name: 'احفظ البريد الجديد' }).click()]); await page.waitForTimeout(250);
  ok('Unchanged email rejected', (await page.locator('.profile__form').innerText()).includes('بريدك الإلكتروني الحالي'));
  await fill('البريد الإلكتروني الجديد', 'sara.new@example.com'); await fill('كلمة المرور الحالية', 'Wrong#1111');
  await Promise.all([page.waitForResponse(r=>r.url().includes('/api/account/email')), page.getByRole('button', { name: 'احفظ البريد الجديد' }).click()]); await page.waitForTimeout(250);
  ok('Wrong current password → error under the password field, nothing changed', (await page.locator('.profile__form').innerText()).includes('كلمة المرور الحالية غير صحيحة') && page.url().endsWith('/profile'));
  await fill('البريد الإلكتروني الجديد', 'other.user@example.com'); await fill('كلمة المرور الحالية', PW2);
  await Promise.all([page.waitForResponse(r=>r.url().includes('/api/account/email')), page.getByRole('button', { name: 'احفظ البريد الجديد' }).click()]); await page.waitForTimeout(250);
  ok('Email of another account rejected under the email field', (await page.locator('.profile__form').innerText()).includes('مسجّل لحساب آخر'));
  tweak('set', 'failProfileWrites', 1);
  await fill('البريد الإلكتروني الجديد', 'sara.new@example.com'); await fill('كلمة المرور الحالية', PW2);
  await page.getByRole('button', { name: 'احفظ البريد الجديد' }).click(); await page.waitForTimeout(700);
  const d2 = JSON.parse(tweak('dump'));
  ok('Update failure → error, previous email kept in Auth and profile', (await page.locator('.profile__form').innerText()).includes('تعذّر') && d2.profiles[acct.uid].email === 'sara.test@example.com' && Object.values(d2.accounts).some((a) => a.email === 'sara.test@example.com'));
  tweak('set', 'failProfileWrites', 0);
  await fill('البريد الإلكتروني الجديد', 'sara.new@example.com'); await fill('كلمة المرور الحالية', PW2);
  await page.getByRole('button', { name: 'احفظ البريد الجديد' }).click(); await page.waitForTimeout(700);
  const d3 = JSON.parse(tweak('dump'));
  ok('Valid change updates Auth + profile, page and header', d3.profiles[acct.uid].email === 'sara.new@example.com' && (await header().innerText()).includes('sara.new@example.com') && (await page.locator('.profile__facts').innerText()).includes('sara.new@example.com'));
  const stNew = await page.evaluate(([pw]) => Promise.all(['sara.test@example.com', 'sara.new@example.com'].map((e) => fetch('/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: e, password: pw }) }).then((r) => r.status))), [PW2]);
  ok('Old email no longer signs in; new email does', stNew[0] === 401 && stNew[1] === 200, stNew.join());

  // ── Delete account (FSEEH-50, 95–97) ─────────────────────────
  group('Delete Account (FSEEH-50)');
  await go('/profile');
  await page.getByRole('button', { name: 'حذف الحساب' }).click();
  const dlg = page.getByRole('dialog');
  ok('Delete opens a confirmation dialog asking for the password', (await dlg.innerText()).includes('كلمة المرور'));
  await dlg.getByRole('button', { name: 'إلغاء' }).click();
  ok('Cancel leaves the account unchanged', JSON.parse(tweak('dump')).profiles[acct.uid] !== undefined);
  await page.getByRole('button', { name: 'حذف الحساب' }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'نعم، احذف حسابي' }).click();
  ok('Missing password → validation, nothing deleted', (await page.getByRole('dialog').innerText()).includes('يرجى إدخال كلمة المرور') && JSON.parse(tweak('dump')).profiles[acct.uid]);
  await page.getByRole('dialog').getByLabel('كلمة المرور', { exact: true }).fill('Wrong#1111');
  await page.getByRole('dialog').getByRole('button', { name: 'نعم، احذف حسابي' }).click(); await page.waitForTimeout(600);
  ok('Wrong password → error, nothing deleted', (await page.getByRole('dialog').innerText()).includes('غير صحيحة') && JSON.parse(tweak('dump')).profiles[acct.uid]);
  tweak('set', 'failAccountDeletes', 1);
  await page.getByRole('dialog').getByLabel('كلمة المرور', { exact: true }).fill(PW2);
  await page.getByRole('dialog').getByRole('button', { name: 'نعم، احذف حسابي' }).click(); await page.waitForTimeout(700);
  const d4 = JSON.parse(tweak('dump'));
  ok('Deletion failure → error; account and profile unchanged', (await page.getByRole('dialog').innerText()).includes('تعذّر') && d4.profiles[acct.uid] && Object.values(d4.accounts).some((a) => a.uid === acct.uid));
  tweak('set', 'failAccountDeletes', 0);
  await page.getByRole('dialog').getByRole('button', { name: 'نعم، احذف حسابي' }).click();
  await page.waitForURL(BASE + '/'); await page.waitForTimeout(400);
  const d5 = JSON.parse(tweak('dump'));
  ok('Confirmed deletion removes Auth account and Firestore profile', !d5.profiles[acct.uid] && !Object.values(d5.accounts).some((a) => a.uid === acct.uid));
  ok('Home page with confirmation; signed out', (await toastText()).includes('حُذف') && (await header().innerText()).includes('تسجيل الدخول'));
  ok('Other account unaffected', Object.values(d5.accounts).some((a) => a.email === 'other.user@example.com'));
  await go('/profile');
  ok('Protected pages require login after deletion', page.url().endsWith('/login'));
  const stDel = await page.evaluate(([pw]) => fetch('/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: 'sara.new@example.com', password: pw }) }).then((r) => r.status), [PW2]);
  ok('Deleted credentials cannot be used', stDel === 401);
  const stReReg = await page.evaluate(([pw]) => fetch('/api/auth/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: 'sara.new@example.com', password: pw, confirm: pw }) }).then((r) => r.status), [PW]);
  ok('Deleted email can register again', stReReg === 201, stReReg);
  ok('Duplicate registration refused (409)', (await page.evaluate(([pw]) => fetch('/api/auth/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: 'SARA.NEW@example.com', password: pw, confirm: pw }) }).then((r) => r.status), [PW])) === 409);

  // ── Security spot checks ─────────────────────────────────────
  group('Security');
  ok('Non-JSON POST refused', (await page.evaluate(() => fetch('/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: 'x' }).then((r) => r.status))) >= 400);
  const dumpAll = tweak('dump');
  ok('No password stored in Firestore profiles', !/Faseeh#|password/i.test(JSON.stringify(JSON.parse(dumpAll).profiles)));
  ok('No uncaught page errors during the run', consoleErrors.length === 0, consoleErrors.slice(0, 3).join(' | '));

  await browser.close();
  fs.writeFileSync(path.join(WORK, 'e2e-results.json'), JSON.stringify(results, null, 1));
  const failed = results.filter((r) => !r.pass);
  console.log(`\n${results.length - failed.length}/${results.length} passed`);
  process.exit(failed.length ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); fs.writeFileSync(path.join(WORK, 'e2e-results.json'), JSON.stringify(results, null, 1)); process.exit(2); });
