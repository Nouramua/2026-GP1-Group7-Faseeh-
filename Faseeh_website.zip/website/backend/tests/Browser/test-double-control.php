<?php
// TEST-ONLY helper: edits the in-memory Firebase test double's saved state.
//   php test-double-control.php <stateFile> advance <seconds>      move the double's clock forward (expire sessions)
//   php test-double-control.php <stateFile> set <property> <0|1>   switch failProfileWrites / failAccountDeletes
//   php test-double-control.php <stateFile> codes                  print reset codes (TEST double only)
//   php test-double-control.php <stateFile> dump                   print accounts (uid, email) and profiles
require dirname(__DIR__, 2) . '/vendor/autoload.php';
[$_, $file, $cmd] = $argv;
$fh = fopen($file, 'c+');
flock($fh, LOCK_EX);
$fb = unserialize(stream_get_contents($fh));
if ($cmd === 'advance') { $fb->now += (int) $argv[3]; }
if ($cmd === 'set') { $fb->{$argv[3]} = (bool) (int) $argv[4]; }
if ($cmd === 'codes') { echo json_encode(array_keys($fb->resetCodes)); }
if ($cmd === 'dump') { echo json_encode(['accounts' => array_map(fn($a) => ['uid' => $a['uid'], 'email' => $a['email']], $fb->accounts), 'profiles' => $fb->profiles]); }
ftruncate($fh, 0); rewind($fh); fwrite($fh, serialize($fb)); flock($fh, LOCK_UN); fclose($fh);
