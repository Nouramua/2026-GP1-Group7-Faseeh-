<?php

declare(strict_types=1);

/**
 * Front controller. `/api/*` goes to the PHP backend; any other path serves the
 * built frontend (FRONTEND_DIST) so the single-page app can handle it.
 *
 * Development:  php -S 127.0.0.1:8080 -t public public/index.php
 */

use Faseeh\App;
use Faseeh\Config;
use Faseeh\Http\Request;

require dirname(__DIR__) . '/vendor/autoload.php';

$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';

try {
    $config = Config::fromEnvironment(dirname(__DIR__) . '/.env');
} catch (Throwable $e) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    error_log('[faseeh] configuration error: ' . $e->getMessage());
    echo json_encode([
        'error' => 'configuration',
        'message' => 'الخادم غير مهيّأ بعد. راجع إعدادات Firebase في ملف backend/.env.',
    ], JSON_UNESCAPED_UNICODE);
    return;
}

if (str_starts_with($path, '/api/')) {
    App::create($config)->handle(Request::fromGlobals())->send();
    return;
}

// Static frontend (production build), with SPA fallback to index.html.
$dist = $config->frontendDist;
if ($dist === null || !is_dir($dist)) {
    http_response_code(404);
    echo 'Frontend build not configured (FRONTEND_DIST). In development, open the Vite dev server instead.';
    return;
}
$real = realpath($dist . $path);
if ($real !== false && str_starts_with($real, realpath($dist)) && is_file($real)) {
    $types = ['js' => 'text/javascript', 'css' => 'text/css', 'svg' => 'image/svg+xml', 'woff2' => 'font/woff2', 'woff' => 'font/woff', 'png' => 'image/png', 'html' => 'text/html; charset=utf-8'];
    header('Content-Type: ' . ($types[pathinfo($real, PATHINFO_EXTENSION)] ?? 'application/octet-stream'));
    readfile($real);
    return;
}
header('Content-Type: text/html; charset=utf-8');
readfile($dist . '/index.html');
