<?php

declare(strict_types=1);

namespace Faseeh\Http;

use RuntimeException;

/**
 * An expected error that is returned to the presentation layer as JSON
 * (see Response::fromException). The message is always safe to show the user.
 */
final class ApiException extends RuntimeException
{
    /**
     * @param int                  $status    HTTP status code (400 validation, 401 no session, 409 conflict, 502 Firebase failure …)
     * @param string               $errorCode stable machine-readable code the frontend can test, e.g. "session_expired"
     * @param string               $message   Arabic message for the user
     * @param array<string,string> $fields    per-field messages, shown under the matching inputs
     */
    public function __construct(
        public readonly int $status,
        public readonly string $errorCode,
        string $message,
        public readonly array $fields = [],
    ) {
        parent::__construct($message);
    }

    /**
     * 400 with field errors: the request was rejected before anything changed.
     *
     * @param array<string,string> $fields
     */
    public static function validation(array $fields, string $message = 'يرجى تصحيح الحقول المشار إليها.'): self
    {
        return new self(400, 'validation', $message, $fields);
    }

    /** 401: no session cookie was sent with a request to a protected endpoint. */
    public static function unauthorized(string $message = 'يرجى تسجيل الدخول للمتابعة.'): self
    {
        return new self(401, 'unauthorized', $message);
    }
}
