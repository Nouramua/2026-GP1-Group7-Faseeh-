<?php

declare(strict_types=1);

namespace Faseeh\Http;

/**
 * An incoming HTTP request in the small shape the controllers need: method,
 * path, decoded JSON body, cookies and headers. Immutable once built.
 */
final class Request
{
    /**
     * @param string               $method  upper-case HTTP method
     * @param string               $path    URL path without the query string, e.g. "/api/auth/login"
     * @param array<string,mixed>  $body    decoded JSON body ({"__invalid_json": true} if it could not be decoded)
     * @param array<string,string> $cookies request cookies (the session cookie is read from here)
     * @param array<string,string> $headers request headers with lower-case names
     */
    public function __construct(
        public readonly string $method,
        public readonly string $path,
        public readonly array $body = [],
        public readonly array $cookies = [],
        public readonly array $headers = [],
    ) {
    }

    /** Builds the Request from PHP's superglobals for the current HTTP request. */
    public static function fromGlobals(): self
    {
        $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
        $headers = [];
        // PHP exposes headers as HTTP_X_Y entries; turn them back into "x-y".
        foreach ($_SERVER as $k => $v) {
            if (str_starts_with($k, 'HTTP_')) {
                $headers[strtolower(str_replace('_', '-', substr($k, 5)))] = (string) $v;
            }
        }
        if (isset($_SERVER['CONTENT_TYPE'])) {
            $headers['content-type'] = (string) $_SERVER['CONTENT_TYPE'];
        }
        // Raw request body; only JSON is accepted (App::guardCrossSite rejects other types).
        $raw = file_get_contents('php://input') ?: '';
        $body = [];
        if ($raw !== '') {
            $decoded = json_decode($raw, true);
            // A body that is not a JSON object is flagged so the router can reject it with 400.
            $body = is_array($decoded) ? $decoded : ['__invalid_json' => true];
        }
        return new self(strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET'), $path, $body, $_COOKIE, $headers);
    }

    /**
     * A body field as a string. Missing or non-string values (numbers, arrays,
     * null) become "", so the validators see them as empty instead of crashing.
     */
    public function string(string $key): string
    {
        $v = $this->body[$key] ?? '';
        return is_string($v) ? $v : '';
    }

    /** A request header by case-insensitive name, or null if absent. */
    public function header(string $name): ?string
    {
        return $this->headers[strtolower($name)] ?? null;
    }
}
