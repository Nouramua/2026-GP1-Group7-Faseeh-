<?php

declare(strict_types=1);

namespace Faseeh\Http;

/** A JSON response from the backend, with optional Set-Cookie headers. */
final class Response
{
    /** @var list<string> raw Set-Cookie header values */
    public array $cookies = [];

    /**
     * @param int                       $status HTTP status code
     * @param array<string,mixed>|null  $json   body to encode as JSON
     */
    public function __construct(public int $status = 200, public ?array $json = null)
    {
    }

    /** @param array<string,mixed> $data the response body */
    public static function json(array $data, int $status = 200): self
    {
        return new self($status, $data);
    }

    /**
     * The error format every client handles: {error: code, message: Arabic text,
     * fields?: {fieldName: message}}. The frontend shows `fields` under the matching inputs.
     */
    public static function fromException(ApiException $e): self
    {
        $body = ['error' => $e->errorCode, 'message' => $e->getMessage()];
        if ($e->fields !== []) {
            $body['fields'] = $e->fields;
        }
        return new self($e->status, $body);
    }

    /** Adds a Set-Cookie header (built by SessionCookie) and returns the same response. */
    public function withCookie(string $setCookie): self
    {
        $this->cookies[] = $setCookie;
        return $this;
    }

    /** Writes the status, security headers, cookies and JSON body to the client. */
    public function send(): void
    {
        http_response_code($this->status);
        header('Content-Type: application/json; charset=utf-8');
        // Account data must never be stored by the browser or a proxy cache.
        header('Cache-Control: no-store');
        // Stops browsers from guessing a different content type.
        header('X-Content-Type-Options: nosniff');
        // Do not leak page addresses (which can contain reset codes) to other sites.
        header('Referrer-Policy: same-origin');
        // false = add a header instead of replacing, so several cookies can be sent.
        foreach ($this->cookies as $c) {
            header('Set-Cookie: ' . $c, false);
        }
        echo json_encode($this->json ?? new \stdClass(), JSON_UNESCAPED_UNICODE);
    }
}
