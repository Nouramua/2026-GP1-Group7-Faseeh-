<?php

declare(strict_types=1);

namespace Faseeh\Validation;

/**
 * Server-side validation for the account forms (Jira FSEEH-78). The same rules
 * and Arabic messages are applied in the browser by
 * frontend/src/shared/validation.ts; the server never trusts the browser's check.
 *
 * Sources: Create an Account AC2–AC4, Log In AC2, Recover a Forgotten Password
 * AC2/AC5/AC6 (final Product Backlog stories 1–3); C2b "input valid? (email
 * format, passwords match, password policy)".
 *
 * Each method returns null when the value is valid, or the Arabic error message.
 */
final class AuthValidator
{
    /** Something@something.tld with no spaces; deliberately simple, Firebase does the final check. */
    private const EMAIL_RE = '/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/u';

    /** Email: required, at most 254 characters (the standard maximum), and well-formed. */
    public static function email(string $email): ?string
    {
        $v = trim($email);
        if ($v === '') {
            return 'يرجى إدخال البريد الإلكتروني.';
        }
        if (mb_strlen($v) > 254 || preg_match(self::EMAIL_RE, $v) !== 1) {
            return 'صيغة البريد الإلكتروني غير صحيحة، مثال: name@example.com';
        }
        return null;
    }

    /**
     * The documented password policy (Create an Account AC4, Recover a Forgotten
     * Password AC5): at least 8 characters, including one uppercase letter, one
     * lowercase letter, one digit and one special character.
     *
     * @return array<string,bool> each rule → whether the password satisfies it
     */
    public static function passwordChecks(string $pw): array
    {
        return [
            'length' => mb_strlen($pw) >= 8,
            'upper' => preg_match('/[A-Z]/', $pw) === 1,
            'lower' => preg_match('/[a-z]/', $pw) === 1,
            'digit' => preg_match('/[0-9]/', $pw) === 1,
            'special' => preg_match('/[^A-Za-z0-9\s]/', $pw) === 1,
        ];
    }

    /**
     * Password: required, meets every policy rule; the message lists the missing rules.
     * The 128-character ceiling is a security bound on what is sent to Firebase,
     * not a product rule.
     */
    public static function password(string $pw): ?string
    {
        if ($pw === '') {
            return 'يرجى إدخال كلمة المرور.';
        }
        if (mb_strlen($pw) > 128) {
            return 'كلمة المرور طويلة جدًا (الحد ١٢٨ حرفًا).';
        }
        $labels = [
            'length' => '٨ أحرف على الأقل',
            'upper' => 'حرف إنجليزي كبير (A–Z)',
            'lower' => 'حرف إنجليزي صغير (a–z)',
            'digit' => 'رقم واحد على الأقل',
            'special' => 'رمز خاص مثل ! @ # ؟',
        ];
        $missing = [];
        foreach (self::passwordChecks($pw) as $k => $ok) {
            if (!$ok) {
                $missing[] = $labels[$k];
            }
        }
        return $missing === [] ? null : 'كلمة المرور لا تستوفي الشروط: ' . implode('، ', $missing) . '.';
    }

    /** Confirmation: required and identical to the password. */
    public static function confirm(string $pw, string $confirm): ?string
    {
        if ($confirm === '') {
            return 'يرجى تأكيد كلمة المرور.';
        }
        return $pw === $confirm ? null : 'كلمتا المرور غير متطابقتين.';
    }

    /**
     * Keeps only the failed checks, giving the field → message map that is
     * returned to the browser (empty array = everything valid).
     *
     * @param array<string,?string> $checks
     * @return array<string,string>
     */
    public static function collect(array $checks): array
    {
        return array_filter($checks, static fn ($v) => $v !== null);
    }
}
