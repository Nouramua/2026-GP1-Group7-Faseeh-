<?php

declare(strict_types=1);

namespace Faseeh\Firebase;

use Google\Auth\Credentials\ServiceAccountCredentials;
use GuzzleHttp\ClientInterface;
use GuzzleHttp\Exception\GuzzleException;

/**
 * Stores user profiles in Cloud Firestore through the Firestore REST API.
 *
 * Why REST and not the Firestore PHP client: the PHP client needs the `grpc`
 * extension, which typical PHP hosting does not provide. The REST API needs
 * only HTTPS, authorised with the same service account as the Admin SDK.
 *
 * Data model: one document per user at {collection}/{Firebase UID}, with the
 * fields `email` (string) and `createdAt` (timestamp). The document ID is the
 * Firebase Authentication UID, which links the profile to the account.
 * No password or other personal data is ever written here.
 */
final class FirestoreRestProfileStore implements ProfileStore
{
    /** OAuth scope that allows reading and writing Cloud Firestore documents. */
    private const SCOPE = 'https://www.googleapis.com/auth/datastore';

    /**
     * Access token reused for the rest of this request. One API call can make
     * two Firestore requests (Delete Account reads then deletes the profile), and
     * a token is valid for about an hour, so fetching one per request is enough.
     */
    private ?string $token = null;

    /**
     * @param ClientInterface $http          HTTP client (Guzzle) used for the REST calls
     * @param string          $projectId     Firebase project ID (FIREBASE_PROJECT_ID)
     * @param string          $databaseId    Firestore database, normally "(default)" (FIRESTORE_DATABASE_ID)
     * @param string          $collection    profile collection name (FIRESTORE_USERS_COLLECTION)
     * @param string|null     $credentialsPath path to the service-account JSON file (FIREBASE_CREDENTIALS)
     * @param string|null     $emulatorHost  host:port of the Firestore emulator, for local tests only
     */
    public function __construct(
        private readonly ClientInterface $http,
        private readonly string $projectId,
        private readonly string $databaseId,
        private readonly string $collection,
        private readonly ?string $credentialsPath,
        private readonly ?string $emulatorHost = null,
    ) {
    }

    /**
     * Creates the profile right after Firebase creates the account (C2b "create
     * user profile in Cloud Firestore", Jira FSEEH-79).
     *
     * `?documentId=` makes Firestore refuse to overwrite an existing document,
     * so an existing profile can never be replaced by accident.
     *
     * @param string|null $createdAt ISO-8601 time; null means "now". Given only when restoring a profile.
     * @throws ProfileWriteFailed when Firestore refuses the write or cannot be reached
     */
    public function createProfile(string $uid, string $email, ?string $createdAt = null): void
    {
        $url = $this->collectionUrl() . '?documentId=' . rawurlencode($uid);
        // Firestore REST represents each field as {type: value}.
        $body = [
            'fields' => [
                'email' => ['stringValue' => $email],
                'createdAt' => ['timestampValue' => $createdAt ?? gmdate('Y-m-d\TH:i:s\Z')],
            ],
        ];
        $this->send('POST', $url, $body);
    }

    /**
     * Deletes the profile (Delete Account, FSEEH-96; registration rollback).
     * A 404 is tolerated: a profile that is already gone counts as deleted.
     */
    public function deleteProfile(string $uid): void
    {
        $this->send('DELETE', $this->documentUrl($uid), null, [404]);
    }

    /**
     * Reads the profile shown on My Account (FSEEH-92).
     *
     * @return array{email:string,createdAt:?string}|null null when no profile exists
     */
    public function getProfile(string $uid): ?array
    {
        $res = $this->send('GET', $this->documentUrl($uid), null, [404]);
        if ($res === null) {
            return null;
        }
        $fields = $res['fields'] ?? [];
        // Unwrap Firestore's typed values back into plain PHP strings.
        return [
            'email' => (string) ($fields['email']['stringValue'] ?? ''),
            'createdAt' => isset($fields['createdAt']['timestampValue']) ? (string) $fields['createdAt']['timestampValue'] : null,
        ];
    }

    /**
     * Keeps the profile's email equal to the account's after Edit Profile (FSEEH-94).
     * `updateMask.fieldPaths=email` changes only that field; `currentDocument.exists=true`
     * makes the update fail instead of creating a new document if the profile is missing.
     */
    public function updateEmail(string $uid, string $email): void
    {
        $url = $this->documentUrl($uid) . '?updateMask.fieldPaths=email&currentDocument.exists=true';
        $this->send('PATCH', $url, ['fields' => ['email' => ['stringValue' => $email]]]);
    }

    /**
     * Sends one authorised request to the Firestore REST API.
     *
     * @param string                    $method    HTTP method (GET, POST, PATCH, DELETE)
     * @param string                    $url       full document or collection URL
     * @param array<string,mixed>|null  $json      request body, or null for none
     * @param list<int>                 $tolerated status codes that mean "nothing there" (the method returns null)
     * @return array<string,mixed>|null decoded response body, or null for a tolerated status
     * @throws ProfileWriteFailed for any other error status or a network failure
     */
    private function send(string $method, string $url, ?array $json, array $tolerated = []): ?array
    {
        $options = [
            'headers' => ['Authorization' => 'Bearer ' . $this->accessToken()],
            'http_errors' => false, // inspect the status ourselves instead of catching Guzzle exceptions
            'timeout' => 15,        // never leave the user waiting indefinitely
        ];
        if ($json !== null) {
            $options['json'] = $json;
        }
        try {
            $res = $this->http->request($method, $url, $options);
        } catch (GuzzleException $e) {
            // DNS, TLS or timeout problems: Firestore could not be reached.
            throw new ProfileWriteFailed('firestore unreachable', 0, $e);
        }
        $status = $res->getStatusCode();
        if (in_array($status, $tolerated, true)) {
            return null;
        }
        if ($status >= 300) {
            // Only the method and status are logged later: never the token or the document body.
            throw new ProfileWriteFailed("firestore {$method} returned {$status}");
        }
        $decoded = json_decode((string) $res->getBody(), true);
        return is_array($decoded) ? $decoded : [];
    }

    /** URL of one user's profile document. */
    private function documentUrl(string $uid): string
    {
        return $this->collectionUrl() . '/' . rawurlencode($uid);
    }

    /** URL of the profile collection, on Google's servers or on the local emulator. */
    private function collectionUrl(): string
    {
        $base = $this->emulatorHost !== null
            ? "http://{$this->emulatorHost}/v1"
            : 'https://firestore.googleapis.com/v1';
        return sprintf(
            '%s/projects/%s/databases/%s/documents/%s',
            $base,
            rawurlencode($this->projectId),
            rawurlencode($this->databaseId),
            rawurlencode($this->collection),
        );
    }

    /**
     * Returns an OAuth 2.0 access token for the service account, fetching it
     * once per request (see $token).
     */
    private function accessToken(): string
    {
        if ($this->emulatorHost !== null) {
            return 'owner'; // the Firestore emulator accepts this fixed token
        }
        if ($this->token === null) {
            // Signs a JWT with the service account's private key and exchanges it for an access token.
            $creds = new ServiceAccountCredentials(self::SCOPE, (string) $this->credentialsPath);
            $this->token = (string) ($creds->fetchAuthToken()['access_token'] ?? '');
        }
        return $this->token;
    }
}
