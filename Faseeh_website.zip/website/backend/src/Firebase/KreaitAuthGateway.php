<?php

declare(strict_types=1);

namespace Faseeh\Firebase;

use Kreait\Firebase\Auth\SignIn\FailedToSignIn;
use Kreait\Firebase\Contract\Auth;
use Kreait\Firebase\Exception\Auth\EmailExists;
use Kreait\Firebase\Exception\Auth\ExpiredOobCode;
use Kreait\Firebase\Exception\Auth\FailedToVerifySessionCookie;
use Kreait\Firebase\Exception\Auth\InvalidOobCode;
use Kreait\Firebase\Exception\Auth\UserNotFound;
use Kreait\Firebase\Exception\AuthException;

/**
 * The real Firebase Authentication gateway, built on the official Firebase Admin
 * SDK for PHP (kreait/firebase-php) and authorised with the project's service
 * account (see App::create()).
 *
 * Architecture: the browser never talks to Firebase directly. Every request goes
 * to the PHP backend, which calls Firebase through this class. Each method
 * translates the SDK's own exceptions into Faseeh's small set of domain errors
 * (Firebase/Exceptions.php), so the controllers never depend on SDK classes.
 */
final class KreaitAuthGateway implements AuthGateway
{
    /** @param Auth $auth the Admin SDK's Authentication client, created by Factory::createAuth() */
    public function __construct(private readonly Auth $auth)
    {
    }

    /**
     * Creates a Firebase Authentication user (Create Account, Jira FSEEH-79).
     * Firebase hashes and stores the password; Faseeh never stores it.
     *
     * @return string the new user's UID, used as the Firestore profile document ID
     * @throws EmailAlreadyRegistered when the email already has an account
     */
    public function createAccount(string $email, string $password): string
    {
        try {
            // Admin SDK call → Firebase Auth REST "accounts:signUp" with admin rights.
            return $this->auth->createUserWithEmailAndPassword($email, $password)->uid;
        } catch (EmailExists $e) {
            // Firebase compares emails case-insensitively, so "A@x.com" and "a@x.com" collide.
            throw new EmailAlreadyRegistered('email exists', 0, $e);
        }
    }

    /**
     * Permanently deletes a Firebase Authentication user. Used by Delete Account
     * (FSEEH-96) and to roll back a registration that could not be completed.
     * Deleting the user also makes all of its session cookies invalid.
     */
    public function deleteAccount(string $uid): void
    {
        $this->auth->deleteUser($uid);
    }

    /**
     * Checks an email/password pair with Firebase (the "Firebase check" in C2b).
     *
     * @return string a short-lived Firebase ID token for the user
     * @throws InvalidCredentials for any wrong email, wrong password or disabled account
     * @throws TooManyAttempts when Firebase is temporarily blocking sign-ins
     */
    public function signIn(string $email, string $password): string
    {
        try {
            $result = $this->auth->signInWithEmailAndPassword($email, $password);
        } catch (FailedToSignIn $e) {
            // Firebase's error codes are inside the exception message.
            $msg = strtoupper($e->getMessage());
            if (str_contains($msg, 'TOO_MANY_ATTEMPTS')) {
                throw new TooManyAttempts('too many attempts', 0, $e);
            }
            // EMAIL_NOT_FOUND, INVALID_PASSWORD, INVALID_LOGIN_CREDENTIALS, USER_DISABLED …
            // are deliberately collapsed into ONE error, so the login page cannot reveal
            // whether an email is registered (Log In AC4, FSEEH-83).
            throw new InvalidCredentials('invalid credentials', 0, $e);
        }
        $token = $result->idToken();
        // Defensive: a successful sign-in must always return an ID token.
        if ($token === null || $token === '') {
            throw new InvalidCredentials('no id token');
        }
        return $token;
    }

    /**
     * Exchanges an ID token for a Firebase SESSION COOKIE (FSEEH-82): a signed
     * token that Firebase issues and the backend can verify on every request.
     *
     * @param int $ttlSeconds lifetime chosen by SESSION_TTL_SECONDS (Firebase allows 5 min – 14 days)
     * @return string the session cookie value, stored in the browser by SessionCookie
     */
    public function startSession(string $idToken, int $ttlSeconds): string
    {
        return $this->auth->createSessionCookie($idToken, $ttlSeconds);
    }

    /**
     * Verifies a session cookie: signature, expiry, and (because checkIfRevoked is
     * true) whether it was revoked by logout, a password reset or account deletion.
     *
     * @return array{uid:string,email:string} the signed-in user taken from the verified token
     * @throws InvalidSession when the cookie is malformed, expired or revoked
     */
    public function verifySession(string $sessionCookie): array
    {
        try {
            // Second argument = checkIfRevoked: also asks Firebase whether the
            // user's sessions were revoked after this cookie was issued.
            $token = $this->auth->verifySessionCookie($sessionCookie, true);
        } catch (FailedToVerifySessionCookie|AuthException|\InvalidArgumentException $e) {
            throw new InvalidSession('invalid session', 0, $e);
        }
        $claims = $token->claims();
        // "sub" (subject) is the Firebase UID; it is the only identity the backend trusts.
        $uid = (string) $claims->get('sub', '');
        if ($uid === '') {
            throw new InvalidSession('session without subject');
        }
        return ['uid' => $uid, 'email' => (string) $claims->get('email', '')];
    }

    /**
     * Ends the user's sessions (Log Out, FSEEH-90). Firebase cannot revoke one
     * single session cookie, so this revokes all of the user's refresh tokens;
     * verifySession() then rejects every cookie issued before this moment.
     */
    public function endSessions(string $uid): void
    {
        $this->auth->revokeRefreshTokens($uid);
    }

    /**
     * Looks up whether an email belongs to an account. Used only by password
     * recovery, whose acceptance criterion 4 requires telling the user when no
     * account is associated with the email.
     */
    public function isEmailRegistered(string $email): bool
    {
        try {
            $this->auth->getUserByEmail($email);
            return true;
        } catch (UserNotFound) {
            return false;
        }
    }

    /**
     * Asks Firebase to email a password-reset link (FSEEH-86). The email is sent
     * by Firebase using the project's template; 'ar' requests the Arabic version.
     */
    public function sendPasswordResetEmail(string $email): void
    {
        $this->auth->sendPasswordResetLink($email, null, 'ar');
    }

    /**
     * Checks a reset link's one-time code (the "oobCode" in the link) before the
     * new-password form is shown (FSEEH-88).
     *
     * @return string the email of the account the link belongs to
     * @throws InvalidResetLink when the code is unknown, expired or already used
     */
    public function verifyPasswordResetLink(string $oobCode): string
    {
        try {
            return $this->auth->verifyPasswordResetCode($oobCode);
        } catch (ExpiredOobCode|InvalidOobCode $e) {
            throw new InvalidResetLink('invalid or expired link', 0, $e);
        } catch (AuthException $e) {
            throw new InvalidResetLink('invalid link', 0, $e);
        }
    }

    /**
     * Sets the new password using the reset link's code (FSEEH-87). Firebase
     * consumes the code, so the same link cannot be used again.
     *
     * @throws InvalidResetLink when the code is unknown, expired or already used
     */
    public function updatePassword(string $oobCode, string $newPassword): void
    {
        try {
            // Third argument = invalidatePreviousSessions: sessions opened with the old password end.
            $this->auth->confirmPasswordReset($oobCode, $newPassword, true);
        } catch (ExpiredOobCode|InvalidOobCode $e) {
            throw new InvalidResetLink('invalid or expired link', 0, $e);
        } catch (AuthException $e) {
            // Some SDK versions report a bad code as a generic AuthException mentioning "OOB".
            if (str_contains(strtoupper($e->getMessage()), 'OOB')) {
                throw new InvalidResetLink('invalid link', 0, $e);
            }
            // Anything else is a real service failure; the controller reports it as such.
            throw $e;
        }
    }

    /**
     * Changes the account's sign-in email in Firebase Authentication (Edit Profile, FSEEH-94).
     *
     * @throws EmailAlreadyRegistered when another account already uses the new email
     */
    public function changeEmail(string $uid, string $newEmail): void
    {
        try {
            $this->auth->changeUserEmail($uid, $newEmail);
        } catch (EmailExists $e) {
            throw new EmailAlreadyRegistered('email exists', 0, $e);
        }
    }
}
