<?php

declare(strict_types=1);

namespace Faseeh\Firebase;

/**
 * Everything the backend needs from Firebase Authentication.
 *
 * System Architecture: "Firebase Authentication: accounts, sessions, password
 * reset, email change, account deletion." Passwords are handled only by
 * Firebase; nothing in Faseeh stores them (Security NFR, story 39 AC3).
 *
 * Implemented by KreaitAuthGateway (real Firebase) and, in the automated
 * tests, by the InMemoryFirebase test double.
 */
interface AuthGateway
{
    /**
     * @return string the new account's UID
     * @throws EmailAlreadyRegistered
     */
    public function createAccount(string $email, string $password): string;

    /** Deletes the account; all of its sessions become invalid. */
    public function deleteAccount(string $uid): void;

    /**
     * @return string Firebase ID token
     * @throws InvalidCredentials
     * @throws TooManyAttempts
     */
    public function signIn(string $email, string $password): string;

    /** Exchanges an ID token for a Firebase session cookie ("Firebase starts the session", C2a/C2b). */
    public function startSession(string $idToken, int $ttlSeconds): string;

    /**
     * Verifies a session cookie, including expiry and revocation.
     *
     * @return array{uid:string,email:string}
     * @throws InvalidSession
     */
    public function verifySession(string $sessionCookie): array;

    /** Ends the user's Firebase session(s) ("Log out … / Firebase ends session", C2a). */
    public function endSessions(string $uid): void;

    /** Whether an account exists for the email (password recovery only). */
    public function isEmailRegistered(string $email): bool;

    /** Asks Firebase to email a password-reset link to the address. */
    public function sendPasswordResetEmail(string $email): void;

    /**
     * @return string the account e-mail the link belongs to
     * @throws InvalidResetLink
     */
    public function verifyPasswordResetLink(string $oobCode): string;

    /**
     * Sets the new password and consumes the link's code.
     *
     * @throws InvalidResetLink
     */
    public function updatePassword(string $oobCode, string $newPassword): void;

    /**
     * Changes the account's email (Edit Profile, backlog story 5).
     *
     * @throws EmailAlreadyRegistered
     */
    public function changeEmail(string $uid, string $newEmail): void;
}
