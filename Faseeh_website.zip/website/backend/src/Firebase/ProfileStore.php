<?php

declare(strict_types=1);

namespace Faseeh\Firebase;

/**
 * User profiles in Cloud Firestore.
 *
 * Documented: "a user profile is created in Cloud Firestore" right after
 * Firebase creates the account (C2b); Firebase holds "accounts and profiles"
 * in Release 1 (System Architecture, data layer).
 *
 * The collection name is a configuration value (FIRESTORE_USERS_COLLECTION),
 * and the profile holds only the account's email and creation time, keyed by
 * the Firebase UID (see docs/DECISIONS.md D1).
 *
 * Implemented by FirestoreRestProfileStore (real Firestore) and by the
 * InMemoryFirebase test double.
 */
interface ProfileStore
{
    /**
     * @param string|null $createdAt ISO-8601 time; null = now. Given only when restoring a profile.
     * @throws ProfileWriteFailed
     */
    public function createProfile(string $uid, string $email, ?string $createdAt = null): void;

    /**
     * Used to roll back a registration that could not be completed, and by
     * Delete Account (backlog story 6).
     *
     * @throws ProfileWriteFailed
     */
    public function deleteProfile(string $uid): void;

    /**
     * My Account / View Profile (backlog story 5 AC1).
     *
     * @return array{email:string,createdAt:?string}|null
     * @throws ProfileWriteFailed when Firestore cannot be reached
     */
    public function getProfile(string $uid): ?array;

    /**
     * Edit Profile (backlog story 5): keeps the profile's email equal to the account's.
     *
     * @throws ProfileWriteFailed
     */
    public function updateEmail(string $uid, string $email): void;
}
