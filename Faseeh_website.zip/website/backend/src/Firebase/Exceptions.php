<?php

declare(strict_types=1);

namespace Faseeh\Firebase;

use RuntimeException;

/**
 * Domain errors raised by the Firebase gateways. They are independent of the
 * Admin SDK's own exception classes, so the controllers (and the test double)
 * never depend on the SDK. The controllers turn each one into a user message.
 */
class FirebaseGatewayError extends RuntimeException
{
}

/** The email already belongs to an account (registration, email change) → 409. */
final class EmailAlreadyRegistered extends FirebaseGatewayError
{
}

/** Wrong email or password, or a disabled account; deliberately not more specific → 401 / 400. */
final class InvalidCredentials extends FirebaseGatewayError
{
}

/** Firebase is temporarily blocking sign-in attempts for this account → 429. */
final class TooManyAttempts extends FirebaseGatewayError
{
}

/** The session cookie is malformed, expired or revoked → the user is a guest again. */
final class InvalidSession extends FirebaseGatewayError
{
}

/** The password-reset link is unknown, expired or already used → 400. */
final class InvalidResetLink extends FirebaseGatewayError
{
}

/** Firestore refused a profile read or write, or could not be reached → 502. */
final class ProfileWriteFailed extends FirebaseGatewayError
{
}
