<?php

declare(strict_types=1);

namespace Faseeh\Controllers;

use Faseeh\Firebase\AuthGateway;
use Faseeh\Firebase\EmailAlreadyRegistered;
use Faseeh\Firebase\InvalidCredentials;
use Faseeh\Firebase\ProfileStore;
use Faseeh\Firebase\TooManyAttempts;
use Faseeh\Http\ApiException;
use Faseeh\Http\Request;
use Faseeh\Http\Response;
use Faseeh\Session\SessionCookie;
use Faseeh\Validation\AuthValidator as V;
use Throwable;

/**
 * My Account: view the profile, change the email (Edit Profile, backlog 5,
 * Jira FSEEH-49) and delete the account (backlog 6, Jira FSEEH-50).
 *
 * Every operation first calls AuthController::requireUser(), so it runs only
 * for the user of the verified Firebase session; the UID never comes from the
 * request. Changing the email and deleting the account also require the
 * current password (re-authentication).
 */
final class AccountController
{
    /**
     * @param AuthController $authController provides the requireUser() session guard
     * @param AuthGateway    $auth           Firebase Authentication
     * @param ProfileStore   $profiles       Cloud Firestore profiles
     * @param SessionCookie  $cookie         builds the Set-Cookie header
     * @param int            $sessionTtl     session lifetime in seconds
     */
    public function __construct(
        private readonly AuthController $authController,
        private readonly AuthGateway $auth,
        private readonly ProfileStore $profiles,
        private readonly SessionCookie $cookie,
        private readonly int $sessionTtl,
    ) {
    }

    /**
     * GET /api/account: the account email and creation date (Edit Profile AC1, FSEEH-92).
     * Response 200: {profile: {email, createdAt}}.
     */
    public function show(Request $r): Response
    {
        $user = $this->authController->requireUser($r);
        try {
            $profile = $this->profiles->getProfile($user['uid']);
        } catch (Throwable $e) {
            throw $this->failure('profile-read', $e, 'تعذّر تحميل بيانات حسابك الآن. حاول مرة أخرى.');
        }
        return Response::json(['profile' => [
            // The email comes from the verified session (Firebase Authentication is the source of truth).
            'email' => $user['email'],
            'createdAt' => $profile['createdAt'] ?? null,
        ]]);
    }

    /**
     * POST /api/account/email: change the sign-in email (Edit Profile AC3–AC9,
     * FSEEH-93, FSEEH-94, FSEEH-116). Only the email can be edited.
     *
     * Order: validate → confirm the current password → change the email in
     * Firebase Authentication → update the Firestore profile → start a new
     * session. If a later step fails, the earlier ones are undone, so Auth and
     * the profile never disagree (AC9).
     *
     * Request body: {newEmail, currentPassword}
     * Response 200: {user: {uid, email}} and a new session cookie.
     */
    public function changeEmail(Request $r): Response
    {
        $user = $this->authController->requireUser($r);
        $newEmail = trim($r->string('newEmail'));
        $password = $r->string('currentPassword');

        // AC4: empty or invalid email, or a missing current password → field errors, no change.
        $errors = V::collect([
            'newEmail' => V::email($newEmail),
            'currentPassword' => $password === '' ? 'يرجى إدخال كلمة المرور الحالية.' : null,
        ]);
        // AC4: an unchanged email (ignoring letter case) is also rejected.
        if (!isset($errors['newEmail']) && strcasecmp($newEmail, $user['email']) === 0) {
            $errors['newEmail'] = 'هذا هو بريدك الإلكتروني الحالي.';
        }
        if ($errors !== []) {
            throw ApiException::validation($errors);
        }

        // AC5: a wrong current password stops here, before anything changes.
        $this->confirmPassword($user['email'], $password);

        try {
            $this->auth->changeEmail($user['uid'], $newEmail);
        } catch (EmailAlreadyRegistered) {
            // AC6: the email belongs to another account.
            throw new ApiException(409, 'email_in_use', 'هذا البريد الإلكتروني مسجّل لحساب آخر.', [
                'newEmail' => 'هذا البريد مسجّل لحساب آخر.',
            ]);
        } catch (Throwable $e) {
            throw $this->failure('email-change', $e, 'تعذّر تغيير البريد الإلكتروني الآن. لم يتغيّر شيء، حاول مرة أخرى.');
        }

        try {
            $this->profiles->updateEmail($user['uid'], $newEmail);
            // The current session cookie still carries the old email, so start a fresh one.
            $session = $this->auth->startSession($this->auth->signIn($newEmail, $password), $this->sessionTtl);
        } catch (Throwable $e) {
            // AC9: put the old email back in Firebase Authentication and the profile.
            try {
                $this->auth->changeEmail($user['uid'], $user['email']);
                $this->profiles->updateEmail($user['uid'], $user['email']);
            } catch (Throwable $undo) {
                error_log('[faseeh] could not restore e-mail for ' . $user['uid'] . ': ' . $undo->getMessage());
            }
            throw $this->failure('email-change-finish', $e, 'تعذّر تغيير البريد الإلكتروني الآن. لم يتغيّر شيء، حاول مرة أخرى.');
        }

        // AC7: the browser updates the email on the page and in the header from this response.
        return Response::json(['user' => ['uid' => $user['uid'], 'email' => $newEmail]])
            ->withCookie($this->cookie->set($session, $this->sessionTtl));
    }

    /**
     * POST /api/account/delete: Delete Account (backlog 6, FSEEH-95 – FSEEH-97).
     *
     * Order: confirm the current password → delete the Firestore profile →
     * delete the Firebase Authentication account (which also invalidates every
     * session) → delete the cookie. If the account deletion fails, the profile is
     * restored, so nothing is half-deleted (AC8).
     *
     * Release 1 scope: the account and its profile are the only stored data.
     * Deleting saved records and anonymising ratings and feedback (AC5) are
     * Release 2 (stories 15 and 21) and join this operation when those exist.
     *
     * Request body: {currentPassword}. Response 200: {ok: true} and a cookie deletion.
     */
    public function delete(Request $r): Response
    {
        $user = $this->authController->requireUser($r);
        $password = $r->string('currentPassword');
        // AC4: a missing password deletes nothing.
        if ($password === '') {
            throw ApiException::validation(['currentPassword' => 'يرجى إدخال كلمة المرور لتأكيد حذف الحساب.']);
        }
        // AC4: a wrong password deletes nothing.
        $this->confirmPassword($user['email'], $password);

        try {
            // Keep a copy so the profile can be restored if the next step fails.
            $profile = $this->profiles->getProfile($user['uid']);
            $this->profiles->deleteProfile($user['uid']);
        } catch (Throwable $e) {
            throw $this->failure('account-delete-profile', $e, 'تعذّر حذف الحساب الآن. لم يُحذف شيء، حاول مرة أخرى.');
        }

        try {
            $this->auth->deleteAccount($user['uid']);
        } catch (Throwable $e) {
            // AC8: no partial deletion, so put the profile back.
            if ($profile !== null) {
                try {
                    $this->profiles->createProfile($user['uid'], $profile['email'], $profile['createdAt']);
                } catch (Throwable $undo) {
                    error_log('[faseeh] could not restore profile for ' . $user['uid'] . ': ' . $undo->getMessage());
                }
            }
            throw $this->failure('account-delete', $e, 'تعذّر حذف الحساب الآن. لم يُحذف شيء، حاول مرة أخرى.');
        }

        // AC6: the session ends; the browser shows the confirmation on the home page.
        return Response::json(['ok' => true])->withCookie($this->cookie->clear());
    }

    /**
     * Re-authentication: checks that $password is the current password of the
     * signed-in account by signing in with it (the result is discarded).
     *
     * @throws ApiException 400 with a field error under the password field when it is wrong
     */
    private function confirmPassword(string $email, string $password): void
    {
        try {
            $this->auth->signIn($email, $password);
        } catch (InvalidCredentials) {
            // 400 (not 401): the session is valid, only the typed password is wrong.
            throw new ApiException(400, 'validation', 'كلمة المرور الحالية غير صحيحة.', [
                'currentPassword' => 'كلمة المرور الحالية غير صحيحة.',
            ]);
        } catch (TooManyAttempts) {
            throw new ApiException(429, 'too_many_attempts', 'محاولات كثيرة خلال وقت قصير. انتظر قليلًا ثم حاول مجددًا.');
        } catch (Throwable $e) {
            throw $this->failure('reauth', $e, 'تعذّر التحقق من كلمة المرور الآن. حاول مرة أخرى.');
        }
    }

    /** Logs an unexpected failure and returns a 502 with a safe Arabic message. */
    private function failure(string $where, Throwable $e, string $message): ApiException
    {
        error_log("[faseeh] {$where} failed: " . get_class($e) . ': ' . $e->getMessage());
        return new ApiException(502, 'service_error', $message);
    }
}
