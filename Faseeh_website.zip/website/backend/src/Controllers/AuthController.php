<?php

declare(strict_types=1);

namespace Faseeh\Controllers;

use Faseeh\Firebase\AuthGateway;
use Faseeh\Firebase\EmailAlreadyRegistered;
use Faseeh\Firebase\InvalidCredentials;
use Faseeh\Firebase\InvalidResetLink;
use Faseeh\Firebase\InvalidSession;
use Faseeh\Firebase\ProfileStore;
use Faseeh\Firebase\ProfileWriteFailed;
use Faseeh\Firebase\TooManyAttempts;
use Faseeh\Http\ApiException;
use Faseeh\Http\Request;
use Faseeh\Http\Response;
use Faseeh\Session\SessionCookie;
use Faseeh\Validation\AuthValidator as V;
use Throwable;

/**
 * DFD process 1.0 "Manage User Authentication and Account": sign up, log in,
 * log out, session state and password recovery, following the C2a state
 * diagram (Guest ↔ Signing Up / Signing In / Recovering Password ↔ Authenticated)
 * and the C2b activity diagram.
 *
 * Every method receives the parsed HTTP request and returns a JSON Response.
 * Errors are thrown as ApiException; App::handle() turns them into JSON.
 */
final class AuthController
{
    /**
     * @param AuthGateway   $auth       Firebase Authentication (real or test double)
     * @param ProfileStore  $profiles   Cloud Firestore profiles (real or test double)
     * @param SessionCookie $cookie     builds the Set-Cookie header for the session
     * @param int           $sessionTtl session lifetime in seconds (SESSION_TTL_SECONDS)
     */
    public function __construct(
        private readonly AuthGateway $auth,
        private readonly ProfileStore $profiles,
        private readonly SessionCookie $cookie,
        private readonly int $sessionTtl,
    ) {
    }

    /**
     * POST /api/auth/register: Create an Account (backlog 1, Jira FSEEH-6).
     *
     * C2b sign-up flow: validate the input → Firebase checks the email is not
     * registered and creates the account → create the Firestore profile →
     * Firebase starts the session → the browser goes to the home page.
     *
     * Request body: {email, password, confirm}
     * Response 201: {user: {uid, email}} and a Set-Cookie with the session.
     */
    public function register(Request $r): Response
    {
        $email = trim($r->string('email'));
        $password = $r->string('password');
        $confirm = $r->string('confirm');

        // Server-side validation (FSEEH-78). The browser checks the same rules, but
        // the server never trusts the browser.
        $errors = V::collect([
            'email' => V::email($email),
            'password' => V::password($password),
            'confirm' => V::confirm($password, $confirm),
        ]);
        if ($errors !== []) {
            throw ApiException::validation($errors); // AC2–AC4: nothing is created
        }

        try {
            $uid = $this->auth->createAccount($email, $password);
        } catch (EmailAlreadyRegistered) {
            // AC5 and C2a "[invalid data or email in use] / display error and retry".
            throw new ApiException(409, 'email_in_use', 'هذا البريد الإلكتروني مسجّل مسبقًا.', [
                'email' => 'هذا البريد مسجّل مسبقًا. جرّب تسجيل الدخول أو استعادة كلمة المرور.',
            ]);
        } catch (Throwable $e) {
            throw $this->failure('register', $e, 'تعذّر إنشاء الحساب الآن. لم يُنشأ أي حساب، حاول مرة أخرى.');
        }

        // From here the Firebase account exists. If any later step fails, it is
        // removed again, so registration is all-or-nothing (AC6 "one account", AC7).
        $profileCreated = false;
        try {
            $this->profiles->createProfile($uid, $email);
            $profileCreated = true;
            // Sign in with the new credentials to get an ID token, then exchange it for a session cookie.
            $idToken = $this->auth->signIn($email, $password);
            $session = $this->auth->startSession($idToken, $this->sessionTtl);
        } catch (Throwable $e) {
            try {
                if ($profileCreated) {
                    $this->profiles->deleteProfile($uid);
                }
                $this->auth->deleteAccount($uid);
            } catch (Throwable $cleanup) {
                // Logged for the operator; the user still sees a clear failure message below.
                error_log('[faseeh] could not roll back account ' . $uid . ': ' . $cleanup->getMessage());
            }
            $msg = $e instanceof ProfileWriteFailed
                ? 'تعذّر إنشاء ملف المستخدم، لذلك لم يُنشأ الحساب. حاول مرة أخرى.'
                : 'تعذّر إكمال إنشاء الحساب. لم يُنشأ أي حساب، حاول مرة أخرى.';
            throw $this->failure('register-finish', $e, $msg);
        }

        // Success: the user is signed in immediately (C2a Signing Up → Authenticated).
        return Response::json(['user' => ['uid' => $uid, 'email' => $email]], 201)
            ->withCookie($this->cookie->set($session, $this->sessionTtl));
    }

    /**
     * POST /api/auth/login: Log In (backlog 2, Jira FSEEH-7).
     *
     * C2b sign-in flow: Firebase checks the credentials → on success Firebase
     * starts the session (FSEEH-82); otherwise one general error (FSEEH-83).
     *
     * Request body: {email, password}
     * Response 200: {user: {uid, email}} and a Set-Cookie with the session.
     */
    public function login(Request $r): Response
    {
        $email = trim($r->string('email'));
        $password = $r->string('password');
        // AC2: both fields are required. The password policy is not checked here,
        // so the error never hints at what a valid password looks like.
        $errors = V::collect([
            'email' => $email === '' ? 'يرجى إدخال البريد الإلكتروني.' : null,
            'password' => $password === '' ? 'يرجى إدخال كلمة المرور.' : null,
        ]);
        if ($errors !== []) {
            throw ApiException::validation($errors);
        }

        try {
            $idToken = $this->auth->signIn($email, $password);
            $session = $this->auth->startSession($idToken, $this->sessionTtl);
            // Read the user back from the new session, exactly as later requests will.
            $user = $this->auth->verifySession($session);
        } catch (InvalidCredentials) {
            // AC4: the same message for a wrong password and an unknown email.
            throw new ApiException(401, 'invalid_credentials', 'البريد الإلكتروني أو كلمة المرور غير صحيحة.');
        } catch (TooManyAttempts) {
            throw new ApiException(429, 'too_many_attempts', 'محاولات كثيرة خلال وقت قصير. انتظر قليلًا ثم حاول مجددًا.');
        } catch (Throwable $e) {
            throw $this->failure('login', $e, 'تعذّر تسجيل الدخول الآن. حاول مرة أخرى.');
        }

        return Response::json(['user' => $user])
            ->withCookie($this->cookie->set($session, $this->sessionTtl));
    }

    /**
     * POST /api/auth/logout: Log Out (backlog 4, Jira FSEEH-12 / FSEEH-90).
     *
     * Revokes the user's Firebase sessions, then deletes the cookie, so a copied
     * cookie cannot be reused. Account and profile are untouched (AC3).
     * Always answers 200: logging out an already-ended session is not an error.
     */
    public function logout(Request $r): Response
    {
        $value = $r->cookies[$this->cookie->name()] ?? '';
        if ($value !== '') {
            try {
                $user = $this->auth->verifySession($value);
                $this->auth->endSessions($user['uid']);
            } catch (InvalidSession) {
                // already expired or revoked: nothing to end
            } catch (Throwable $e) {
                // Firebase unreachable: the cookie is still deleted below, and the
                // Firebase session expires on its own at the end of its lifetime.
                error_log('[faseeh] logout revoke failed: ' . $e->getMessage());
            }
        }
        return Response::json(['ok' => true])->withCookie($this->cookie->clear());
    }

    /**
     * GET /api/auth/session: the current C2a state for the interface.
     *
     * Response: {user: null} for a guest; {user: {uid, email}} when signed in;
     * {user: null, expired: true} plus a cookie deletion when the cookie was
     * expired or revoked (FSEEH-113: the interface then returns to Guest).
     */
    public function session(Request $r): Response
    {
        $value = $r->cookies[$this->cookie->name()] ?? '';
        if ($value === '') {
            return Response::json(['user' => null]);
        }
        try {
            return Response::json(['user' => $this->auth->verifySession($value)]);
        } catch (InvalidSession) {
            return Response::json(['user' => null, 'expired' => true])->withCookie($this->cookie->clear());
        }
    }

    /**
     * POST /api/auth/password-reset/request: Recover a Forgotten Password,
     * first step (backlog 3, Jira FSEEH-26 / FSEEH-85, FSEEH-86).
     *
     * C2b: email format valid? → email registered? → No: "no account is associated
     * with this email" (AC4, no email is sent); Yes: Firebase sends the reset link.
     *
     * Request body: {email}. Response 200: {ok: true}.
     */
    public function requestPasswordReset(Request $r): Response
    {
        $email = trim($r->string('email'));
        $err = V::email($email);
        if ($err !== null) {
            throw ApiException::validation(['email' => $err], $err);
        }
        try {
            $registered = $this->auth->isEmailRegistered($email);
        } catch (Throwable $e) {
            throw $this->failure('reset-lookup', $e, 'تعذّر التحقق من البريد الآن. حاول مرة أخرى.');
        }
        if (!$registered) {
            throw new ApiException(404, 'email_not_registered', 'لا يوجد حساب مرتبط بهذا البريد الإلكتروني.', [
                'email' => 'لا يوجد حساب مرتبط بهذا البريد الإلكتروني.',
            ]);
        }
        try {
            $this->auth->sendPasswordResetEmail($email);
        } catch (Throwable $e) {
            throw $this->failure('reset-send', $e, 'تعذّر إرسال رابط الاستعادة الآن. حاول مرة أخرى.');
        }
        return Response::json(['ok' => true]);
    }

    /**
     * POST /api/auth/password-reset/verify: C2b "is the link valid (not expired
     * or used)?" (AC7, FSEEH-88). Called when the reset page opens.
     *
     * Request body: {oobCode}. Response 200: {email}, the account the link is for.
     */
    public function verifyPasswordReset(Request $r): Response
    {
        $code = $r->string('oobCode');
        if ($code === '') {
            throw $this->invalidLink();
        }
        try {
            $email = $this->auth->verifyPasswordResetLink($code);
        } catch (InvalidResetLink) {
            throw $this->invalidLink();
        }
        return Response::json(['email' => $email]);
    }

    /**
     * POST /api/auth/password-reset/confirm: set the new password (AC5–AC8, FSEEH-87).
     *
     * C2b: new password meets the policy and matches? → Firebase updates the
     * password → the browser goes to the sign-in page. Firebase consumes the
     * code (the link cannot be reused) and ends sessions opened with the old password.
     *
     * Request body: {oobCode, password, confirm}. Response 200: {ok: true}.
     */
    public function confirmPasswordReset(Request $r): Response
    {
        $code = $r->string('oobCode');
        $password = $r->string('password');
        $confirm = $r->string('confirm');
        if ($code === '') {
            throw $this->invalidLink();
        }
        $errors = V::collect([
            'password' => V::password($password),
            'confirm' => V::confirm($password, $confirm),
        ]);
        if ($errors !== []) {
            throw ApiException::validation($errors);
        }
        try {
            $this->auth->updatePassword($code, $password);
        } catch (InvalidResetLink) {
            throw $this->invalidLink();
        } catch (Throwable $e) {
            throw $this->failure('reset-confirm', $e, 'تعذّر تغيير كلمة المرور الآن. حاول مرة أخرى.');
        }
        return Response::json(['ok' => true]);
    }

    /**
     * Guard used by every protected endpoint (Log In AC5–AC6, FSEEH-84).
     *
     * The user identity always comes from the verified Firebase session cookie,
     * never from the request body, so one user cannot act on another's account.
     *
     * @return array{uid:string,email:string} the signed-in user
     * @throws ApiException 401 "unauthorized" without a cookie, 401 "session_expired"
     *                      when the cookie is expired or revoked
     */
    public function requireUser(Request $r): array
    {
        $value = $r->cookies[$this->cookie->name()] ?? '';
        if ($value === '') {
            throw ApiException::unauthorized();
        }
        try {
            return $this->auth->verifySession($value);
        } catch (InvalidSession) {
            throw new ApiException(401, 'session_expired', 'انتهت جلستك. سجّل الدخول مرة أخرى.');
        }
    }

    /** The single message for an unknown, expired or already used reset link. */
    private function invalidLink(): ApiException
    {
        return new ApiException(400, 'invalid_reset_link', 'رابط الاستعادة غير صالح أو انتهت صلاحيته أو سبق استخدامه. اطلب رابطًا جديدًا.');
    }

    /**
     * Turns an unexpected Firebase or network failure into a 502 with a safe
     * Arabic message. The technical detail goes only to the server log.
     */
    private function failure(string $where, Throwable $e, string $message): ApiException
    {
        error_log("[faseeh] {$where} failed: " . get_class($e) . ': ' . $e->getMessage());
        return new ApiException(502, 'service_error', $message);
    }
}
