<?php

declare(strict_types=1);

namespace Faseeh\Session;

/**
 * Builds the Set-Cookie header that stores the Firebase session cookie in the browser.
 *
 * Security flags:
 *  - HttpOnly: page scripts cannot read the cookie, so injected script cannot steal it.
 *  - SameSite=Lax: the browser does not send it with cross-site form posts.
 *  - Secure (production only): sent over HTTPS only. Local development runs on
 *    plain http://localhost, where a Secure cookie would never be sent.
 *  - Max-Age equals the Firebase session lifetime, so the browser forgets the
 *    cookie at the same moment Firebase stops accepting it.
 */
final class SessionCookie
{
    /**
     * @param string $name   cookie name (SESSION_COOKIE_NAME, default "faseeh_session")
     * @param bool   $secure true in production (APP_ENV=production) to add the Secure flag
     */
    public function __construct(
        private readonly string $name,
        private readonly bool $secure,
    ) {
    }

    /** The cookie name, used by the controllers to read the incoming cookie. */
    public function name(): string
    {
        return $this->name;
    }

    /**
     * Header value that stores a new session (after sign-up, login or email change).
     *
     * @param string $value      the Firebase session cookie
     * @param int    $ttlSeconds how long the browser keeps it
     */
    public function set(string $value, int $ttlSeconds): string
    {
        return $this->build($value, $ttlSeconds);
    }

    /** Header value that deletes the cookie (logout, expired session, deleted account). */
    public function clear(): string
    {
        return $this->build('', -1);
    }

    /** Assembles the Set-Cookie value; a negative TTL produces an already-expired cookie. */
    private function build(string $value, int $ttl): string
    {
        $parts = [
            $this->name . '=' . rawurlencode($value),
            'Path=/',
            'HttpOnly',
            'SameSite=Lax',
        ];
        if ($ttl < 0) {
            // Max-Age=0 plus a date in the past: every browser deletes the cookie immediately.
            $parts[] = 'Max-Age=0';
            $parts[] = 'Expires=Thu, 01 Jan 1970 00:00:00 GMT';
        } else {
            $parts[] = 'Max-Age=' . $ttl;
        }
        if ($this->secure) {
            $parts[] = 'Secure';
        }
        return implode('; ', $parts);
    }
}
