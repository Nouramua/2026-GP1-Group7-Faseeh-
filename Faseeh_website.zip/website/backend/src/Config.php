<?php

declare(strict_types=1);

namespace Faseeh;

use RuntimeException;

/**
 * Backend configuration, read from environment variables (optionally a `.env`
 * file next to composer.json). No secret is ever hard-coded: the service-account
 * key is referenced by file path only, and that file lives outside the project.
 */
final class Config
{
    /**
     * @param string      $appEnv                  "production" adds the Secure cookie flag (APP_ENV)
     * @param string      $appUrl                  address of the website, used by the cross-site check (APP_URL)
     * @param string      $firebaseProjectId       Firebase project ID (FIREBASE_PROJECT_ID)
     * @param string|null $firebaseCredentialsPath path to the service-account JSON file (FIREBASE_CREDENTIALS)
     * @param string      $firestoreDatabaseId     Firestore database ID, normally "(default)"
     * @param string      $usersCollection         Firestore collection holding the profiles
     * @param int         $sessionTtlSeconds       session lifetime (Firebase allows 300 – 1,209,600 s)
     * @param string      $sessionCookieName       browser cookie name
     * @param string|null $authEmulatorHost        Firebase Auth emulator, local tests only
     * @param string|null $firestoreEmulatorHost   Firestore emulator, local tests only
     * @param string|null $frontendDist            folder of the built website served by index.php
     */
    public function __construct(
        public readonly string $appEnv,
        public readonly string $appUrl,
        public readonly string $firebaseProjectId,
        public readonly ?string $firebaseCredentialsPath,
        public readonly string $firestoreDatabaseId,
        public readonly string $usersCollection,
        public readonly int $sessionTtlSeconds,
        public readonly string $sessionCookieName,
        public readonly ?string $authEmulatorHost,
        public readonly ?string $firestoreEmulatorHost,
        public readonly ?string $frontendDist,
    ) {
    }

    /**
     * Reads and validates the configuration. The server refuses to start (the
     * front controller answers 500 "server not configured") rather than run
     * with a missing or unsafe value.
     *
     * @param string|null $envFile optional .env file; real environment variables take precedence
     * @throws RuntimeException naming the missing or invalid setting (never its value)
     */
    public static function fromEnvironment(?string $envFile = null): self
    {
        if ($envFile !== null && is_file($envFile)) {
            self::loadEnvFile($envFile);
        }

        $authEmulator = self::optional('FIREBASE_AUTH_EMULATOR_HOST');
        $credentials = self::optional('FIREBASE_CREDENTIALS');
        // Real Firebase needs the service-account file; only an emulator setup may run without it.
        if ($credentials === null && $authEmulator === null) {
            throw new RuntimeException('FIREBASE_CREDENTIALS is not set (path to the service-account JSON file). See docs/FIREBASE_SETUP.md.');
        }
        if ($credentials !== null && !is_readable($credentials)) {
            throw new RuntimeException('FIREBASE_CREDENTIALS points to a file that cannot be read.');
        }

        $ttl = (int) self::required('SESSION_TTL_SECONDS');
        // Firebase session cookies must last between 5 minutes and 2 weeks.
        if ($ttl < 300 || $ttl > 1_209_600) {
            throw new RuntimeException('SESSION_TTL_SECONDS must be between 300 (5 minutes) and 1209600 (14 days).');
        }

        return new self(
            appEnv: self::optional('APP_ENV') ?? 'development',
            appUrl: rtrim(self::required('APP_URL'), '/'),
            firebaseProjectId: self::required('FIREBASE_PROJECT_ID'),
            firebaseCredentialsPath: $credentials,
            firestoreDatabaseId: self::optional('FIRESTORE_DATABASE_ID') ?? '(default)',
            usersCollection: self::required('FIRESTORE_USERS_COLLECTION'),
            sessionTtlSeconds: $ttl,
            sessionCookieName: self::optional('SESSION_COOKIE_NAME') ?? 'faseeh_session',
            authEmulatorHost: $authEmulator,
            firestoreEmulatorHost: self::optional('FIRESTORE_EMULATOR_HOST'),
            frontendDist: self::optional('FRONTEND_DIST'),
        );
    }

    /** True when APP_ENV is "production" (HTTPS deployment). */
    public function isProduction(): bool
    {
        return $this->appEnv === 'production';
    }

    /** Reads a setting that must be present; throws naming the setting otherwise. */
    private static function required(string $key): string
    {
        $v = self::optional($key);
        if ($v === null) {
            throw new RuntimeException("Missing required configuration value: {$key}. See backend/.env.example.");
        }
        return $v;
    }

    /** Reads a setting; an unset or blank value counts as absent (null). */
    private static function optional(string $key): ?string
    {
        $v = getenv($key);
        if ($v === false || trim($v) === '') {
            return null;
        }
        return trim($v);
    }

    /**
     * Minimal .env reader: KEY=value lines, # comments, optional quotes.
     * Values are put into the process environment only if not already set.
     */
    private static function loadEnvFile(string $file): void
    {
        foreach (file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [] as $line) {
            $line = trim($line);
            // Skip blank lines, comments and lines without "=".
            if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) {
                continue;
            }
            [$k, $v] = array_map('trim', explode('=', $line, 2));
            $v = trim($v, "\"'");
            if (getenv($k) === false) { // real environment wins over the file
                putenv("{$k}={$v}");
            }
        }
    }
}
