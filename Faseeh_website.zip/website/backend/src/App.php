<?php

declare(strict_types=1);

namespace Faseeh;

use Faseeh\Controllers\AccountController;
use Faseeh\Controllers\AuthController;
use Faseeh\Firebase\AuthGateway;
use Faseeh\Firebase\FirestoreRestProfileStore;
use Faseeh\Firebase\KreaitAuthGateway;
use Faseeh\Firebase\ProfileStore;
use Faseeh\Http\ApiException;
use Faseeh\Http\Request;
use Faseeh\Http\Response;
use Faseeh\Session\SessionCookie;
use GuzzleHttp\Client;
use Kreait\Firebase\Factory;
use Throwable;

/**
 * The application layer's PHP backend in the System Architecture diagram:
 * "handles requests and verifies the user's Firebase session".
 *
 * Release 1 exposes only the authentication and account routes below. The
 * analysis, simplification, saving, history, rating, statistics and download
 * routes belong to Release 2 (Sprint 4) and do not exist yet.
 */
final class App
{
    private readonly AuthController $authController;
    private readonly AccountController $accountController;

    /**
     * Wires the controllers together. The Firebase dependencies are passed in,
     * so the same App runs with the real Firebase (App::create) or with the
     * in-memory test double used by the automated tests.
     *
     * @param Config       $config   validated configuration
     * @param AuthGateway  $auth     Firebase Authentication access
     * @param ProfileStore $profiles Cloud Firestore profile access
     */
    public function __construct(
        private readonly Config $config,
        AuthGateway $auth,
        ProfileStore $profiles,
    ) {
        // The Secure cookie flag is added only in production (HTTPS).
        $cookie = new SessionCookie($config->sessionCookieName, $config->isProduction());
        $this->authController = new AuthController($auth, $profiles, $cookie, $config->sessionTtlSeconds);
        $this->accountController = new AccountController($this->authController, $auth, $profiles, $cookie, $config->sessionTtlSeconds);
    }

    /**
     * Builds the App with the REAL Firebase services (used by public/index.php).
     *
     * The Admin SDK factory is authorised with the service-account JSON file
     * named by FIREBASE_CREDENTIALS. The file stays on the server and is never
     * sent to the browser or committed to the repository.
     */
    public static function create(Config $config): self
    {
        // Local testing only: point the Admin SDK at the Firebase Auth emulator.
        if ($config->authEmulatorHost !== null) {
            putenv('FIREBASE_AUTH_EMULATOR_HOST=' . $config->authEmulatorHost);
        }
        $factory = (new Factory())->withProjectId($config->firebaseProjectId);
        if ($config->firebaseCredentialsPath !== null) {
            $factory = $factory->withServiceAccount($config->firebaseCredentialsPath);
        }
        // Firebase Authentication through the Admin SDK; Firestore through its REST API (see FirestoreRestProfileStore).
        $auth = new KreaitAuthGateway($factory->createAuth());
        $profiles = new FirestoreRestProfileStore(
            new Client(),
            $config->firebaseProjectId,
            $config->firestoreDatabaseId,
            $config->usersCollection,
            $config->firebaseCredentialsPath,
            $config->firestoreEmulatorHost,
        );
        return new self($config, $auth, $profiles);
    }

    /** Exposes the session guard to the unit tests (AuthFlowTest). */
    public function auth(): AuthController
    {
        return $this->authController;
    }

    /**
     * Routes one request to its controller and always returns a JSON Response.
     *
     * Expected errors (ApiException) become their own status and message.
     * Anything unexpected is logged on the server and answered with a generic
     * 500, so internal details never reach the browser.
     */
    public function handle(Request $r): Response
    {
        try {
            $this->guardCrossSite($r);
            // The route table: [HTTP method, path] → controller method.
            return match ([$r->method, $r->path]) {
                ['GET', '/api/health'] => Response::json(['ok' => true]),
                ['GET', '/api/auth/session'] => $this->authController->session($r),
                ['POST', '/api/auth/register'] => $this->authController->register($r),
                ['POST', '/api/auth/login'] => $this->authController->login($r),
                ['POST', '/api/auth/logout'] => $this->authController->logout($r),
                ['POST', '/api/auth/password-reset/request'] => $this->authController->requestPasswordReset($r),
                ['POST', '/api/auth/password-reset/verify'] => $this->authController->verifyPasswordReset($r),
                ['POST', '/api/auth/password-reset/confirm'] => $this->authController->confirmPasswordReset($r),
                ['GET', '/api/account'] => $this->accountController->show($r),
                ['POST', '/api/account/email'] => $this->accountController->changeEmail($r),
                ['POST', '/api/account/delete'] => $this->accountController->delete($r),
                default => throw new ApiException(404, 'not_found', 'المسار غير موجود.'),
            };
        } catch (ApiException $e) {
            return Response::fromException($e);
        } catch (Throwable $e) {
            error_log('[faseeh] unhandled: ' . get_class($e) . ': ' . $e->getMessage());
            return Response::fromException(new ApiException(500, 'internal', 'حدث خطأ غير متوقع في الخادم. حاول مرة أخرى.'));
        }
    }

    /**
     * The session lives in a cookie, so state-changing requests must come from
     * Faseeh's own pages: JSON bodies only (cross-site forms cannot send them
     * without a CORS preflight) and, when the browser sends one, a matching Origin.
     */
    private function guardCrossSite(Request $r): void
    {
        // GET requests change nothing, so only POST requests are checked.
        if ($r->method !== 'POST') {
            return;
        }
        $ct = $r->header('content-type') ?? '';
        if (!str_starts_with(strtolower($ct), 'application/json')) {
            throw new ApiException(415, 'unsupported_media_type', 'يجب إرسال الطلب بصيغة JSON.');
        }
        // Request::fromGlobals() marks a body that is not valid JSON.
        if (isset($r->body['__invalid_json'])) {
            throw new ApiException(400, 'validation', 'صيغة الطلب غير صحيحة.');
        }
        // Accept the configured site address, or a same-host origin (the Vite dev
        // server proxies /api, so the Origin and Host then match).
        $origin = $r->header('origin');
        if ($origin !== null && rtrim($origin, '/') !== $this->config->appUrl) {
            $host = $r->header('host');
            $parsed = parse_url($origin);
            $originHost = ($parsed['host'] ?? '') . (isset($parsed['port']) ? ':' . $parsed['port'] : '');
            if ($host === null || $originHost !== $host) {
                throw new ApiException(403, 'forbidden', 'مصدر الطلب غير مسموح.');
            }
        }
    }
}
