# Faseeh website — Release 1

This folder contains **all the code and documentation for the Faseeh web platform** (Release 1):

| Folder / file | Contents |
|---|---|
| `frontend/` | React + TypeScript website (Vite) |
| `backend/` | PHP backend with Firebase Authentication and Cloud Firestore, plus its tests |
| `firestore.rules` | Firestore security rules |
| `docs/` | Website documentation: Firebase implementation, code implementation, audit, verification, setup and testing guides, site map |

The research work (notebooks, datasets, models) is outside this folder, at the repository root.

**How to install, configure Firebase, run and test the website:** see the main [README](../README.md), sections 2–6. All of its website commands are run inside this `website/` folder.
