import type {
  AccountProfile,
  AnalysisResult,
  AnyResult,
  AppConfig,
  HistoryItem,
  PublicUser,
  Rating,
  RatingIssue,
  SimplificationResult,
  UsageStats,
} from "../../shared/api";
import type { Level } from "../../shared/levels";

/**
 * Account and session operations. Real in Release 1 (PHP backend + Firebase
 * Authentication and Cloud Firestore); implemented by services/http.ts.
 */
export interface AuthService {
  session(): Promise<{ user: PublicUser | null; expired?: boolean }>;
  register(email: string, password: string, confirm: string): Promise<{ user: PublicUser }>;
  login(email: string, password: string): Promise<{ user: PublicUser }>;
  logout(): Promise<{ ok: true }>;
  requestPasswordReset(email: string): Promise<{ ok: true }>;
  verifyPasswordReset(oobCode: string): Promise<{ email: string }>;
  confirmPasswordReset(oobCode: string, password: string, confirm: string): Promise<{ ok: true }>;
  /** My Account, Edit Profile and Delete Account (backlog stories 5 and 6). */
  account(): Promise<{ profile: AccountProfile }>;
  changeEmail(newEmail: string, currentPassword: string): Promise<{ user: PublicUser }>;
  deleteAccount(currentPassword: string): Promise<{ ok: true }>;
}

/**
 * Model-dependent and record-keeping operations (Release 2, Sprints 3–4).
 * In Release 1, `config`, `analyze` and `simplify` are design demonstrations
 * with labelled sample data (services/demo), and the rest reject with
 * "available in Release 2" (lib/api.ts). The full interface is kept so the
 * Release 2 implementation can replace the demonstration without changing pages.
 */
export interface FeatureService {
  config(): Promise<AppConfig>;
  analyze(text: string, signal?: AbortSignal): Promise<AnalysisResult>;
  simplify(text: string, targetLevel: Level, analysisId: string | null, signal?: AbortSignal): Promise<SimplificationResult>;
  save(id: string): Promise<{ ok: true; alreadySaved: boolean }>;
  rate(id: string, stars: number, issues: RatingIssue[], comment: string): Promise<Rating>;
  history(): Promise<{ items: HistoryItem[] }>;
  historyItem(id: string): Promise<AnyResult>;
  deleteHistory(id: string): Promise<{ ok: true }>;
  stats(): Promise<UsageStats>;
}

export type FaseehService = AuthService & FeatureService;
