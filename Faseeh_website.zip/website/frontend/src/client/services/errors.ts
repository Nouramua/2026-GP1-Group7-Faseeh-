import type { ApiErrorCode } from "../../shared/api";

/** Error type every service implementation throws, so the UI handles demo and live failures identically. */
export class ApiRequestError extends Error {
  constructor(
    public code: ApiErrorCode | "network",
    message: string,
    public status: number,
    public fields: Record<string, string> = {},
  ) {
    super(message);
  }
}
