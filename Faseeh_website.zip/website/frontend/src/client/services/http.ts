import type { AccountProfile, ApiError, PublicUser } from "../../shared/api";
import { ApiRequestError } from "./errors";
import type { AuthService } from "./types";

/**
 * Sends one JSON request to the PHP backend and returns the decoded response.
 *
 * - All URLs are relative ("/api/..."), so the browser only ever talks to
 *   Faseeh's own origin. It never talks to Firebase directly.
 * - The Firebase session travels in an HttpOnly cookie that the browser
 *   attaches automatically (`credentials: "same-origin"`); this code never
 *   sees or stores the session itself.
 * - Any non-2xx answer becomes an ApiRequestError carrying the backend's
 *   error code, Arabic message, HTTP status and per-field messages.
 *
 * @param method HTTP method
 * @param url    path after "/api", e.g. "/auth/login"
 * @param body   object sent as JSON (omitted for GET)
 * @param signal lets the caller cancel the request
 */
export async function request<T>(method: string, url: string, body?: unknown, signal?: AbortSignal): Promise<T> {
  let res: Response;
  try {
    res = await fetch(`/api${url}`, {
      method,
      credentials: "same-origin",
      // JSON content type is required by the backend's cross-site guard for every POST.
      headers: body !== undefined ? { "Content-Type": "application/json" } : undefined,
      body: body !== undefined ? JSON.stringify(body) : undefined,
      signal,
    });
  } catch (e) {
    // A cancelled request is not an error to show; let the caller ignore it.
    if ((e as Error).name === "AbortError") throw e;
    // The request never reached the server (offline, server down).
    throw new ApiRequestError("network", "تعذّر الاتصال بالخادم. تحقّق من اتصالك ثم أعد المحاولة.", 0);
  }
  // Read as text first so an empty or non-JSON body cannot crash the page.
  const text = await res.text();
  let data: unknown = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = null;
  }
  if (!res.ok) {
    // The backend's error format: {error, message, fields?} (see Response::fromException).
    const err = (data ?? {}) as Partial<ApiError>;
    throw new ApiRequestError(err.error ?? "internal", err.message ?? "حدث خطأ غير متوقع. حاول مرة أخرى.", res.status, err.fields ?? {});
  }
  return data as T;
}

/**
 * Real account operations (Release 1): each one maps to one PHP endpoint,
 * which in turn calls Firebase Authentication and Cloud Firestore.
 */
export const authService: AuthService = {
  /** Current state: {user} when signed in, {user: null, expired?: true} otherwise. */
  session: () => request<{ user: PublicUser | null; expired?: boolean }>("GET", "/auth/session"),
  /** Create an Account (FSEEH-6): sets the session cookie on success. */
  register: (email, password, confirm) => request("POST", "/auth/register", { email, password, confirm }),
  /** Log In (FSEEH-7): sets the session cookie on success. */
  login: (email, password) => request("POST", "/auth/login", { email, password }),
  /** Log Out (FSEEH-12): revokes the Firebase sessions and deletes the cookie. */
  logout: () => request("POST", "/auth/logout", {}),
  /** Recover a Forgotten Password (FSEEH-26), step 1: email the reset link. */
  requestPasswordReset: (email) => request("POST", "/auth/password-reset/request", { email }),
  /** Step 2: check the link's one-time code when the reset page opens. */
  verifyPasswordReset: (oobCode) => request("POST", "/auth/password-reset/verify", { oobCode }),
  /** My Account (FSEEH-49): email and creation date. */
  account: () => request<{ profile: AccountProfile }>("GET", "/account"),
  /** Edit Profile (FSEEH-49): change the email; needs the current password. */
  changeEmail: (newEmail, currentPassword) => request("POST", "/account/email", { newEmail, currentPassword }),
  /** Delete Account (FSEEH-50): needs the current password; deletes the cookie. */
  deleteAccount: (currentPassword) => request("POST", "/account/delete", { currentPassword }),
  /** Step 3: set the new password with the link's code. */
  confirmPasswordReset: (oobCode, password, confirm) =>
    request("POST", "/auth/password-reset/confirm", { oobCode, password, confirm }),
};
