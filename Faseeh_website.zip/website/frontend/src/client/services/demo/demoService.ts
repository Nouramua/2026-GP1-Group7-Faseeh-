/**
 * DESIGN-DEMONSTRATION service for the Workspace (Release 1).
 *
 * The readability classifier and the simplification model are connected to the
 * website in Release 2 (backlog story 36, Sprint 4). Until then the Workspace
 * uses this file, and the interface labels every result it returns:
 *
 *  - «عيّنة» (sample): one of the four built-in sample passages was used, so the
 *    level and the simplified text are prepared examples written by the team.
 *  - «محاكاة» (simulation): any other text. The level comes from a simple
 *    sentence-length heuristic, and "simplification" only splits long sentences.
 *
 * No AI model is called, nothing is sent to a server, and nothing is stored.
 * Accounts are NOT handled here: they are real (PHP backend + Firebase).
 * Saving, rating, history and statistics are Release 2 and are routed to a
 * "not available yet" error in `lib/api.ts`, not to this file.
 */
import type { AnalysisResult, AnyResult, AppConfig, SentenceLevel, SimplificationResult } from "../../../shared/api";
import { isLevel, type Level } from "../../../shared/levels";
import { validateArabicText } from "../../../shared/validation";
import { ApiRequestError } from "../errors";
import type { FeatureService } from "../types";
import { findSample } from "./samples";

// ── Readability: sample lookup, else a transparent length heuristic ──────

/** Splits after sentence-ending punctuation (Arabic and Latin) or at line breaks. */
const SENT_SPLIT = /(?<=[.!؟?…])\s+|\n+/;

/**
 * Splits a text into sentences, trimming each one and dropping fragments that
 * contain no letters (for example a stray "..." or a line of numbers).
 */
function splitSentences(text: string): string[] {
  return text
    .split(SENT_SPLIT)
    .map((x) => x.trim())
    .filter((x) => /\p{L}/u.test(x));
}

/**
 * Demonstration estimate of one sentence's level from its length.
 * Thresholds: up to 7 words → 1, up to 14 → 2, up to 21 → 3, longer → 4;
 * long average word length (> 5.4 letters) raises the level by one.
 * This is NOT the trained classifier; the UI labels its output as a simulation.
 *
 * @param sentence one sentence of the user's text
 * @returns an estimated level from 1 (easiest) to 4 (hardest)
 */
function estimate(sentence: string): Level {
  // Words are whitespace-separated tokens that contain at least one letter.
  const words = sentence.split(/\s+/).filter((w) => /\p{L}/u.test(w));
  const n = words.length;
  // Average number of letters per word (punctuation stripped); guard against division by zero.
  const avgLen = words.reduce((a, w) => a + w.replace(/[^\p{L}]/gu, "").length, 0) / Math.max(1, n);
  let lvl = n <= 7 ? 1 : n <= 14 ? 2 : n <= 21 ? 3 : 4;
  if (avgLen > 5.4 && lvl < 4) lvl++;
  return lvl as Level;
}

/**
 * Produces the demonstration analysis of a text.
 *
 * @param text the validated input text
 * @returns the overall level, per-sentence levels, and whether a prepared sample was used
 */
function analyseText(text: string): { level: Level; sentences: SentenceLevel[]; sample: boolean } {
  const sample = findSample(text);
  const parts = splitSentences(text);
  // Prepared sample: use the team's documented levels (only if the sentence split still lines up).
  if (sample && parts.length === sample.sentenceLevels.length)
    return { level: sample.level, sentences: parts.map((t, i) => ({ text: t, level: sample.sentenceLevels[i] })), sample: true };
  // Any other text: estimate each sentence, then round the mean to the nearest level within 1–4.
  const sentences = (parts.length ? parts : [text.trim()]).map((t) => ({ text: t, level: estimate(t) }));
  const mean = sentences.reduce((a, s) => a + s.level, 0) / sentences.length;
  return { level: Math.min(4, Math.max(1, Math.floor(mean + 0.5))) as Level, sentences, sample: false };
}

/**
 * Simulation for custom text: splits long sentences at commas, semicolons and
 * common connectors, and ends each piece with a full stop. Labelled in the UI.
 */
function splitSimulation(text: string): string {
  return splitSentences(text)
    .flatMap((s) => s.split(/[،,؛]\s*|\s+(?=(?:إذ|حيث|بل|لكن|كما|لذلك)\s)/))
    .map((s) => s.replace(/[.؟!]+$/, "").trim())
    .filter(Boolean)
    .map((s) => s + ".")
    .join(" ");
}

/**
 * True when a result is a simulation rather than a prepared sample.
 * Used by the interface to choose between the «محاكاة» and «عيّنة» labels.
 */
export function isSimulated(r: AnyResult): boolean {
  const sample = findSample(r.originalText);
  if (r.type === "analysis") return !sample;
  return !sample?.simplified[r.targetLevel];
}

// ── Helpers ───────────────────────────────────────────────────────────────

/**
 * Waits a short time so the loading states can be seen, and stops early with an
 * AbortError if the user starts another request or leaves the page.
 */
const wait = (ms: number, signal?: AbortSignal) =>
  new Promise<void>((resolve, reject) => {
    const t = setTimeout(resolve, ms);
    signal?.addEventListener("abort", () => {
      clearTimeout(t);
      reject(new DOMException("aborted", "AbortError"));
    });
  });

/**
 * Re-checks the text with the same rules as the interface (empty / not Arabic),
 * mirroring what the real backend will do in Release 2. There is no length limit.
 */
function checkText(text: string) {
  const v = validateArabicText(text);
  if (!v.ok) throw new ApiRequestError("validation", v.message!, 400, { text: v.message! });
}

// ── The service (only what the Release 1 Workspace calls) ────────────────────

export const demoService: Pick<FeatureService, "config" | "analyze" | "simplify"> = {
  /** Tells the Workspace which demonstration features are switched on. */
  async config(): Promise<AppConfig> {
    return {
      classifierAvailable: true,
      classifierModel: "نسخة العرض — بيانات نموذجية",
      simplifierAvailable: true,
      emailDelivery: "server-log",
    };
  },

  /**
   * Demonstration readability analysis.
   * @returns an analysis result with `id: null`, because nothing can be saved in Release 1
   */
  async analyze(text, signal) {
    checkText(text);
    await wait(1500, signal);
    const a = analyseText(text);
    const result: AnalysisResult = {
      id: null,
      type: "analysis",
      originalText: text,
      originalLevel: a.level,
      sentences: a.sentences,
      createdAt: new Date().toISOString(),
      saved: false,
    };
    return result;
  },

  /**
   * Demonstration simplification to the level the user selected.
   * Prepared samples return the team's hand-written text for that level;
   * other texts return the labelled sentence-splitting simulation.
   */
  async simplify(text, targetLevel, _analysisId, signal) {
    checkText(text);
    // A request without a valid target level is refused, as Select a Target Level AC3 (story 12) requires.
    if (!isLevel(targetLevel))
      throw new ApiRequestError("validation", "اختر المستوى المستهدف (من ١ إلى ٤) قبل التبسيط.", 400, { targetLevel: "اختر مستوى مستهدفًا." });
    await wait(2300, signal);
    const a = analyseText(text);
    const prepared = findSample(text)?.simplified[targetLevel];
    const result: SimplificationResult = {
      id: null,
      type: "simplification",
      originalText: text,
      originalLevel: a.level,
      targetLevel,
      simplifiedText: prepared ? prepared.text : splitSimulation(text),
      outputLevel: null, // the demonstration performs no verification; never shown in the UI
      createdAt: new Date().toISOString(),
      saved: false,
      rating: null, // rating is Release 2 (story 21)
    };
    return result;
  },
};
