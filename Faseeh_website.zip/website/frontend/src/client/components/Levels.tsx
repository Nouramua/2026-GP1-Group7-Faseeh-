import { useId, type KeyboardEvent } from "react";
import { LEVEL_INFO, LEVELS, type Level } from "../../shared/levels";

/** Compact level badge. Meaning is carried by numeral + name, never by colour alone. */
export function LevelBadge({ level, label, size = "md" }: { level: Level | null; label?: string; size?: "sm" | "md" }) {
  if (level === null)
    return (
      <span className={`lvl-badge lvl-badge--none lvl-badge--${size}`}>
        {label && <span className="lvl-badge__label">{label}</span>}
        <span className="lvl-badge__name">لم يُقَس</span>
      </span>
    );
  const info = LEVEL_INFO[level];
  return (
    <span className={`lvl-badge lvl-badge--${size}`} data-level={level}>
      {label && <span className="lvl-badge__label">{label}</span>}
      <span className="lvl-badge__dot" aria-hidden="true" />
      <span className="lvl-badge__name">
        المستوى {info.numeral} · {info.name}
      </span>
    </span>
  );
}

/**
 * The four-step readability ruler. The marker glides to the predicted level;
 * steps rise like a staircase to show the ordered scale.
 */
export function LevelMeter({ level, animate = true }: { level: Level; animate?: boolean }) {
  return (
    <div className={`lvl-meter ${animate ? "lvl-meter--animate" : ""}`} data-level={level} role="img" aria-label={`المستوى ${LEVEL_INFO[level].numeral} من ٤: ${LEVEL_INFO[level].name}`}>
      <div className="lvl-meter__track">
        {LEVELS.map((l) => (
          <span key={l} className={`lvl-meter__step ${l === level ? "is-on" : ""}`} data-level={l} style={{ ["--i" as string]: l }}>
            <span className="lvl-meter__num">{LEVEL_INFO[l].numeral}</span>
          </span>
        ))}
      </div>
      <div className="lvl-meter__ends" aria-hidden="true">
        <span>أسهل</span>
        <span>أصعب</span>
      </div>
    </div>
  );
}

/** Accessible radio group for choosing the target level. */
export function LevelPicker({
  value,
  onChange,
  currentLevel,
  maxLevel = 4,
  disabled,
}: {
  value: Level | null;
  onChange: (l: Level) => void;
  currentLevel: Level | null;
  /** highest selectable level; harder levels are shown but not selectable */
  maxLevel?: Level | 0;
  disabled?: boolean;
}) {
  const name = useId();
  const top = Math.max(0, maxLevel);
  const onKey = (e: KeyboardEvent<HTMLDivElement>) => {
    // RTL: ArrowLeft moves to the next (harder) level visually
    const delta = e.key === "ArrowLeft" || e.key === "ArrowDown" ? 1 : e.key === "ArrowRight" || e.key === "ArrowUp" ? -1 : 0;
    if (!delta) return;
    e.preventDefault();
    if (!top) return;
    const next = Math.min(top, Math.max(1, (value ?? (delta > 0 ? 0 : top + 1)) + delta)) as Level;
    onChange(next);
    (e.currentTarget.querySelector(`[data-level="${next}"]`) as HTMLElement | null)?.focus();
  };
  return (
    <div className="lvl-picker" role="radiogroup" aria-label="المستوى المستهدف" onKeyDown={onKey}>
      {LEVELS.map((l) => {
        const info = LEVEL_INFO[l];
        const checked = value === l;
        const locked = l > top;
        return (
          <button
            key={l}
            type="button"
            role="radio"
            name={name}
            aria-checked={checked}
            tabIndex={checked || (value === null && l === 1 && !locked) ? 0 : -1}
            data-level={l}
            disabled={disabled || locked}
            aria-disabled={locked || undefined}
            title={locked ? "ليس أسهل من مستوى نصّك" : undefined}
            className={`lvl-option ${checked ? "is-checked" : ""} ${locked ? "is-locked" : ""}`}
            onClick={() => onChange(l)}
          >
            <span className="lvl-option__num" aria-hidden="true">
              {info.numeral}
            </span>
            <span className="lvl-option__name">{info.name}</span>
            <span className="lvl-option__short">{info.short}</span>
            {currentLevel === l && <span className="lvl-option__tag">مستوى نصّك</span>}
            <span className="lvl-option__check" aria-hidden="true">
              <svg viewBox="0 0 24 24" width="16" height="16">
                <path d="M5 12.5l4.2 4L19 7" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </span>
          </button>
        );
      })}
    </div>
  );
}

/** Full explanation of the four levels (home page + workspace guide). */
export function LevelGuide({ compact = false }: { compact?: boolean }) {
  return (
    <ol className={`lvl-guide ${compact ? "lvl-guide--compact" : ""}`}>
      {LEVELS.map((l) => {
        const info = LEVEL_INFO[l];
        return (
          <li key={l} className="lvl-guide__item" data-level={l} style={{ ["--i" as string]: l }}>
            <div className="lvl-guide__head">
              <span className="lvl-guide__num" aria-hidden="true">
                {info.numeral}
              </span>
              <div>
                <h3 className="lvl-guide__name">
                  <span className="visually-hidden">المستوى {info.numeral}: </span>
                  {info.name}
                </h3>
                <p className="lvl-guide__short">{info.short}</p>
              </div>
            </div>
            <p className="lvl-guide__desc">{info.description}</p>
            {!compact && (
              <>
                <ul className="lvl-guide__traits">
                  {info.traits.map((t) => (
                    <li key={t}>{t}</li>
                  ))}
                </ul>
                <blockquote className="lvl-guide__example" lang="ar">
                  {info.example}
                </blockquote>
              </>
            )}
          </li>
        );
      })}
    </ol>
  );
}
