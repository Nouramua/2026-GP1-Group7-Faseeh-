import { useEffect, useRef, useState } from "react";
import { Mascot } from "../brand/Mascot";
import { FAQ, TIPS, useAssistant } from "../lib/assistant";

const STORE = "faseeh:assistant-seen";

/**
 * «نقطة» — a small, dismissible, keyboard-accessible helper docked at the
 * bottom-left corner (the trailing edge in RTL), away from primary controls.
 */
export function Assistant() {
  const { topic } = useAssistant();
  const tip = TIPS[topic] ?? TIPS.default;
  const [open, setOpen] = useState(false);
  const [faq, setFaq] = useState<number | null>(null);
  const [nudge, setNudge] = useState(false);
  const [intro, setIntro] = useState(false);
  const panelRef = useRef<HTMLDivElement>(null);
  const btnRef = useRef<HTMLButtonElement>(null);
  const lastTopic = useRef(topic);

  // First visit (Get Contextual Help AC6, Jira FSEEH-114): a short greeting bubble
  // beside the button, shown 3.2 s after load and removed at 11 s.
  useEffect(() => {
    let seen = true;
    try {
      seen = localStorage.getItem(STORE) === "1";
    } catch {
      /* storage blocked: treat as seen, so the greeting never repeats on every page */
    }
    if (!seen) {
      // The visit is recorded as "greeted" only when the greeting is actually shown.
      // Recording it on mount would lose the greeting if the visitor leaves within
      // 3.2 s, and in development React's StrictMode (which runs effects twice)
      // would cancel the first timer after the flag was already written.
      const a = window.setTimeout(() => {
        setIntro(true);
        try {
          localStorage.setItem(STORE, "1");
        } catch {
          /* ignore */
        }
      }, 3200);
      const b = window.setTimeout(() => setIntro(false), 11000);
      return () => {
        window.clearTimeout(a);
        window.clearTimeout(b);
      };
    }
  }, []);

  // When the context changes while closed, show a small "new tip" nudge.
  useEffect(() => {
    if (lastTopic.current !== topic) {
      lastTopic.current = topic;
      setFaq(null);
      if (!open) setNudge(true);
    }
  }, [topic, open]);

  // While the panel is open: clear the indicators, move focus into the panel, and listen for Esc.
  useEffect(() => {
    if (!open) return;
    setNudge(false);
    setIntro(false);
    // The panel comes before the help button in the page, so without this a
    // keyboard user pressing Tab after opening would move away from the help
    // content. Focusing the panel lets Tab continue to the close button and FAQ.
    panelRef.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setOpen(false);
        btnRef.current?.focus();
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <div className={`assistant ${open ? "is-open" : ""}`}>
      {open && (
        <div
          id="assistant-panel"
          className="assistant__panel"
          role="dialog"
          aria-modal="false"
          aria-labelledby="assistant-title"
          ref={panelRef}
          // -1: focusable from script (see the effect above) but not an extra Tab stop.
          tabIndex={-1}
        >
          <div className="assistant__head">
            <Mascot size={40} mood={tip.mood} />
            <div>
              <p className="assistant__name">نقطة · مساعدة فصيح</p>
              <h2 id="assistant-title" className="assistant__title">
                {tip.title}
              </h2>
            </div>
            <button
              type="button"
              className="icon-btn assistant__close"
              aria-label="إغلاق المساعدة"
              onClick={() => {
                setOpen(false);
                btnRef.current?.focus();
              }}
            >
              <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
                <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
              </svg>
            </button>
          </div>
          <p className="assistant__body" aria-live="polite">
            {tip.body}
          </p>
          <div className="assistant__faq">
            <p className="assistant__faq-h">أسئلة شائعة</p>
            <ul>
              {FAQ.map((f, i) => (
                <li key={f.q}>
                  <button
                    type="button"
                    className="assistant__q"
                    aria-expanded={faq === i}
                    aria-controls={`faq-${i}`}
                    onClick={() => setFaq(faq === i ? null : i)}
                  >
                    {f.q}
                  </button>
                  {faq === i && (
                    <p id={`faq-${i}`} className="assistant__a">
                      {f.a}
                    </p>
                  )}
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
      {intro && !open && (
        <button type="button" className="assistant__intro" onClick={() => setOpen(true)}>
          أهلًا! أنا <strong>نقطة</strong>، اضغطني متى احتجت مساعدة.
        </button>
      )}
      <button
        ref={btnRef}
        type="button"
        className="assistant__btn"
        aria-expanded={open}
        aria-controls={open ? "assistant-panel" : undefined}
        aria-label={open ? "إخفاء مساعدة نقطة" : `مساعدة نقطة: ${tip.title}`}
        onClick={() => setOpen((o) => !o)}
      >
        <Mascot size={46} mood={open ? tip.mood : "idle"} />
        {nudge && !open && <span className="assistant__nudge" aria-hidden="true" />}
      </button>
    </div>
  );
}
