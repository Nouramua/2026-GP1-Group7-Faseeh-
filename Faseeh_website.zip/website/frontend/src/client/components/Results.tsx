import { useState } from "react";
import { Link } from "react-router-dom";
import type { AnalysisResult, Rating, RatingIssue, SimplificationResult } from "../../shared/api";
import { RATING_ISSUE_LABELS, RATING_ISSUES } from "../../shared/api";
import { LEVEL_INFO, type Level } from "../../shared/levels";
import { ApiRequestError, api, isDemo, recordsAvailable } from "../lib/api";
import { isSimulated } from "../services/demo/demoService";
import type { AnyResult } from "../../shared/api";
import { useSession } from "../lib/session";
import { useToast } from "../lib/toast";
import { fmtDateTime } from "../lib/format";
import { LevelBadge, LevelMeter } from "./Levels";
import { Spinner } from "./ui";

const SIZES = [17, 19, 21, 24, 28];

export function useCopy() {
  const toast = useToast();
  return async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast("نُسخ النص المبسّط.", "success");
    } catch {
      // Fallback for browsers that block the async clipboard API
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.setAttribute("readonly", "");
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand("copy");
      ta.remove();
      toast(ok ? "نُسخ النص المبسّط." : "تعذّر النسخ تلقائيًا. حدّد النص وانسخه يدويًا.", ok ? "success" : "error");
    }
  };
}

export function SaveButton({ id, saved, onSaved }: { id: string | null; saved: boolean; onSaved: () => void }) {
  const { user } = useSession();
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  if (!recordsAvailable)
    return (
      <span className="saved-pill saved-pill--later" role="note">
        حفظ النتائج متاح في الإصدار الثاني
      </span>
    );
  if (!user || !id)
    return (
      <Link className="btn btn--ghost" to="/login" state={{ from: "/workspace" }}>
        سجّل الدخول لحفظ النتيجة
      </Link>
    );
  if (saved)
    return (
      <span className="saved-pill" role="status">
        <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path d="M5 12.5l4.2 4L19 7" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" /></svg>
        محفوظة في سجلّك
      </span>
    );
  return (
    <button
      type="button"
      className="btn btn--soft"
      disabled={busy}
      aria-busy={busy}
      onClick={async () => {
        setBusy(true);
        try {
          await api.save(id);
          onSaved();
          toast("حُفظت النتيجة في سجلّك.", "success");
        } catch (e) {
          toast(e instanceof ApiRequestError ? e.message : "تعذّر الحفظ. حاول مرة أخرى.", "error");
        } finally {
          setBusy(false);
        }
      }}
    >
      {busy ? <Spinner /> : null}
      احفظ النتيجة
    </button>
  );
}

/** Demo mode only: says whether a result is a prepared sample or a simulation. */
export function DemoNote({ result }: { result: AnyResult }) {
  if (!isDemo) return null;
  const sim = isSimulated(result);
  const text =
    result.type === "analysis"
      ? sim
        ? "تقدير تجريبي يعتمد على طول الجمل فقط، وسيحلّ محلّه نموذج التصنيف."
        : "نتيجة نموذجية معدّة للعرض، وليست ناتج النموذج."
      : sim
        ? "محاكاة تجريبية: قُسّمت الجمل الطويلة فقط. سيظهر هنا ناتج نموذج التبسيط بعد ربطه."
        : "نص مبسّط نموذجي كتبه الفريق للعرض، وليس ناتج النموذج.";
  return (
    <p className={`demo-note ${sim ? "demo-note--sim" : ""}`}>
      <span className="demo-note__tag">{sim ? "محاكاة" : "عيّنة"}</span>
      {text}
    </p>
  );
}

/** Reveals text word by word (once), then settles into plain text. */
function WordReveal({ text, play }: { text: string; play: boolean }) {
  if (!play) return <>{text}</>;
  const words = text.split(/(\s+)/);
  let i = 0;
  return (
    <>
      {words.map((w, k) =>
        /^\s+$/.test(w) ? (
          w
        ) : (
          <span key={k} className="word-in" style={{ ["--i" as string]: Math.min(i++, 60) }}>
            {w}
          </span>
        ),
      )}
    </>
  );
}

export function AnalysisView({ result, live = true }: { result: AnalysisResult; live?: boolean }) {
  const info = LEVEL_INFO[result.originalLevel];
  // Only the overall level of the text is shown; per-sentence levels are not displayed.
  return (
    <div className="analysis">
      <div className="analysis__top">
        <div className="analysis__headline">
          <p className="eyebrow-text">مستوى مقروئية النص</p>
          <p className="analysis__level">
            <span className="analysis__numeral" data-level={result.originalLevel}>
              {info.numeral}
            </span>
            <span>
              <span className="analysis__name">{info.name}</span>
              <span className="analysis__short">{info.short}</span>
            </span>
          </p>
        </div>
        <LevelMeter level={result.originalLevel} animate={live} />
      </div>
      <p className="analysis__desc">{info.description}</p>
      <DemoNote result={result} />
    </div>
  );
}

function FontSizeControl({ size, setSize }: { size: number; setSize: (n: number) => void }) {
  const i = SIZES.indexOf(size);
  return (
    <div className="font-ctrl" role="group" aria-label="حجم خط النص المبسّط">
      <button type="button" className="icon-btn" onClick={() => setSize(SIZES[Math.max(0, i - 1)])} disabled={i <= 0} aria-label="تصغير الخط">
        <span aria-hidden="true" style={{ fontSize: 13 }}>أ−</span>
      </button>
      <span className="font-ctrl__val" aria-live="polite">
        {size.toLocaleString("ar-SA")}
        <span className="visually-hidden"> بكسل</span>
      </span>
      <button type="button" className="icon-btn" onClick={() => setSize(SIZES[Math.min(SIZES.length - 1, i + 1)])} disabled={i >= SIZES.length - 1} aria-label="تكبير الخط">
        <span aria-hidden="true" style={{ fontSize: 17 }}>أ+</span>
      </button>
    </div>
  );
}

/** The simplification request at a glance: original level → the level the user chose. */
function LevelJourney({ from, to }: { from: Level; to: Level }) {
  return (
    <div className="journey" role="group" aria-label={`من المستوى ${LEVEL_INFO[from].numeral} إلى المستوى ${LEVEL_INFO[to].numeral} الذي اخترته`}>
      <div className="journey__stop" data-level={from}>
        <span className="journey__num" aria-hidden="true">{LEVEL_INFO[from].numeral}</span>
        <span className="journey__txt">
          <span className="journey__label">مستوى النص الأصلي</span>
          <span className="journey__name">{LEVEL_INFO[from].name}</span>
        </span>
      </div>
      <svg className="journey__path" viewBox="0 0 120 40" preserveAspectRatio="none" aria-hidden="true">
        <path d="M118 8 C 80 6, 60 36, 6 30 M14 24 L5 30 L13 37" pathLength={1} />
      </svg>
      <div className="journey__stop journey__stop--target" data-level={to}>
        <span className="journey__num" aria-hidden="true">{LEVEL_INFO[to].numeral}</span>
        <span className="journey__txt">
          <span className="journey__label">المستوى الذي اخترته</span>
          <span className="journey__name">{LEVEL_INFO[to].name}</span>
        </span>
      </div>
    </div>
  );
}

export function ComparisonView({
  result,
  onSaved,
  onRated,
  animateIn = false,
}: {
  result: SimplificationResult;
  onSaved?: () => void;
  onRated?: (r: Rating) => void;
  animateIn?: boolean;
}) {
  const [size, setSize] = useState(21);
  const copy = useCopy();
  return (
    <section className="compare" aria-labelledby="compare-h">
      <div className="compare__head">
        <h2 id="compare-h" className="section-title">
          المقارنة بين النسختين
        </h2>
        <p className="compare__meta">{fmtDateTime(result.createdAt)}</p>
      </div>
      <LevelJourney from={result.originalLevel} to={result.targetLevel} />
      <DemoNote result={result} />
      <div className={`compare__grid ${animateIn ? "is-animating" : ""}`}>
        <svg className="compare__flowline" viewBox="0 0 80 200" preserveAspectRatio="none" aria-hidden="true">
          <path d="M78 20 C 40 30, 50 110, 40 120 S 10 180, 2 186" pathLength={1} />
        </svg>
        <article className="passage passage--original" aria-labelledby="orig-h">
          <header className="passage__head">
            <h3 id="orig-h">النص الأصلي</h3>
            <LevelBadge level={result.originalLevel} size="sm" />
          </header>
          <div className="passage__text reading" tabIndex={0} aria-label="النص الأصلي">
            {result.originalText}
          </div>
        </article>
        <article className="passage passage--simple" aria-labelledby="simp-h">
          <header className="passage__head">
            <h3 id="simp-h">
              النص المبسّط
              <span className="passage__target">للمستوى {LEVEL_INFO[result.targetLevel].numeral}</span>
            </h3>
            <div className="passage__tools">
              <FontSizeControl size={size} setSize={setSize} />
              <button type="button" className="btn btn--ghost btn--sm" onClick={() => copy(result.simplifiedText)}>
                <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><rect x="8" y="8" width="11" height="11" rx="2.5" fill="none" stroke="currentColor" strokeWidth="1.8" /><path d="M5 15V7a2 2 0 012-2h8" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" /></svg>
                نسخ
              </button>
            </div>
          </header>
          <div className="passage__text reading" tabIndex={0} aria-label="النص المبسّط" style={{ fontSize: size }}>
            <WordReveal text={result.simplifiedText} play={animateIn} />
          </div>
        </article>
      </div>
      <div className="compare__actions">
        {onSaved && <SaveButton id={result.id} saved={result.saved} onSaved={onSaved} />}
      </div>
      {result.id && <RatingForm resultId={result.id} initial={result.rating} onRated={onRated} />}
    </section>
  );
}

export function RatingForm({ resultId, initial, onRated }: { resultId: string; initial: Rating | null; onRated?: (r: Rating) => void }) {
  const { user } = useSession();
  const toast = useToast();
  const [stars, setStars] = useState<number>(initial?.stars ?? 0);
  const [hover, setHover] = useState(0);
  const [issues, setIssues] = useState<RatingIssue[]>(initial?.issues ?? []);
  const [comment, setComment] = useState(initial?.comment ?? "");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState<Rating | null>(initial);
  if (!user || !recordsAvailable) return null; // rating and feedback are Release 2 (backlog story 21, Jira FSEEH-25)
  const labels = ["", "ضعيف", "مقبول", "جيد", "جيد جدًا", "ممتاز"];
  const shown = hover || stars;

  return (
    <form
      className="rating"
      onSubmit={async (e) => {
        e.preventDefault();
        if (!stars) {
          setError("اختر عدد النجوم أولًا.");
          return;
        }
        setBusy(true);
        setError(null);
        try {
          const r = await api.rate(resultId, stars, issues, comment);
          setSubmitted(r);
          onRated?.(r);
          toast(submitted ? "حُدّث تقييمك." : "شكرًا لتقييمك!", "success");
        } catch (err) {
          setError(err instanceof ApiRequestError ? err.message : "تعذّر إرسال التقييم. حاول مرة أخرى.");
        } finally {
          setBusy(false);
        }
      }}
    >
      <fieldset className="rating__stars-set">
        <legend className="rating__legend">ما رأيك في هذا التبسيط؟</legend>
        <div className="rating__stars" onMouseLeave={() => setHover(0)}>
          {[1, 2, 3, 4, 5].map((n) => (
            <label key={n} className={`star ${n <= shown ? "is-on" : ""}`} onMouseEnter={() => setHover(n)}>
              <input type="radio" name={`stars-${resultId}`} value={n} checked={stars === n} onChange={() => setStars(n)} className="visually-hidden" />
              <svg viewBox="0 0 24 24" width="30" height="30" aria-hidden="true">
                <path d="M12 3.2l2.6 5.6 6.1.7-4.5 4.2 1.2 6-5.4-3-5.4 3 1.2-6L3.3 9.5l6.1-.7z" />
              </svg>
              <span className="visually-hidden">{n.toLocaleString("ar-SA")} من ٥ — {labels[n]}</span>
            </label>
          ))}
          <span className="rating__word" aria-hidden="true">
            {labels[shown]}
          </span>
        </div>
      </fieldset>
      {stars > 0 && stars <= 3 && (
        <fieldset className="rating__issues">
          <legend className="rating__legend rating__legend--sm">ما المشكلة؟ (اختياري)</legend>
          <div className="chips">
            {RATING_ISSUES.map((i) => (
              <label key={i} className={`chip ${issues.includes(i) ? "is-on" : ""}`}>
                <input
                  type="checkbox"
                  className="visually-hidden"
                  checked={issues.includes(i)}
                  onChange={(e) => setIssues((cur) => (e.target.checked ? [...cur, i] : cur.filter((x) => x !== i)))}
                />
                {RATING_ISSUE_LABELS[i]}
              </label>
            ))}
          </div>
        </fieldset>
      )}
      {stars > 0 && (
        <div className="field">
          <label className="field__label" htmlFor={`comment-${resultId}`}>
            ملاحظة (اختياري)
          </label>
          <textarea id={`comment-${resultId}`} className="input input--area-sm" maxLength={500} value={comment} onChange={(e) => setComment(e.target.value)} rows={2} />
        </div>
      )}
      {error && (
        <p className="field__error" role="alert">
          {error}
        </p>
      )}
      <div className="rating__foot">
        <button type="submit" className="btn btn--soft" disabled={busy || !stars}>
          {busy ? <Spinner /> : null}
          {submitted ? "تحديث التقييم" : "أرسل التقييم"}
        </button>
        {submitted && <span className="fine-print">تقييمك المحفوظ: {submitted.stars.toLocaleString("ar-SA")} من ٥</span>}
      </div>
    </form>
  );
}
