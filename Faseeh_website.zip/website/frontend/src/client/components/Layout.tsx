import { useEffect, useRef, useState, type ReactNode } from "react";
import { Link, NavLink, useLocation, useNavigate } from "react-router-dom";
import { LogoMark, LogoOutline } from "../brand/Logo";
import { useSession } from "../lib/session";
import { useToast } from "../lib/toast";
import { Assistant } from "./Assistant";
import { isDemo } from "../lib/api";

const NAV = [
  { to: "/", label: "الرئيسية", end: true },
  { to: "/workspace", label: "مساحة العمل" },
  { to: "/history", label: "السجل" },
  { to: "/stats", label: "الإحصاءات" },
  { to: "/about", label: "عن فصيح" },
];

function Header() {
  const { user, logout, loading } = useSession();
  const toast = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const [menu, setMenu] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => setMenu(false), [location.pathname]);
  useEffect(() => {
    if (!menu) return;
    const close = (e: MouseEvent | KeyboardEvent) => {
      if (e instanceof KeyboardEvent ? e.key === "Escape" : !menuRef.current?.contains(e.target as Node)) setMenu(false);
    };
    document.addEventListener("mousedown", close);
    document.addEventListener("keydown", close);
    return () => {
      document.removeEventListener("mousedown", close);
      document.removeEventListener("keydown", close);
    };
  }, [menu]);

  const onLogout = async () => {
    await logout();
    toast("سُجّل خروجك بأمان.", "success");
    navigate("/");
  };

  return (
    <header className="site-header">
      <div className="container site-header__inner">
        <Link to="/" className="brand-link" aria-label="فصيح — الصفحة الرئيسية">
          <LogoMark className="brand-link__logo" title={null} />
        </Link>
        <nav aria-label="التنقل الرئيسي" className="main-nav">
          {NAV.map((n) => (
            <NavLink key={n.to} to={n.to} end={n.end} className="main-nav__link">
              {n.label}
            </NavLink>
          ))}
        </nav>
        <div className="site-header__account">
          {loading ? null : user ? (
            <div className="account" ref={menuRef}>
              <button
                type="button"
                className="account__btn"
                aria-expanded={menu}
                aria-haspopup="menu"
                onClick={() => setMenu((m) => !m)}
              >
                <span className="account__avatar" aria-hidden="true">
                  {user.email[0].toUpperCase()}
                </span>
                <span className="account__email" dir="ltr">
                  {user.email}
                </span>
              </button>
              {menu && (
                <div className="account__menu" role="menu">
                  <Link role="menuitem" to="/profile">
                    حسابي
                  </Link>
                  <Link role="menuitem" to="/history">
                    سجلّي
                  </Link>
                  <Link role="menuitem" to="/stats">
                    إحصاءاتي
                  </Link>
                  <hr />
                  <button role="menuitem" type="button" className="account__logout" onClick={onLogout}>
                    تسجيل الخروج
                  </button>
                </div>
              )}
            </div>
          ) : (
            <>
              <Link to="/login" state={{ from: location.pathname }} className="btn btn--ghost btn--sm">
                تسجيل الدخول
              </Link>
              <Link to="/register" className="btn btn--soft btn--sm">
                إنشاء حساب
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}

function Footer() {
  return (
    <footer className="site-footer">
      <LogoOutline part="ha" className="site-footer__motif" strokeWidth={1.2} />
      <div className="container site-footer__inner">
        <div className="site-footer__brand">
          <LogoMark className="site-footer__logo" title="فصيح" />
          <p>منصّة عربية لقياس مقروئية النصوص وتبسيطها إلى المستوى الذي تختاره.</p>
        </div>
        <div className="site-footer__cols">
          <div>
            <h2 className="site-footer__h">المنصّة</h2>
            <ul>
              <li>
                <Link to="/workspace">مساحة العمل</Link>
              </li>
              <li>
                <Link to={{ pathname: "/", hash: "#levels" }}>المستويات الأربعة</Link>
              </li>
              <li>
                <Link to={{ pathname: "/", hash: "#how" }}>كيف يعمل فصيح</Link>
              </li>
              <li>
                <Link to="/about">عن المشروع</Link>
              </li>
            </ul>
          </div>
          <div>
            <h2 className="site-footer__h">المشروع</h2>
            <p className="site-footer__small">
              مشروع تخرّج — قسم تقنية المعلومات، كلية علوم الحاسب والمعلومات، جامعة الملك سعود.
              <br />
              نورة المعيلي · العنود السند · جنى العثمان · نورة التويم
              <br />
              بإشراف د. وجدان الخالدي
            </p>
          </div>
        </div>
      </div>
      <div className="container site-footer__base">
        <span>© {new Date().getFullYear()} فصيح</span>
        <span>{isDemo ? "الإصدار الأول — التحليل والتبسيط عرض توضيحي" : "منصّة عربية لقياس مقروئية النصوص وتبسيطها."}</span>
      </div>
    </footer>
  );
}

/** C2a: "session expires / Firebase ends session" → back to Guest, with a clear message. */
function SessionExpiryNotice() {
  const { expired, clearExpired } = useSession();
  const toast = useToast();
  useEffect(() => {
    if (expired) {
      toast("انتهت جلستك. سجّل الدخول مرة أخرى.", "info");
      clearExpired();
    }
  }, [expired, clearExpired, toast]);
  return null;
}

export function Layout({ children }: { children: ReactNode }) {
  const location = useLocation();
  const mainRef = useRef<HTMLElement>(null);
  const first = useRef(true);

  // Route change: scroll to top (or hash), move focus to main for screen readers.
  useEffect(() => {
    if (location.hash) {
      const id = location.hash.slice(1);
      // wait a frame so a freshly mounted page has rendered its sections
      requestAnimationFrame(() => document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" }));
      return;
    }
    window.scrollTo({ top: 0 });
    if (first.current) {
      first.current = false;
      return;
    }
    mainRef.current?.focus({ preventScroll: true });
  }, [location.pathname, location.hash]);

  return (
    <>
      <a href="#main" className="skip-link">
        انتقل إلى المحتوى
      </a>
      <SessionExpiryNotice />
      <Header />
      <main id="main" ref={mainRef} tabIndex={-1} className="page-transition" key={location.pathname + (location.state as { replayLogo?: number } | null)?.replayLogo}>
        {children}
      </main>
      <Footer />
      <Assistant />
    </>
  );
}
