import { useEffect, useId, useRef, useState, type InputHTMLAttributes, type ReactNode } from "react";
import { LogoOutline, type MotifPart } from "../brand/Logo";
import { passwordChecks } from "../../shared/validation";

export function Spinner({ label }: { label?: string }) {
  return (
    <span className="spinner" role={label ? "status" : undefined}>
      <span className="spinner__ring" aria-hidden="true" />
      {label && <span className="visually-hidden">{label}</span>}
    </span>
  );
}

/** Field with a visible label, helper text and an error tied via aria-describedby. */
export function Field({
  label,
  error,
  hint,
  children,
  id: idProp,
}: {
  label: string;
  error?: string | null;
  hint?: ReactNode;
  id?: string;
  children: (props: { id: string; "aria-invalid": boolean; "aria-describedby"?: string }) => ReactNode;
}) {
  const auto = useId();
  const id = idProp ?? auto;
  const describedBy = [hint ? `${id}-hint` : null, error ? `${id}-err` : null].filter(Boolean).join(" ") || undefined;
  return (
    <div className={`field ${error ? "has-error" : ""}`}>
      <label className="field__label" htmlFor={id}>
        {label}
      </label>
      {children({ id, "aria-invalid": Boolean(error), "aria-describedby": describedBy })}
      {hint && (
        <div className="field__hint" id={`${id}-hint`}>
          {hint}
        </div>
      )}
      {error && (
        <p className="field__error" id={`${id}-err`} role="alert">
          {error}
        </p>
      )}
    </div>
  );
}

export function PasswordInput(props: InputHTMLAttributes<HTMLInputElement>) {
  const [show, setShow] = useState(false);
  return (
    <div className="pw-input">
      <input {...props} type={show ? "text" : "password"} dir="ltr" className="input" />
      <button type="button" className="pw-input__toggle" onClick={() => setShow((s) => !s)} aria-pressed={show}>
        {show ? "إخفاء" : "إظهار"}
      </button>
    </div>
  );
}

export function PasswordRules({ value }: { value: string }) {
  return (
    <ul className="pw-rules" aria-label="شروط كلمة المرور">
      {passwordChecks(value).map((c) => (
        <li key={c.key} className={c.ok ? "is-ok" : ""}>
          <span className="pw-rules__mark" aria-hidden="true" />
          {c.label}
          <span className="visually-hidden">{c.ok ? " (مستوفى)" : " (غير مستوفى)"}</span>
        </li>
      ))}
    </ul>
  );
}

/** Modal dialog using the native <dialog> element (focus trap + Esc built in). */
export function Dialog({
  open,
  onClose,
  title,
  children,
  actions,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  actions: ReactNode;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  const titleId = useId();
  useEffect(() => {
    const d = ref.current;
    if (!d) return;
    if (open && !d.open) d.showModal();
    if (!open && d.open) d.close();
  }, [open]);
  return (
    <dialog
      ref={ref}
      className="dialog"
      aria-labelledby={titleId}
      onClose={onClose}
      onClick={(e) => {
        if (e.target === ref.current) onClose();
      }}
    >
      <div className="dialog__body">
        <h2 id={titleId} className="dialog__title">
          {title}
        </h2>
        {children}
        <div className="dialog__actions">{actions}</div>
      </div>
    </dialog>
  );
}

export function EmptyState({
  title,
  body,
  action,
  motif = "sad",
}: {
  title: string;
  body: string;
  action?: ReactNode;
  motif?: MotifPart;
}) {
  return (
    <div className="empty">
      <LogoOutline part={motif} className="empty__motif" draw drawMs={2600} strokeWidth={1.6} />
      <h2 className="empty__title">{title}</h2>
      <p className="empty__body">{body}</p>
      {action}
    </div>
  );
}

export function Notice({ tone = "info", title, children }: { tone?: "info" | "warn" | "error" | "success"; title?: string; children: ReactNode }) {
  return (
    <div className={`notice notice--${tone}`} role={tone === "error" ? "alert" : undefined}>
      <span className="notice__icon" aria-hidden="true">
        {tone === "success" ? (
          <svg viewBox="0 0 24 24" width="18" height="18"><path d="M5 12.5l4.2 4L19 7" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" /></svg>
        ) : (
          <svg viewBox="0 0 24 24" width="18" height="18"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeWidth="2" /><path d="M12 7.5v5.5M12 16.4v.1" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" /></svg>
        )}
      </span>
      <div>
        {title && <p className="notice__title">{title}</p>}
        <div className="notice__text">{children}</div>
      </div>
    </div>
  );
}

/** Processing indicator: a calligraphic line being "read" from right to left. */
export function ReadingLoader({ label }: { label: string }) {
  return (
    <div className="reading-loader" role="status" aria-live="polite">
      <svg viewBox="0 0 220 40" className="reading-loader__svg" aria-hidden="true">
        <path className="reading-loader__base" d="M214 22 C190 8 176 34 152 20 S112 6 92 22 S50 34 30 18 S10 16 6 22" />
        <path className="reading-loader__ink" d="M214 22 C190 8 176 34 152 20 S112 6 92 22 S50 34 30 18 S10 16 6 22" pathLength={1} />
      </svg>
      <span>{label}</span>
    </div>
  );
}
