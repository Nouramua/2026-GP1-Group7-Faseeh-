import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import "@fontsource/marhey/arabic-500.css";
import "@fontsource/marhey/arabic-600.css";
import "@fontsource-variable/readex-pro/wght.css";
import "@fontsource-variable/noto-naskh-arabic/wght.css";
import "./styles/tokens.css";
import "./styles/base.css";
import "./styles/components.css";
import "./styles/pages.css";
import "./styles/demo.css";
import { App } from "./App";
import { AssistantProvider } from "./lib/assistant";
import { SessionProvider } from "./lib/session";
import { ToastProvider } from "./lib/toast";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <BrowserRouter>
      <SessionProvider>
        <ToastProvider>
          <AssistantProvider>
            <App />
          </AssistantProvider>
        </ToastProvider>
      </SessionProvider>
    </BrowserRouter>
  </StrictMode>,
);
