import { LOGO } from "./logoData";

export type MascotMood = "idle" | "think" | "happy" | "concern";

/**
 * «نقطة» (Nuqta) — Faseeh's helper. Her body is the actual dot of the letter ف
 * taken from the logo trace; the tiny flick of the logo becomes her tuft.
 * Kept deliberately minimal: two eyes, an expression, nothing else.
 */
export function Mascot({ size = 56, mood = "idle", className }: { size?: number; mood?: MascotMood; className?: string }) {
  // The dot sits around x 782–866, y 12–97 in logo coordinates.
  const mouth =
    mood === "happy"
      ? "M812 66 q12 10 24 0"
      : mood === "concern"
        ? "M814 70 q10 -6 20 0"
        : mood === "think"
          ? "M815 67 h16"
          : "M813 66 q11 6 22 0";
  return (
    <svg
      className={`mascot mascot--${mood} ${className ?? ""}`}
      width={size}
      height={size}
      viewBox="770 0 108 108"
      aria-hidden="true"
      focusable="false"
    >
      <path d={LOGO.fills.dot} fill="var(--brand)" />
      <g className="mascot__eyes" fill="var(--cocoa)">
        <ellipse cx="809" cy="50" rx="4.6" ry={mood === "think" ? 3 : 5.6} />
        <ellipse cx="838" cy="50" rx="4.6" ry={mood === "think" ? 3 : 5.6} />
      </g>
      <circle cx="801" cy="62" r="4.5" fill="#fbe6d4" opacity=".75" />
      <circle cx="846" cy="62" r="4.5" fill="#fbe6d4" opacity=".75" />
      <path d={mouth} fill="none" stroke="var(--cocoa)" strokeWidth="3.2" strokeLinecap="round" />
    </svg>
  );
}
