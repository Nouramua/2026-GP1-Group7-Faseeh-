import { useEffect, useId, useMemo, useState, type CSSProperties } from "react";
import { LOGO } from "./logoData";
import { usePrefersReducedMotion } from "../lib/motion";

const FILL_ORDER = ["flick", "body", "dot", "knot"] as const;
type Part = (typeof FILL_ORDER)[number];

/** Static logo built from the exact vector trace of the original artwork. */
export function LogoMark({ className, title = "فصيح", style }: { className?: string; title?: string | null; style?: CSSProperties }) {
  return (
    <svg
      className={className}
      viewBox={LOGO.viewBox}
      role={title ? "img" : undefined}
      aria-label={title ?? undefined}
      aria-hidden={title ? undefined : true}
      style={style}
    >
      <g fill="currentColor" fillRule="evenodd">
        {FILL_ORDER.map((k) => (
          <path key={k} d={LOGO.fills[k]} />
        ))}
      </g>
    </svg>
  );
}

/** Pen timing: constant pen speed through the word, minimum durations for tiny strokes. */
function useStrokeSchedule(totalMs: number) {
  return useMemo(() => {
    const bodyLen = LOGO.strokes.filter((s) => s.group === "body").reduce((a, s) => a + s.length, 0);
    const speed = bodyLen / (totalMs * 0.62); // the word itself takes ~62% of the time
    const gap: Record<Part, number> = { flick: 0, body: 60, dot: 140, knot: 220 };
    let t = 120;
    let prev: Part | null = null;
    return LOGO.strokes.map((s) => {
      const group = s.group as Part;
      if (group !== prev) t += gap[group];
      prev = group;
      const min = group === "body" ? 300 : group === "dot" ? 260 : 150;
      const duration = Math.max(min, s.length / speed);
      const item = { ...s, delay: t, duration };
      t += duration * (group === "knot" ? 0.8 : 1);
      return item;
    });
  }, [totalMs]);
}

/**
 * The signature animation: the original logo is revealed along the path a pen
 * would travel. Centre-line strokes (derived from the logo's skeleton) animate
 * inside an SVG mask over the real logo fill, so the final image is exactly the
 * original artwork. A short cross-fade at the end guarantees pixel-complete edges.
 */
export function LogoWriting({
  className,
  durationMs = 2600,
  play = true,
  onDone,
}: {
  className?: string;
  durationMs?: number;
  play?: boolean;
  onDone?: () => void;
}) {
  const reduced = usePrefersReducedMotion();
  const uid = useId().replace(/:/g, "");
  const schedule = useStrokeSchedule(durationMs);
  const end = schedule.length ? schedule[schedule.length - 1].delay + schedule[schedule.length - 1].duration : 0;
  const animate = play && !reduced;
  const [done, setDone] = useState(!animate);

  useEffect(() => {
    if (!animate) {
      setDone(true);
      onDone?.();
      return;
    }
    setDone(false);
    const t = window.setTimeout(() => {
      setDone(true);
      onDone?.();
    }, end + 60);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [animate, end]);

  return (
    <svg className={className} viewBox={LOGO.viewBox} role="img" aria-label="فصيح">
      <defs>
        <mask id={`pen-${uid}`} maskUnits="userSpaceOnUse" x="0" y="0" width={LOGO.width} height={LOGO.height}>
          <rect width={LOGO.width} height={LOGO.height} fill="black" />
          {animate &&
            schedule.map((s, i) => (
              <path
                key={i}
                d={s.d}
                pathLength={1}
                fill="none"
                stroke="white"
                strokeWidth={s.width}
                strokeLinecap="round"
                strokeLinejoin="round"
                className="pen-stroke"
                style={{ animationDuration: `${s.duration}ms`, animationDelay: `${s.delay}ms` }}
              />
            ))}
        </mask>
      </defs>
      <g fill="currentColor" fillRule="evenodd" mask={animate ? `url(#pen-${uid})` : undefined}>
        {FILL_ORDER.map((k) => (
          <path key={k} d={LOGO.fills[k]} />
        ))}
      </g>
      {animate && (
        <g fill="currentColor" fillRule="evenodd" className={done ? "logo-settle is-done" : "logo-settle"} aria-hidden>
          {FILL_ORDER.map((k) => (
            <path key={k} d={LOGO.fills[k]} />
          ))}
        </g>
      )}
    </svg>
  );
}

/** Crop windows (in logo coordinates) isolating recognisable parts of the word. */
export const MOTIF_CROPS = {
  word: LOGO.viewBox,
  fa: "735 0 260 320", // ف with its dot
  sad: "560 110 240 230", // ص bowl
  ya: "230 150 360 210", // ي teeth
  ha: "0 120 330 341", // ح and its sweeping tail
  knot: "236 304 258 82", // the knot symbol (drawn alone, see LogoOutline)
} as const;
export type MotifPart = keyof typeof MOTIF_CROPS;

/**
 * Outline of the real logo (or a cropped part of it), optionally drawn as a
 * slow calligraphic trail. Used for background ornaments and section motifs.
 */
export function LogoOutline({
  part = "word",
  className,
  draw = false,
  drawMs = 5200,
  delayMs = 0,
  strokeWidth = 1.4,
  style,
}: {
  part?: MotifPart;
  className?: string;
  draw?: boolean;
  drawMs?: number;
  delayMs?: number;
  strokeWidth?: number;
  style?: CSSProperties;
}) {
  const reduced = usePrefersReducedMotion();
  const animate = draw && !reduced;
  return (
    <svg className={className} viewBox={MOTIF_CROPS[part]} aria-hidden="true" focusable="false" style={style} preserveAspectRatio="xMidYMid meet">
      <g fill="none" stroke="currentColor" strokeWidth={strokeWidth} vectorEffect="non-scaling-stroke" strokeLinejoin="round">
        {(part === "knot" ? (["knot"] as const) : FILL_ORDER).map((k, i) => (
          <path
            key={k}
            d={LOGO.fills[k]}
            vectorEffect="non-scaling-stroke"
            pathLength={animate ? 1 : undefined}
            className={animate ? "trail-stroke" : undefined}
            style={animate ? { animationDuration: `${drawMs}ms`, animationDelay: `${delayMs + i * 180}ms` } : undefined}
          />
        ))}
      </g>
    </svg>
  );
}
