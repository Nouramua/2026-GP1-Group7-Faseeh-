import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

/**
 * Rule-based contextual help for «نقطة». Pages publish a topic describing what
 * the user is doing; the assistant shows the matching guidance. No generative
 * AI is involved.
 */
export type AssistantTopic =
  | "home"
  | "ws-empty"
  | "ws-typing"
  | "ws-invalid"
  | "ws-analyzing"
  | "ws-analyzed"
  | "ws-stale"
  | "ws-target"
  | "ws-simplifier-off"
  | "ws-simplifying"
  | "ws-result"
  | "ws-error"
  | "history"
  | "history-empty"
  | "detail"
  | "stats"
  | "stats-empty"
  | "auth"
  | "profile"
  | "default";

interface Ctx {
  topic: AssistantTopic;
  setTopic: (t: AssistantTopic) => void;
}

const AssistantCtx = createContext<Ctx>({ topic: "default", setTopic: () => {} });

export function AssistantProvider({ children }: { children: ReactNode }) {
  const [topic, setTopic] = useState<AssistantTopic>("default");
  const value = useMemo(() => ({ topic, setTopic }), [topic]);
  return <AssistantCtx.Provider value={value}>{children}</AssistantCtx.Provider>;
}

export function useAssistantTopic(topic: AssistantTopic) {
  const { setTopic } = useContext(AssistantCtx);
  useEffect(() => setTopic(topic), [topic, setTopic]);
}

export const useAssistant = () => useContext(AssistantCtx);

export interface Tip {
  title: string;
  body: string;
  mood: "idle" | "think" | "happy" | "concern";
}

export const TIPS: Record<AssistantTopic, Tip> = {
  home: {
    title: "أهلًا، أنا نقطة!",
    body: "أرافقك في فصيح. ابدأ من «مساحة العمل»: ألصق نصًّا عربيًّا، وسأشرح لك كل خطوة حتى تحصل على نسخة أوضح.",
    mood: "happy",
  },
  "ws-empty": {
    title: "الخطوة الأولى: النص",
    body: "اكتب نصًّا عربيًّا أو ألصقه في المربع. يمكن أن يكون جملة أو فقرة قصيرة، ثم اضغط «حلّل المقروئية».",
    mood: "idle",
  },
  "ws-typing": {
    title: "جاهز للتحليل؟",
    body: "حين تنتهي من النص اضغط «حلّل المقروئية». سيعطي النموذج النص مستوى من ١ (الأسهل) إلى ٤ (الأصعب).",
    mood: "idle",
  },
  "ws-invalid": {
    title: "لنصحّح النص معًا",
    body: "يقبل فصيح النصوص العربية فقط، ويجب ألّا يكون النص فارغًا. اقرأ الرسالة تحت المربع لتعرف السبب.",
    mood: "concern",
  },
  "ws-analyzing": {
    title: "أقرأ نصّك الآن…",
    body: "يحلّل فصيح نصّك ويقدّر مستوى مقروئيته من ١ إلى ٤.",
    mood: "think",
  },
  "ws-analyzed": {
    title: "هذا مستوى نصّك",
    body: "المستوى ١ هو الأسهل و٤ هو الأصعب. بعدها اختر المستوى الذي تريده.",
    mood: "happy",
  },
  "ws-stale": {
    title: "تغيّر النص",
    body: "عدّلتَ النص بعد تحليله، لذلك لم تعد النتيجة تمثّله. أعد التحليل قبل اختيار مستوى التبسيط.",
    mood: "concern",
  },
  "ws-target": {
    title: "كيف أختار المستوى؟",
    body: "اختر المستوى الذي يناسب القارئ: ١ للمبتدئين والأطفال، ٢ للقراءة اليومية السهلة، ٣ لطلاب المراحل المتقدمة. هذا المستوى هو هدف التبسيط، ولن يُعرض نص لا يطابقه.",
    mood: "idle",
  },
  "ws-simplifier-off": {
    title: "التبسيط غير متاح بعد",
    body: "نموذج التبسيط ما زال قيد التطوير ولم يُربط بالمنصّة. لن يعرض فصيح نصًّا مولّدًا وهميًّا؛ يمكنك الآن تحليل المقروئية وحفظ النتيجة.",
    mood: "concern",
  },
  "ws-simplifying": {
    title: "أبسّط النص…",
    body: "يرسل فصيح النص والمستوى الذي اخترته إلى نموذج التبسيط، ثم يتحقق من أن النص الجديد يطابق هذا المستوى قبل عرضه.",
    mood: "think",
  },
  "ws-result": {
    title: "قارن بين النسختين",
    body: "على اليمين نصّك الأصلي، وعلى اليسار النص المبسّط للمستوى الذي اخترته. يمكنك نسخه أو تكبير خطه أو حفظه، وتقييمك يساعدنا على التحسين.",
    mood: "happy",
  },
  "ws-error": {
    title: "حدث خلل بسيط",
    body: "لم يكتمل الطلب، ولم يُحتسب في إحصاءاتك. نصّك ما زال محفوظًا في المربع؛ اضغط «أعد المحاولة».",
    mood: "concern",
  },
  history: {
    title: "سجلّك الشخصي",
    body: "هنا النتائج التي حفظتها فقط. افتح أي سجل لرؤيته كاملًا كما حُفظ، دون إعادة تشغيل النماذج.",
    mood: "idle",
  },
  "history-empty": {
    title: "السجل فارغ",
    body: "بعد أي تحليل أو تبسيط اضغط «احفظ النتيجة» لتجدها هنا لاحقًا.",
    mood: "idle",
  },
  detail: {
    title: "نتيجة محفوظة",
    body: "تُعرض القيم كما حُفظت. يمكنك نسخ النص أو تغيير حجم الخط أو حذف السجل.",
    mood: "idle",
  },
  stats: {
    title: "إحصاءات استخدامك",
    body: "تُحتسب العمليات الناجحة فقط. حذف سجل محفوظ لا يُنقص عدد العمليات التي أجريتها.",
    mood: "happy",
  },
  "stats-empty": {
    title: "لا أرقام بعد",
    body: "ستظهر إحصاءاتك بعد أول تحليل ناجح وأنت مسجّل الدخول.",
    mood: "idle",
  },
  auth: {
    title: "حسابك في فصيح",
    body: "تُدار الحسابات عبر Firebase Authentication، فلا يخزّن فصيح كلمة مرورك. كلمة المرور: ٨ أحرف على الأقل، فيها حرف كبير وحرف صغير ورقم ورمز خاص.",
    mood: "idle",
  },
  profile: {
    title: "صفحة حسابك",
    body: "هنا ترى بريدك وتاريخ إنشاء حسابك، ويمكنك تغيير البريد أو حذف الحساب. كلا الأمرين يحتاج كلمة المرور الحالية للتأكيد.",
    mood: "idle",
  },
  default: {
    title: "كيف أساعدك؟",
    body: "اختر سؤالًا من الأسئلة الشائعة أدناه.",
    mood: "idle",
  },
};

export const FAQ: { q: string; a: string }[] = [
  {
    q: "ما معنى «مقروئية النص»؟",
    a: "المقروئية هي مدى سهولة قراءة النص وفهمه. يقدّرها فصيح بنموذج تعلّم آلي دُرّب على نصوص عربية مصنّفة بحسب صعوبتها.",
  },
  {
    q: "ما المستويات الأربعة؟",
    a: "١ تأسيسي (سهل جدًا)، ٢ ميسَّر (سهل)، ٣ متوسط، ٤ متقدّم.",
  },
  {
    q: "ماذا لو لم يصل التبسيط إلى المستوى الذي اخترته؟",
    a: "لا يعرض فصيح نصًّا لا يطابق المستوى المختار. ستظهر لك رسالة واضحة، ويمكنك إعادة المحاولة أو اختيار مستوى آخر.",
  },
  {
    q: "هل تُحفظ نصوصي؟",
    a: "في الإصدار الحالي لا تُحفظ نصوصك. حفظ النتائج والسجل يصلان في الإصدار الثاني، ولن يرى بياناتك غيرك.",
  },
  {
    q: "لماذا لا أستطيع اختيار مستوى أصعب؟",
    a: "التبسيط ينقل النص إلى مستوى أسهل فقط، لذلك تظهر المستويات الأسهل من مستوى نصّك قابلة للاختيار.",
  },
];
