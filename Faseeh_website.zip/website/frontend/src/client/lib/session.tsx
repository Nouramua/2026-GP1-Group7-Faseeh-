import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import type { AppConfig, PublicUser } from "../../shared/api";
import { api } from "./api";

/**
 * The C2a session state (Guest ↔ Authenticated) as seen by the interface.
 *
 * The truth lives in the PHP backend, which verifies the Firebase session
 * cookie. This provider only mirrors it: it asks GET /api/auth/session on
 * load, whenever the tab becomes visible again, every 5 minutes, and on every
 * entry to a protected page (RequireAuth). When a session that existed is no
 * longer valid, the interface returns to Guest and shows "session ended"
 * (Log Out AC5, Jira FSEEH-113).
 */
interface SessionState {
  /** the signed-in user, or null for a guest */
  user: PublicUser | null;
  /** true until the first session check has answered (avoids flashing the guest header) */
  loading: boolean;
  /** true once a session that existed has been found expired or revoked */
  expired: boolean;
  /** Workspace feature switches (demonstration in Release 1) */
  config: AppConfig | null;
  /** true when the configuration could not be loaded */
  configError: boolean;
  /** sets the user after login, registration, email change or account deletion */
  setUser: (u: PublicUser | null) => void;
  /** re-asks the backend for the session state and returns the user (or null) */
  refreshSession: () => Promise<PublicUser | null>;
  /** reloads the Workspace configuration */
  refreshConfig: () => Promise<void>;
  /** logs out on the server and clears private state in the page */
  logout: () => Promise<void>;
  /** acknowledges the "session ended" message so it is shown only once */
  clearExpired: () => void;
}

const Ctx = createContext<SessionState | null>(null);
/** Background re-check interval for an open tab. */
const RECHECK_MS = 5 * 60_000;

/** Removes the Workspace draft, so nothing private stays for the next visitor (Log Out AC4). */
function clearPrivateUiState() {
  try {
    sessionStorage.removeItem("faseeh:workspace");
  } catch {
    /* storage unavailable */
  }
}

export function SessionProvider({ children }: { children: ReactNode }) {
  const [user, setUserState] = useState<PublicUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [expired, setExpired] = useState(false);
  const [config, setConfig] = useState<AppConfig | null>(null);
  const [configError, setConfigError] = useState(false);
  // A ref mirrors `user` so the async callbacks below always see the latest value.
  const userRef = useRef<PublicUser | null>(null);

  const setUser = useCallback((u: PublicUser | null) => {
    userRef.current = u;
    setUserState(u);
    if (u) setExpired(false);
  }, []);

  const refreshSession = useCallback(async () => {
    try {
      const r = await api.session();
      if (!r.user && userRef.current) {
        // Authenticated → Guest without a logout: the session expired (C2a)
        clearPrivateUiState();
        setExpired(true);
      }
      setUser(r.user);
      return r.user;
    } catch {
      // Backend unreachable: keep the current state; protected pages re-check on entry.
      return userRef.current;
    } finally {
      setLoading(false);
    }
  }, [setUser]);

  const refreshConfig = useCallback(async () => {
    try {
      setConfig(await api.config());
      setConfigError(false);
    } catch {
      setConfigError(true);
    }
  }, []);

  // On start: check the session and load the configuration; then keep the session state fresh.
  useEffect(() => {
    void refreshSession();
    void refreshConfig();
    // Returning to the tab (e.g. after a long break) re-checks immediately.
    const onFocus = () => {
      if (document.visibilityState === "visible") void refreshSession();
    };
    document.addEventListener("visibilitychange", onFocus);
    const t = window.setInterval(() => void refreshSession(), RECHECK_MS);
    return () => {
      document.removeEventListener("visibilitychange", onFocus);
      window.clearInterval(t);
    };
  }, [refreshSession, refreshConfig]);

  const logout = useCallback(async () => {
    try {
      await api.logout();
    } finally {
      // Even if the request fails, the page forgets the user: Log Out AC4,
      // nothing private stays on screen for the next visitor.
      clearPrivateUiState();
      setUser(null);
    }
  }, [setUser]);

  const value = useMemo(
    () => ({
      user,
      loading,
      expired,
      config,
      configError,
      setUser,
      refreshSession,
      refreshConfig,
      logout,
      clearExpired: () => setExpired(false),
    }),
    [user, loading, expired, config, configError, setUser, refreshSession, refreshConfig, logout],
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useSession(): SessionState {
  const v = useContext(Ctx);
  if (!v) throw new Error("useSession outside provider");
  return v;
}
