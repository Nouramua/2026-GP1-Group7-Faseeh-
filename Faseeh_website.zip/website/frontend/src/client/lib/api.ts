/**
 * The one place that decides which service each part of the interface uses.
 *
 * Release 1:
 *   • accounts & sessions      → PHP backend + Firebase Authentication / Firestore (real)
 *   • analysis/simplification  → design demonstration with labelled sample data;
 *                                the models are connected in Release 2 (story 36, Sprint 4)
 *   • saving, rating, history, statistics → not available until Release 2
 *     (stories 15–22); every call is rejected with a clear "Release 2" error
 */
import { demoService } from "../services/demo/demoService";
import { ApiRequestError } from "../services/errors";
import { authService } from "../services/http";
import type { FaseehService } from "../services/types";

export { ApiRequestError } from "../services/errors";

/** Rejects a Release 2 operation; nothing is sent or stored. */
const releaseTwo = (): Promise<never> =>
  Promise.reject(new ApiRequestError("not_available", "تتوفر هذه الميزة في الإصدار الثاني من فصيح.", 0));

export const api: FaseehService = {
  ...authService,
  config: demoService.config,
  analyze: demoService.analyze,
  simplify: demoService.simplify,
  save: releaseTwo,
  rate: releaseTwo, // Rate Simplification Results and Give Feedback is Release 2 (story 21)
  history: releaseTwo,
  historyItem: releaseTwo,
  deleteHistory: releaseTwo,
  stats: releaseTwo,
};

/** Analysis and simplification results are demonstrations in this release (labelled «عيّنة» / «محاكاة»). */
export const isDemo = true;
/** Saving, history, ratings and statistics arrive in Release 2; controls for them stay hidden or say so. */
export const recordsAvailable = false;
