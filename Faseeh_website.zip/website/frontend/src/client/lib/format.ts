const dateFmt = new Intl.DateTimeFormat("ar-SA-u-ca-gregory-nu-arab", { day: "numeric", month: "long", year: "numeric" });
const timeFmt = new Intl.DateTimeFormat("ar-SA-u-ca-gregory-nu-arab", { hour: "numeric", minute: "2-digit" });
const numFmt = new Intl.NumberFormat("ar-SA-u-nu-arab");

export const fmtDate = (iso: string) => dateFmt.format(new Date(iso));
export const fmtTime = (iso: string) => timeFmt.format(new Date(iso));
export const fmtDateTime = (iso: string) => `${fmtDate(iso)} · ${fmtTime(iso)}`;
export const fmtNum = (n: number) => numFmt.format(n);
