import { useEffect, useState, type ReactNode } from "react";
import { Link, Navigate, Route, Routes, useLocation } from "react-router-dom";
import { Layout } from "./components/Layout";
import { EmptyState, Spinner } from "./components/ui";
import { useAssistantTopic } from "./lib/assistant";
import { useSession } from "./lib/session";
import { ForgotPassword, Login, Register, ResetPassword } from "./pages/Auth";
import { About } from "./pages/About";
import { Home } from "./pages/Home";
import { Profile } from "./pages/Profile";
import { Workspace } from "./pages/Workspace";

/**
 * Protected pages (Log In AC6, Jira FSEEH-84): the session is re-verified with
 * the PHP backend on every entry; without a valid session (never signed in,
 * logged out, or expired) the user is sent to the sign-in page. The backend
 * enforces the same rule on every protected request, so this guard is for the
 * interface only and is not the security boundary.
 */
function RequireAuth({ children }: { children: ReactNode }) {
  const { refreshSession } = useSession();
  const location = useLocation();
  const [state, setState] = useState<"checking" | "in" | "out">("checking");
  useEffect(() => {
    // `live` ignores an answer that arrives after the user has already navigated away.
    let live = true;
    setState("checking");
    void refreshSession().then((u) => live && setState(u ? "in" : "out"));
    return () => {
      live = false;
    };
  }, [refreshSession, location.pathname]);
  if (state === "checking")
    return (
      <div className="container page page--center">
        <Spinner label="جارٍ التحقق من الجلسة" />
      </div>
    );
  if (state === "out") return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  return <>{children}</>;
}

/**
 * History and usage statistics are Release 2 (stories 16–20). In Release 1 the
 * pages exist behind real authentication and say so; nothing is listed or counted.
 */
function ReleaseTwoPage({ kind }: { kind: "history" | "stats" }) {
  useAssistantTopic(kind === "history" ? "history-empty" : "stats-empty");
  const title = kind === "history" ? "سجلّي" : "إحصاءاتي";
  return (
    <div className="container page">
      <header className="page-head">
        <h1 className="page-title">{title}</h1>
        <p className="page-lede">هذه صفحة خاصة بحسابك، ولا تظهر إلا بعد تسجيل الدخول.</p>
      </header>
      <EmptyState
        title={kind === "history" ? "حفظ النتائج يصل في الإصدار الثاني" : "إحصاءات الاستخدام تصل في الإصدار الثاني"}
        body={
          kind === "history"
            ? "سيُتاح حفظ نتائج التحليل والتبسيط ومراجعتها هنا بعد ربط النماذج بالمنصّة في الإصدار الثاني."
            : "ستظهر هنا أعداد عمليات التحليل والتبسيط الناجحة الخاصة بحسابك بعد ربط النماذج في الإصدار الثاني."
        }
        motif={kind === "history" ? "sad" : "ya"}
        action={
          <Link to="/workspace" className="btn btn--soft">
            جرّب مساحة العمل
          </Link>
        }
      />
    </div>
  );
}

function NotFound() {
  useAssistantTopic("default");
  return (
    <div className="container page">
      <EmptyState
        title="الصفحة غير موجودة"
        body="ربما تغيّر الرابط أو كُتب بشكل خاطئ."
        motif="knot"
        action={
          <Link to="/" className="btn btn--primary">
            العودة إلى الرئيسية
          </Link>
        }
      />
    </div>
  );
}

export function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/workspace" element={<Workspace />} />
        <Route path="/history" element={<RequireAuth><ReleaseTwoPage kind="history" /></RequireAuth>} />
        <Route path="/history/:id" element={<RequireAuth><ReleaseTwoPage kind="history" /></RequireAuth>} />
        <Route path="/stats" element={<RequireAuth><ReleaseTwoPage kind="stats" /></RequireAuth>} />
        <Route path="/profile" element={<RequireAuth><Profile /></RequireAuth>} />
        <Route path="/about" element={<About />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Layout>
  );
}
