import { useEffect, useState, type FormEvent } from "react";
import { useNavigate } from "react-router-dom";
import type { AccountProfile } from "../../shared/api";
import { validateEmail } from "../../shared/validation";
import { Dialog, Field, Notice, PasswordInput, Spinner } from "../components/ui";
import { ApiRequestError, api } from "../lib/api";
import { useAssistantTopic } from "../lib/assistant";
import { fmtDate } from "../lib/format";
import { useSession } from "../lib/session";
import { useToast } from "../lib/toast";

type Errors = Record<string, string | undefined>;

function apiErrors(e: unknown): { fields: Errors; message: string | null } {
  if (e instanceof ApiRequestError) return { fields: e.fields, message: Object.keys(e.fields).length ? null : e.message };
  return { fields: {}, message: "حدث خطأ غير متوقع. حاول مرة أخرى." };
}

/**
 * My Account: view the profile, change the email (Edit Profile, backlog story 5,
 * Jira FSEEH-49) and delete the account (backlog story 6, Jira FSEEH-50).
 * Protected page; the backend acts only on the signed-in user's own account.
 */
export function Profile() {
  useAssistantTopic("profile");
  const { user, setUser, refreshSession } = useSession();
  const toast = useToast();
  const navigate = useNavigate();

  /**
   * C2a "session expires → Guest" (Log Out AC5, backlog story 4, Jira FSEEH-113).
   * If the backend answers 401, the session cookie expired or was revoked while
   * this page was open. Re-checking the session switches the interface to the
   * guest state (the layout then shows "your session ended"), and the user is
   * sent to the login page, as for any protected page without a valid session.
   *
   * @param e the error thrown by an account request
   * @returns true when the error was a lost session and has been handled
   */
  const handleLostSession = async (e: unknown): Promise<boolean> => {
    // Only 401 means "no valid session"; a wrong current password is a 400 field error.
    if (!(e instanceof ApiRequestError) || e.status !== 401) return false;
    await refreshSession();
    navigate("/login", { replace: true });
    return true;
  };
  const [profile, setProfile] = useState<{ status: "loading" } | { status: "error"; message: string } | { status: "ok"; data: AccountProfile }>({ status: "loading" });

  // Edit Profile (change e-mail)
  const [newEmail, setNewEmail] = useState("");
  const [emailPw, setEmailPw] = useState("");
  const [emailErr, setEmailErr] = useState<Errors>({});
  const [emailMsg, setEmailMsg] = useState<string | null>(null);
  const [emailBusy, setEmailBusy] = useState(false);

  // Delete Account
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [deletePw, setDeletePw] = useState("");
  const [deleteErr, setDeleteErr] = useState<Errors>({});
  const [deleteMsg, setDeleteMsg] = useState<string | null>(null);
  const [deleteBusy, setDeleteBusy] = useState(false);

  const load = () => {
    setProfile({ status: "loading" });
    api
      .account()
      .then((r) => setProfile({ status: "ok", data: r.profile }))
      .catch(async (e) => {
        if (await handleLostSession(e)) return;
        setProfile({ status: "error", message: e instanceof ApiRequestError ? e.message : "تعذّر تحميل بيانات حسابك." });
      });
  };
  useEffect(load, []);

  const submitEmail = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const errs: Errors = {
      newEmail: validateEmail(newEmail) ?? undefined,
      currentPassword: emailPw ? undefined : "يرجى إدخال كلمة المرور الحالية.",
    };
    setEmailErr(errs);
    setEmailMsg(null);
    if (errs.newEmail || errs.currentPassword) {
      requestAnimationFrame(() => (form.querySelector('[aria-invalid="true"]') as HTMLElement | null)?.focus());
      return;
    }
    setEmailBusy(true);
    try {
      const r = await api.changeEmail(newEmail.trim(), emailPw);
      setUser(r.user);
      setProfile((p) => (p.status === "ok" ? { status: "ok", data: { ...p.data, email: r.user.email } } : p));
      setNewEmail("");
      setEmailPw("");
      toast("تم تغيير بريدك الإلكتروني.", "success");
    } catch (err) {
      // A wrong current password is a 400 with a field error, so only a lost session lands here.
      if (await handleLostSession(err)) return;
      const { fields, message } = apiErrors(err);
      setEmailErr(fields);
      setEmailMsg(message);
    } finally {
      setEmailBusy(false);
    }
  };

  const closeDelete = () => {
    setConfirmOpen(false);
    setDeletePw("");
    setDeleteErr({});
    setDeleteMsg(null);
  };

  const confirmDelete = async () => {
    if (!deletePw) {
      setDeleteErr({ currentPassword: "يرجى إدخال كلمة المرور لتأكيد حذف الحساب." });
      return;
    }
    setDeleteBusy(true);
    setDeleteErr({});
    setDeleteMsg(null);
    try {
      await api.deleteAccount(deletePw);
      try {
        sessionStorage.removeItem("faseeh:workspace");
      } catch {
        /* storage unavailable */
      }
      setUser(null);
      setConfirmOpen(false);
      toast("حُذف حسابك وكل بياناته.", "success");
      navigate("/", { replace: true });
    } catch (err) {
      if (await handleLostSession(err)) {
        setConfirmOpen(false);
        return;
      }
      const { fields, message } = apiErrors(err);
      setDeleteErr(fields);
      setDeleteMsg(message);
    } finally {
      setDeleteBusy(false);
    }
  };

  return (
    <div className="container page profile">
      <header className="page-head">
        <h1 className="page-title">حسابي</h1>
        <p className="page-lede">بيانات حسابك في فصيح. لا تظهر هذه الصفحة إلا لك بعد تسجيل الدخول.</p>
      </header>

      {/* View Profile */}
      <section className="panel" aria-labelledby="pf-info">
        <h2 id="pf-info" className="panel__title">
          بيانات الحساب
        </h2>
        {profile.status === "loading" && <Spinner label="جارٍ تحميل بيانات الحساب" />}
        {profile.status === "error" && (
          <>
            <Notice tone="error">{profile.message}</Notice>
            <button type="button" className="btn btn--soft btn--sm" onClick={load}>
              أعد المحاولة
            </button>
          </>
        )}
        {profile.status === "ok" && (
          <dl className="profile__facts">
            <div>
              <dt>البريد الإلكتروني</dt>
              <dd dir="ltr">{user?.email ?? profile.data.email}</dd>
            </div>
            {profile.data.createdAt && (
              <div>
                <dt>عضو منذ</dt>
                <dd>{fmtDate(profile.data.createdAt)}</dd>
              </div>
            )}
          </dl>
        )}
      </section>

      {/* Edit Profile */}
      <section className="panel" aria-labelledby="pf-edit">
        <h2 id="pf-edit" className="panel__title">
          تعديل البريد الإلكتروني
        </h2>
        <p className="panel__sub">ستستخدم البريد الجديد لتسجيل الدخول. للتأكيد، أدخل كلمة المرور الحالية.</p>
        <form noValidate onSubmit={submitEmail} className="form profile__form">
          {emailMsg && <Notice tone="error">{emailMsg}</Notice>}
          <Field label="البريد الإلكتروني الجديد" error={emailErr.newEmail}>
            {(p) => <input {...p} className="input" type="email" dir="ltr" autoComplete="email" value={newEmail} onChange={(e) => setNewEmail(e.target.value)} />}
          </Field>
          <Field label="كلمة المرور الحالية" error={emailErr.currentPassword}>
            {(p) => <PasswordInput {...p} autoComplete="current-password" value={emailPw} onChange={(e) => setEmailPw(e.target.value)} />}
          </Field>
          <div>
            <button type="submit" className="btn btn--primary" disabled={emailBusy} aria-busy={emailBusy}>
              {emailBusy ? <Spinner /> : null}
              احفظ البريد الجديد
            </button>
          </div>
        </form>
      </section>

      {/* Delete Account */}
      <section className="panel profile__danger" aria-labelledby="pf-delete">
        <h2 id="pf-delete" className="panel__title">
          حذف الحساب
        </h2>
        <p className="panel__sub">يُحذف حسابك وملفك الشخصي نهائيًا، ولا يمكن التراجع عن ذلك.</p>
        <div className="panel__actions">
          <button type="button" className="btn btn--ghost-danger" onClick={() => setConfirmOpen(true)}>
            حذف الحساب
          </button>
        </div>
      </section>

      <Dialog
        open={confirmOpen}
        onClose={closeDelete}
        title="حذف الحساب نهائيًا؟"
        actions={
          <>
            <button type="button" className="btn btn--danger" onClick={confirmDelete} disabled={deleteBusy} aria-busy={deleteBusy}>
              {deleteBusy ? <Spinner /> : null}
              نعم، احذف حسابي
            </button>
            <button type="button" className="btn btn--ghost" onClick={closeDelete} disabled={deleteBusy}>
              إلغاء
            </button>
          </>
        }
      >
        <p>سيُحذف حسابك وملفك الشخصي ولن تتمكن من تسجيل الدخول به مرة أخرى. أدخل كلمة المرور للتأكيد.</p>
        {deleteMsg && <Notice tone="error">{deleteMsg}</Notice>}
        <Field label="كلمة المرور" error={deleteErr.currentPassword}>
          {(p) => (
            <PasswordInput
              {...p}
              autoComplete="current-password"
              value={deletePw}
              onChange={(e) => setDeletePw(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  void confirmDelete();
                }
              }}
            />
          )}
        </Field>
      </Dialog>
    </div>
  );
}
