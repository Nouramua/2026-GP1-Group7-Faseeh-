import { Link } from "react-router-dom";
import { LogoOutline } from "../brand/Logo";
import { Mascot } from "../brand/Mascot";
import { useAssistantTopic } from "../lib/assistant";
import { useReveal } from "../lib/motion";

const TEAM = ["نورة المعيلي", "العنود السند", "جنى العثمان", "نورة التويم"];

const PIPELINE = [
  { title: "النص العربي", body: "جملة أو فقرة يُدخلها المستخدم." },
  { title: "مصنِّف المقروئية", body: "يمنح النص مستوى مقروئية واحدًا من ١ إلى ٤." },
  { title: "المستوى المستهدف", body: "يختاره المستخدم بنفسه بحسب القارئ." },
  { title: "نموذج التبسيط", body: "يعيد صياغة النص نحو المستوى المختار مع الحفاظ على المعنى." },
  { title: "التحقق من المستوى", body: "لا يُعرض النص المبسّط إلا إذا طابق المستوى الذي اختاره المستخدم." },
];

function Block({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  const ref = useReveal<HTMLDivElement>();
  return (
    <div ref={ref} className={`reveal ${className}`}>
      {children}
    </div>
  );
}

export function About() {
  useAssistantTopic("default");
  return (
    <div className="about">
      <section className="about-hero">
        <LogoOutline className="about-hero__word" draw drawMs={4200} strokeWidth={1.2} />
        <div className="container about-hero__inner">
          <p className="about-hero__kicker">مشروع تخرّج · جامعة الملك سعود</p>
          <h1 className="about-hero__title">لغة عربية أوضح لقرّاء أكثر</h1>
          <p className="about-hero__lede">
            كثير من النصوص العربية المتاحة اليوم أصعب مما يحتمله طلاب المدارس ومتعلّمو العربية وذوو صعوبات القراءة. يجمع فصيح مهمتين في مسار واحد: قياس صعوبة النص، ثم تبسيطه إلى المستوى الذي يختاره القارئ.
          </p>
        </div>
      </section>

      <section className="container about-flow" aria-labelledby="flow-h">
        <Block className="section-head">
          <h2 id="flow-h" className="display-title">
            كيف يمرّ النص داخل فصيح
          </h2>
          <p className="section-lede">مسار من خمس محطات؛ كل محطة تسلّم ما بعدها.</p>
        </Block>
        <ol className="pipeline">
          {PIPELINE.map((p, i) => (
            <li key={p.title} className="pipeline__step reveal is-in" style={{ ["--d" as string]: `${i * 120}ms` }}>
              <span className="pipeline__n" aria-hidden="true">
                {["١", "٢", "٣", "٤", "٥"][i]}
              </span>
              <h3>{p.title}</h3>
              <p>{p.body}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="container about-cols">
        <Block className="about-card">
          <h2 className="about-card__h">البيانات</h2>
          <p>
            دُرّب مصنِّف فصيح على نصوص عربية مصنّفة مسبقًا بحسب صعوبة قراءتها، وتُعرض نتائجه على أربعة مستويات مرتّبة من الأسهل إلى الأصعب.
          </p>
        </Block>
        <Block className="about-card">
          <h2 className="about-card__h">التصنيف</h2>
          <p>
            قارن الفريق نماذج تقليدية (SVM، الغابات العشوائية، أشجار القرار، XGBoost) ونماذج تعلّم عميق، وقيّمها بمعامل كابا الموزون تربيعيًا ودقة الخطأ بمستوى واحد.
          </p>
        </Block>
        <Block className="about-card">
          <h2 className="about-card__h">التبسيط</h2>
          <p>نموذج تبسيط يكتب النص بالمستوى الذي يختاره المستخدم، قيد التطوير، وسيُربط بهذه الواجهة في المرحلة القادمة.</p>
        </Block>
      </section>

      <section className="container about-team" aria-labelledby="team-h">
        <Block className="about-team__card">
          <div>
            <h2 id="team-h" className="display-title">
              الفريق
            </h2>
            <ul className="about-team__list">
              {TEAM.map((n) => (
                <li key={n}>{n}</li>
              ))}
            </ul>
            <p className="about-team__sup">
              بإشراف <strong>د. وجدان الخالدي</strong>
            </p>
            <p className="fine-print">قسم تقنية المعلومات · كلية علوم الحاسب والمعلومات · جامعة الملك سعود</p>
          </div>
          <div className="about-team__mascot" aria-hidden="true">
            <Mascot size={110} mood="happy" />
          </div>
        </Block>
        <div className="about-cta">
          <Link to="/workspace" className="btn btn--primary btn--lg">
            جرّب مساحة العمل
          </Link>
        </div>
      </section>
    </div>
  );
}
