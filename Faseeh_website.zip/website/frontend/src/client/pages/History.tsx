import { useCallback, useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import type { AnyResult, HistoryItem } from "../../shared/api";
import { LevelBadge } from "../components/Levels";
import { AnalysisView, ComparisonView } from "../components/Results";
import { Dialog, EmptyState, Notice, Spinner } from "../components/ui";
import { ApiRequestError, api } from "../lib/api";
import { useAssistantTopic } from "../lib/assistant";
import { fmtDateTime, fmtNum } from "../lib/format";
import { useToast } from "../lib/toast";

type Filter = "all" | "analysis" | "simplification";
const TYPE_LABEL = { analysis: "تحليل مقروئية", simplification: "تبسيط" } as const;

function DeleteDialog({ open, onClose, onConfirm, busy }: { open: boolean; onClose: () => void; onConfirm: () => void; busy: boolean }) {
  return (
    <Dialog
      open={open}
      onClose={onClose}
      title="حذف السجل؟"
      actions={
        <>
          <button type="button" className="btn btn--danger" onClick={onConfirm} disabled={busy}>
            {busy ? <Spinner /> : null}
            نعم، احذفه
          </button>
          <button type="button" className="btn btn--ghost" onClick={onClose} autoFocus>
            إلغاء
          </button>
        </>
      }
    >
      <p>سيُحذف هذا السجل نهائيًا من حسابك ولا يمكن استرجاعه. لن يتغيّر عدد العمليات في إحصاءاتك.</p>
    </Dialog>
  );
}

export function History() {
  const [state, setState] = useState<{ status: "loading" } | { status: "error"; message: string } | { status: "ok"; items: HistoryItem[] }>({ status: "loading" });
  const [filter, setFilter] = useState<Filter>("all");
  const [pending, setPending] = useState<HistoryItem | null>(null);
  const [busy, setBusy] = useState(false);
  const toast = useToast();
  const empty = state.status === "ok" && state.items.length === 0;
  useAssistantTopic(empty ? "history-empty" : "history");

  const load = useCallback(async () => {
    setState({ status: "loading" });
    try {
      const { items } = await api.history();
      setState({ status: "ok", items });
    } catch (e) {
      setState({ status: "error", message: e instanceof ApiRequestError ? e.message : "تعذّر تحميل السجل." });
    }
  }, []);
  useEffect(() => void load(), [load]);

  const confirmDelete = async () => {
    if (!pending || state.status !== "ok") return;
    setBusy(true);
    try {
      await api.deleteHistory(pending.id);
      setState({ status: "ok", items: state.items.filter((i) => i.id !== pending.id) });
      toast("حُذف السجل.", "success");
      setPending(null);
    } catch (e) {
      toast(e instanceof ApiRequestError ? e.message : "تعذّر الحذف. حاول مرة أخرى.", "error");
    } finally {
      setBusy(false);
    }
  };

  const items = state.status === "ok" ? state.items.filter((i) => filter === "all" || i.type === filter) : [];
  const counts = state.status === "ok" ? { all: state.items.length, analysis: state.items.filter((i) => i.type === "analysis").length, simplification: state.items.filter((i) => i.type === "simplification").length } : null;

  return (
    <div className="container page">
      <header className="page-head">
        <h1 className="page-title">سجلّي</h1>
        <p className="page-lede">النتائج التي حفظتها، مرتّبة من الأحدث. لا يراها أحد غيرك.</p>
      </header>

      {state.status === "loading" && (
        <ul className="history-list" aria-busy="true" aria-label="جارٍ تحميل السجل">
          {[0, 1, 2].map((i) => (
            <li key={i} className="history-item skeleton" />
          ))}
        </ul>
      )}
      {state.status === "error" && (
        <>
          <Notice tone="error" title="تعذّر تحميل السجل">
            {state.message}
          </Notice>
          <button type="button" className="btn btn--soft" onClick={load}>
            أعد المحاولة
          </button>
        </>
      )}
      {empty && (
        <EmptyState
          title="لم تحفظ أي نتيجة بعد"
          body="حلّل نصًّا في مساحة العمل، ثم اضغط «احفظ النتيجة» لتجده هنا."
          action={
            <Link to="/workspace" className="btn btn--primary">
              اذهب إلى مساحة العمل
            </Link>
          }
        />
      )}
      {state.status === "ok" && state.items.length > 0 && counts && (
        <>
          <div className="filters" role="tablist" aria-label="تصفية السجل">
            {(["all", "analysis", "simplification"] as Filter[]).map((f) => (
              <button key={f} type="button" role="tab" aria-selected={filter === f} className={`filter ${filter === f ? "is-on" : ""}`} onClick={() => setFilter(f)}>
                {f === "all" ? "الكل" : f === "analysis" ? "التحليلات" : "التبسيطات"}
                <span className="filter__n">{fmtNum(counts[f])}</span>
              </button>
            ))}
          </div>
          {items.length === 0 ? (
            <p className="fine-print">لا توجد سجلات من هذا النوع.</p>
          ) : (
            <ul className="history-list">
              {items.map((it, i) => (
                <li key={it.id} className="history-item" style={{ ["--d" as string]: `${Math.min(i, 8) * 40}ms` }}>
                  <Link to={`/history/${it.id}`} className="history-item__link">
                    <span className="history-item__type" data-type={it.type}>
                      {TYPE_LABEL[it.type]}
                    </span>
                    <span className="history-item__preview reading">{it.preview}</span>
                    <span className="history-item__meta">
                      <time dateTime={it.savedAt}>{fmtDateTime(it.savedAt)}</time>
                      <span className="history-item__levels">
                        <LevelBadge level={it.originalLevel} size="sm" />
                        {it.type === "simplification" && (
                          <>
                            <span className="compare__arrow compare__arrow--sm" aria-label="إلى" />
                            <LevelBadge level={it.targetLevel} size="sm" />
                          </>
                        )}
                      </span>
                    </span>
                  </Link>
                  <button type="button" className="icon-btn history-item__del" aria-label={`حذف سجل ${TYPE_LABEL[it.type]} بتاريخ ${fmtDateTime(it.savedAt)}`} onClick={() => setPending(it)}>
                    <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M5 7h14M10 7V5h4v2M7 7l1 12h8l1-12" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </>
      )}
      <DeleteDialog open={pending !== null} onClose={() => setPending(null)} onConfirm={confirmDelete} busy={busy} />
    </div>
  );
}

export function HistoryDetail() {
  const { id = "" } = useParams();
  const navigate = useNavigate();
  const toast = useToast();
  const [state, setState] = useState<{ status: "loading" } | { status: "error"; message: string; notFound: boolean } | { status: "ok"; result: AnyResult }>({ status: "loading" });
  const [confirm, setConfirm] = useState(false);
  const [busy, setBusy] = useState(false);
  useAssistantTopic("detail");

  useEffect(() => {
    api
      .historyItem(id)
      .then((result) => setState({ status: "ok", result }))
      .catch((e) =>
        setState({
          status: "error",
          message: e instanceof ApiRequestError ? e.message : "تعذّر تحميل السجل.",
          notFound: e instanceof ApiRequestError && e.code === "not_found",
        }),
      );
  }, [id]);

  const del = async () => {
    setBusy(true);
    try {
      await api.deleteHistory(id);
      toast("حُذف السجل.", "success");
      navigate("/history");
    } catch (e) {
      toast(e instanceof ApiRequestError ? e.message : "تعذّر الحذف.", "error");
      setBusy(false);
    }
  };

  return (
    <div className="container page">
      <nav aria-label="مسار التنقل" className="crumbs">
        <Link to="/history">سجلّي</Link>
        <span aria-hidden="true">‹</span>
        <span aria-current="page">تفاصيل السجل</span>
      </nav>
      {state.status === "loading" && <div className="panel skeleton skeleton--tall" aria-busy="true" />}
      {state.status === "error" &&
        (state.notFound ? (
          <EmptyState title="السجل غير موجود" body="ربما حُذف هذا السجل، أو أن الرابط لا يخص حسابك." motif="knot" action={<Link to="/history" className="btn btn--soft">العودة إلى السجل</Link>} />
        ) : (
          <Notice tone="error" title="تعذّر التحميل">
            {state.message}
          </Notice>
        ))}
      {state.status === "ok" && (
        <>
          <header className="page-head page-head--row">
            <div>
              <h1 className="page-title">{state.result.type === "analysis" ? "تحليل مقروئية" : "تبسيط نص"}</h1>
              <p className="page-lede">
                أُجري في <time dateTime={state.result.createdAt}>{fmtDateTime(state.result.createdAt)}</time> · معروض كما حُفظ
              </p>
            </div>
            <button type="button" className="btn btn--ghost-danger" onClick={() => setConfirm(true)}>
              حذف السجل
            </button>
          </header>
          {state.result.type === "analysis" ? (
            <section className="panel">
              <AnalysisView result={state.result} live={false} />
              <div className="passage passage--original passage--solo">
                <header className="passage__head">
                  <h2>النص الأصلي</h2>
                </header>
                <div className="passage__text reading" tabIndex={0}>
                  {state.result.originalText}
                </div>
              </div>
            </section>
          ) : (
            <ComparisonView
              result={state.result}
              onRated={(r) => state.result.type === "simplification" && setState({ status: "ok", result: { ...state.result, rating: r } })}
            />
          )}
        </>
      )}
      <DeleteDialog open={confirm} onClose={() => setConfirm(false)} onConfirm={del} busy={busy} />
    </div>
  );
}
