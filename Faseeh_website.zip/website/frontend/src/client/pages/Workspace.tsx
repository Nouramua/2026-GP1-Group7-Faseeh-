import { useEffect, useMemo, useRef, useState } from "react";
import type { AnalysisResult, SimplificationResult } from "../../shared/api";
import { LEVEL_INFO, type Level } from "../../shared/levels";
import { validateArabicText } from "../../shared/validation";
import { LogoOutline } from "../brand/Logo";
import { Mascot } from "../brand/Mascot";
import { LevelGuide, LevelPicker } from "../components/Levels";
import { AnalysisView, ComparisonView, SaveButton } from "../components/Results";
import { Dialog, Notice, ReadingLoader, Spinner } from "../components/ui";
import { ApiRequestError, api } from "../lib/api";
import { useAssistantTopic, type AssistantTopic } from "../lib/assistant";
import { fmtNum } from "../lib/format";
import { useSession } from "../lib/session";
import { SAMPLES } from "../services/demo/samples";

type Async<T> = { status: "idle" } | { status: "loading" } | { status: "success"; data: T } | { status: "error"; error: ApiRequestError };

const DRAFT = "faseeh:workspace";
function readDraft(): string {
  try {
    return sessionStorage.getItem(DRAFT) ?? "";
  } catch {
    return "";
  }
}

function Stepper({ step }: { step: 1 | 2 | 3 | 4 }) {
  const items = ["النص", "المقروئية", "المستوى المستهدف", "النتيجة"];
  return (
    <ol className="stepper" aria-label="مراحل العمل">
      {items.map((label, i) => {
        const n = (i + 1) as 1 | 2 | 3 | 4;
        const state = n < step ? "done" : n === step ? "current" : "todo";
        return (
          <li key={label} className={`stepper__item is-${state}`} aria-current={state === "current" ? "step" : undefined}>
            <span className="stepper__dot" aria-hidden="true">
              {state === "done" ? (
                <svg viewBox="0 0 24 24" width="14" height="14"><path d="M5 12.5l4.2 4L19 7" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" /></svg>
              ) : (
                ["١", "٢", "٣", "٤"][i]
              )}
            </span>
            <span className="stepper__label">{label}</span>
            {state === "done" && <span className="visually-hidden"> (مكتملة)</span>}
          </li>
        );
      })}
    </ol>
  );
}

/** Simplification in progress: rewrite toward the chosen level, then check it. */
function SimplifyProgress({ level }: { level: Level | null }) {
  const n = level ? LEVEL_INFO[level].numeral : "";
  return (
    <div className="sprogress" role="status" aria-live="polite">
      <ReadingLoader label={`يعيد فصيح صياغة النص للمستوى ${n}…`} />
      <ol className="sprogress__steps" aria-hidden="true">
        <li className="is-active">إعادة الصياغة</li>
        <li className="is-next">التحقق من مطابقة المستوى {n}</li>
        <li>عرض النص المبسّط</li>
      </ol>
    </div>
  );
}

/** Shown when no rewrite reached the chosen level: nothing off-level is displayed. */
function LevelNotMet({ level, onRetry, onChooseAnother }: { level: Level; onRetry: () => void; onChooseAnother: () => void }) {
  const info = LEVEL_INFO[level];
  return (
    <section className="panel unmet enter" role="alert" aria-labelledby="unmet-h">
      <Mascot size={56} mood="concern" />
      <div className="unmet__body">
        <h2 id="unmet-h" className="unmet__title">
          لم نصل إلى المستوى {info.numeral} ({info.name}) هذه المرة
        </h2>
        <p>
          لم تجتز أي صياغة التحقق من المستوى الذي اخترته، لذلك لا نعرض نصًّا لا يطابقه. نصّك ومستواه المختار محفوظان كما هما.
        </p>
        <div className="panel__actions">
          <button type="button" className="btn btn--primary" onClick={onRetry}>
            أعد المحاولة للمستوى {info.numeral}
          </button>
          <button type="button" className="btn btn--ghost" onClick={onChooseAnother}>
            اختر مستوى آخر
          </button>
        </div>
      </div>
    </section>
  );
}

export function Workspace() {
  const { config, configError, refreshConfig, user } = useSession();
  // The draft survives a reload in this tab (sessionStorage) and is cleared on logout.
  const [text, setText] = useState(readDraft);
  const [touched, setTouched] = useState(false);
  const [analysis, setAnalysis] = useState<Async<AnalysisResult>>({ status: "idle" });
  const [analyzedText, setAnalyzedText] = useState<string | null>(null);
  const [target, setTarget] = useState<Level | null>(null);
  const [simple, setSimple] = useState<Async<SimplificationResult>>({ status: "idle" });
  const [guide, setGuide] = useState(false);
  const textRef = useRef<HTMLTextAreaElement>(null);
  const resultRef = useRef<HTMLDivElement>(null);
  const compareRef = useRef<HTMLDivElement>(null);
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    try {
      sessionStorage.setItem(DRAFT, text);
    } catch {
      /* ignore */
    }
  }, [text]);
  useEffect(() => () => abortRef.current?.abort(), []);

  // Re-validate only when the text changes (empty / non-Arabic rules; no length limit).
  const validation = useMemo(() => validateArabicText(text), [text]);
  // Errors appear only after the user has interacted (blur or submit), never while first typing.
  const showError = touched && !validation.ok;
  const analyzed = analysis.status === "success" ? analysis.data : null;
  const stale = analyzed !== null && analyzedText !== text;
  const simplified = simple.status === "success" ? simple.data : null;
  const simplifierOn = config?.simplifierAvailable ?? false;

  const step: 1 | 2 | 3 | 4 = simplified ? 4 : analyzed && !stale ? (target ? 3 : 2) : 1;

  const topic: AssistantTopic =
    analysis.status === "loading"
      ? "ws-analyzing"
      : simple.status === "loading"
        ? "ws-simplifying"
        : analysis.status === "error" || simple.status === "error"
          ? "ws-error"
          : showError
            ? "ws-invalid"
            : simplified
              ? "ws-result"
              : stale
                ? "ws-stale"
                : analyzed
                  ? !simplifierOn
                    ? "ws-simplifier-off"
                    : target
                      ? "ws-target"
                      : "ws-analyzed"
                  : text.trim()
                    ? "ws-typing"
                    : "ws-empty";
  useAssistantTopic(topic);

  const runAnalysis = async () => {
    setTouched(true);
    if (!validation.ok) {
      textRef.current?.focus();
      return;
    }
    abortRef.current?.abort();
    const ac = new AbortController();
    abortRef.current = ac;
    setAnalysis({ status: "loading" });
    setSimple({ status: "idle" });
    setTarget(null);
    try {
      const data = await api.analyze(text, ac.signal);
      setAnalysis({ status: "success", data });
      setAnalyzedText(text);
      requestAnimationFrame(() => resultRef.current?.focus({ preventScroll: false }));
    } catch (e) {
      if ((e as Error).name === "AbortError") return;
      const err = e instanceof ApiRequestError ? e : new ApiRequestError("internal", "حدث خطأ غير متوقع.", 0);
      setAnalysis({ status: "error", error: err });
      if (err.code === "classifier_unavailable") void refreshConfig();
    }
  };

  const runSimplify = async () => {
    if (!analyzed || stale || !target) return;
    abortRef.current?.abort();
    const ac = new AbortController();
    abortRef.current = ac;
    setSimple({ status: "loading" });
    try {
      const data = await api.simplify(analyzed.originalText, target, analyzed.id, ac.signal);
      setSimple({ status: "success", data });
      requestAnimationFrame(() => compareRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }));
    } catch (e) {
      if ((e as Error).name === "AbortError") return;
      const err = e instanceof ApiRequestError ? e : new ApiRequestError("internal", "حدث خطأ غير متوقع.", 0);
      setSimple({ status: "error", error: err });
      if (err.code === "simplifier_unavailable") void refreshConfig();
    }
  };

  const clearAll = () => {
    abortRef.current?.abort();
    setText("");
    setTouched(false);
    setAnalysis({ status: "idle" });
    setAnalyzedText(null);
    setTarget(null);
    setSimple({ status: "idle" });
    textRef.current?.focus();
  };

  // While either request runs, inputs that would change the request are locked.
  const busy = analysis.status === "loading" || simple.status === "loading";

  return (
    <div className="workspace">
      <div className="workspace__deco" aria-hidden="true">
        <LogoOutline part="fa" className="workspace__deco-fa" strokeWidth={1} />
      </div>
      <div className="container">
        <header className="ws-head">
          <div>
            <h1 className="page-title">مساحة العمل</h1>
            <p className="page-lede">ألصق نصًّا عربيًّا، واعرف مستوى مقروئيته، ثم اختر المستوى الذي تريده.</p>
          </div>
          <button type="button" className="btn btn--ghost btn--sm" onClick={() => setGuide(true)}>
            ما المستويات الأربعة؟
          </button>
        </header>

        <Stepper step={step} />

        {configError && (
          <Notice tone="error" title="تعذّر الاتصال بالخادم">
            لا يمكن الوصول إلى خادم فصيح الآن. تحقّق من اتصالك ثم أعد تحميل الصفحة.
          </Notice>
        )}
        {config && !config.classifierAvailable && (
          <Notice tone="warn" title="خدمة تحليل المقروئية متوقفة">
            لا يستجيب نموذج التصنيف حاليًا، لذا قد يفشل التحليل. يمكنك كتابة النص والمحاولة بعد قليل.
          </Notice>
        )}

        {/* ── Step 1: input ───────────────────────────── */}
        <section className="panel panel--input" aria-labelledby="in-h">
          <div className="panel__head">
            <h2 id="in-h" className="panel__title">
              النص العربي
            </h2>
          </div>
          <div className="samples" role="group" aria-label="نصوص نموذجية">
            <span className="samples__label">جرّب نصًّا نموذجيًّا:</span>
            {SAMPLES.map((smp) => (
              <button
                key={smp.id}
                type="button"
                className={`sample-chip ${text.trim() === smp.text ? "is-on" : ""}`}
                disabled={busy}
                onClick={() => {
                  setText(smp.text);
                  setTouched(false);
                }}
              >
                <span className="sample-chip__title">{smp.title}</span>
                <span className="sample-chip__topic">{smp.topic}</span>
              </button>
            ))}
          </div>
          <div className={`textbox ${showError ? "has-error" : ""} ${analysis.status === "loading" ? "is-reading" : ""}`}>
            <label htmlFor="ws-text" className="visually-hidden">
              النص العربي المراد تحليله
            </label>
            <textarea
              id="ws-text"
              ref={textRef}
              className="textbox__area reading"
              dir="rtl"
              lang="ar"
              value={text}
              placeholder="اكتب نصًّا عربيًّا هنا أو ألصقه…"
              onChange={(e) => setText(e.target.value)}
              onBlur={() => text && setTouched(true)}
              aria-invalid={showError}
              aria-describedby="ws-text-meta ws-text-err"
              readOnly={busy}
              rows={6}
            />
            <div className="textbox__meta" id="ws-text-meta">
              {/* Character counter (Submit Arabic Text AC7, backlog story 8). It only reports the length: there is no maximum. */}
              <span className="counter">{fmtNum(validation.length)} حرف</span>
              {stale && <span className="stale-tag">عُدّل النص بعد التحليل</span>}
            </div>
          </div>
          <p id="ws-text-err" className="field__error" role={showError ? "alert" : undefined}>
            {showError ? validation.message : ""}
          </p>
          <div className="panel__actions">
            <button type="button" className="btn btn--primary" onClick={runAnalysis} disabled={busy} aria-busy={analysis.status === "loading"}>
              {analysis.status === "loading" ? <Spinner /> : null}
              {analysis.status === "loading" ? "يجري التحليل…" : stale ? "أعد تحليل المقروئية" : "حلّل المقروئية"}
            </button>
            <button type="button" className="btn btn--ghost" onClick={clearAll} disabled={!text && analysis.status === "idle"}>
              مسح
            </button>
          </div>
        </section>

        {/* ── Step 2: analysis result ─────────────────── */}
        <div aria-live="polite" className="ws-live">
          {analysis.status === "loading" && (
            <section className="panel panel--loading">
              <ReadingLoader label="يقرأ فصيح نصّك ويقدّر مستوى مقروئيته…" />
            </section>
          )}
          {analysis.status === "error" && (
            <section className="panel">
              <Notice tone="error" title="لم يكتمل التحليل">
                {analysis.error.message}
              </Notice>
              <div className="panel__actions">
                <button type="button" className="btn btn--soft" onClick={runAnalysis}>
                  أعد المحاولة
                </button>
              </div>
            </section>
          )}
        </div>
        {analyzed && (
          <section className={`panel panel--result enter ${stale ? "is-stale" : ""}`} aria-labelledby="res-h" tabIndex={-1} ref={resultRef}>
            <h2 id="res-h" className="visually-hidden">
              نتيجة التحليل
            </h2>
            <AnalysisView result={analyzed} />
            {stale && (
              <Notice tone="warn">عدّلتَ النص بعد تحليله، فالنتيجة أعلاه تخصّ النسخة السابقة. أعد التحليل لتحديثها.</Notice>
            )}
            {!stale && !simplified && (
              <div className="panel__actions panel__actions--end">
                <SaveButton
                  id={analyzed.id}
                  saved={analyzed.saved}
                  onSaved={() => setAnalysis({ status: "success", data: { ...analyzed, saved: true } })}
                />
              </div>
            )}
          </section>
        )}

        {/* ── Step 3: target level ────────────────────── */}
        {analyzed && !stale && (
          <section className="panel panel--target enter" aria-labelledby="tg-h">
            <div className="panel__head">
              <div>
                <h2 id="tg-h" className="panel__title">
                  اختر المستوى المستهدف
                </h2>
                <p className="panel__sub">اختر المستوى الذي تريد أن يُكتب به النص. هذا المستوى هو هدف التبسيط، ولن يُعرض نص لا يطابقه.</p>
              </div>
            </div>
            <LevelPicker
              value={target}
              onChange={setTarget}
              currentLevel={analyzed.originalLevel}
              maxLevel={(analyzed.originalLevel - 1) as Level}
              disabled={simple.status === "loading"}
            />
            {analyzed.originalLevel === 1 ? (
              <Notice tone="info" title="نصّك في أسهل مستوى">
                صُنّف النص في المستوى ١، وهو أسهل مستويات فصيح، فلا يوجد مستوى أسهل يُبسَّط إليه.
              </Notice>
            ) : (
              <p className="fine-print target-note">
                المستويات المتاحة أسهل من مستوى نصّك ({LEVEL_INFO[analyzed.originalLevel].numeral})، لأن التبسيط ينقل النص إلى مستوى أسهل فقط.
              </p>
            )}
            {!simplifierOn && (
              <Notice tone="info" title="التبسيط غير متاح بعد">
                نموذج التبسيط ما زال قيد التطوير ولم يُربط بالمنصّة، لذلك لن نعرض نصًّا مولّدًا وهميًّا. يمكنك حفظ نتيجة التحليل الآن.
              </Notice>
            )}
            <div className="panel__actions">
              <button
                type="button"
                className="btn btn--primary"
                onClick={runSimplify}
                disabled={!target || !simplifierOn || simple.status === "loading" || analyzed.originalLevel === 1}
                aria-busy={simple.status === "loading"}
                aria-describedby={!target ? "tg-hint" : undefined}
              >
                {simple.status === "loading" ? <Spinner /> : null}
                {simple.status === "loading" ? "يجري التبسيط…" : target ? `بسّط إلى المستوى ${LEVEL_INFO[target].numeral}` : "بسّط النص"}
              </button>
              {!target && (
                <span id="tg-hint" className="fine-print">
                  اختر مستوى أولًا.
                </span>
              )}
            </div>
          </section>
        )}

        {/* ── Step 4: comparison ──────────────────────── */}
        <div aria-live="polite" className="ws-live">
          {simple.status === "loading" && (
            <section className="panel panel--loading">
              <SimplifyProgress level={target} />
            </section>
          )}
          {simple.status === "error" && simple.error.code === "level_not_met" && target && (
            <LevelNotMet
              level={target}
              onRetry={runSimplify}
              onChooseAnother={() => {
                setSimple({ status: "idle" });
                setTarget(null);
                document.getElementById("tg-h")?.scrollIntoView({ behavior: "smooth", block: "center" });
              }}
            />
          )}
          {simple.status === "error" && simple.error.code !== "level_not_met" && (
            <section className="panel">
              <Notice tone="error" title="لم يكتمل التبسيط">
                {simple.error.message}
              </Notice>
              {simple.error.code !== "simplifier_unavailable" && (
                <div className="panel__actions">
                  <button type="button" className="btn btn--soft" onClick={runSimplify}>
                    أعد المحاولة
                  </button>
                </div>
              )}
            </section>
          )}
        </div>
        {simplified && (
          <div ref={compareRef} className="enter">
            <ComparisonView
              animateIn
              result={simplified}
              onSaved={() => setSimple({ status: "success", data: { ...simplified, saved: true } })}
              onRated={(r) => setSimple({ status: "success", data: { ...simplified, rating: r } })}
            />
          </div>
        )}

        {!user && analyzed && (
          <p className="fine-print guest-note">أنت تستخدم فصيح كزائر: النتائج لا تُحفظ ولا تُحتسب في الإحصاءات.</p>
        )}
      </div>

      <Dialog
        open={guide}
        onClose={() => setGuide(false)}
        title="المستويات الأربعة في فصيح"
        actions={
          <button type="button" className="btn btn--primary" onClick={() => setGuide(false)}>
            فهمت
          </button>
        }
      >
        <p className="dialog__lede">المستوى ١ هو الأسهل و٤ هو الأصعب.</p>
        <LevelGuide compact />
      </Dialog>
    </div>
  );
}
