import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import type { UsageStats } from "../../shared/api";
import { LEVEL_INFO, LEVELS, type Level } from "../../shared/levels";
import { EmptyState, Notice } from "../components/ui";
import { ApiRequestError, api } from "../lib/api";
import { useAssistantTopic } from "../lib/assistant";
import { fmtDate, fmtNum } from "../lib/format";

function Distribution({ title, data, note }: { title: string; data: Record<Level, number>; note: string }) {
  const total = LEVELS.reduce((a, l) => a + data[l], 0);
  const max = Math.max(1, ...LEVELS.map((l) => data[l]));
  return (
    <section className="stat-card" aria-labelledby={`d-${title}`}>
      <h2 id={`d-${title}`} className="stat-card__title">
        {title}
      </h2>
      <p className="stat-card__note">{note}</p>
      {total === 0 ? (
        <p className="fine-print">لا بيانات بعد.</p>
      ) : (
        <table className="dist">
          <caption className="visually-hidden">{title}</caption>
          <tbody>
            {LEVELS.map((l) => (
              <tr key={l} data-level={l}>
                <th scope="row">
                  {LEVEL_INFO[l].numeral} · {LEVEL_INFO[l].name}
                </th>
                <td className="dist__bar-cell">
                  <span className="dist__bar" style={{ ["--w" as string]: data[l] / max }} />
                </td>
                <td className="dist__n">{fmtNum(data[l])}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </section>
  );
}

function Weekly({ weeks }: { weeks: UsageStats["weekly"] }) {
  const max = Math.max(1, ...weeks.map((w) => w.analyses + w.simplifications));
  const H = 140;
  const bw = 26;
  const gap = 22;
  const W = weeks.length * (bw + gap);
  return (
    <section className="stat-card stat-card--wide" aria-labelledby="wk-h">
      <h2 id="wk-h" className="stat-card__title">
        نشاطك في آخر ثمانية أسابيع
      </h2>
      <div className="legend" aria-hidden="true">
        <span className="legend__item legend__item--a">تحليل</span>
        <span className="legend__item legend__item--s">تبسيط</span>
      </div>
      <svg viewBox={`0 0 ${W} ${H + 34}`} className="weekly" role="img" aria-labelledby="wk-h wk-desc">
        <desc id="wk-desc">
          {weeks.map((w) => `أسبوع ${fmtDate(w.weekStart)}: ${fmtNum(w.analyses)} تحليل و${fmtNum(w.simplifications)} تبسيط`).join("؛ ")}
        </desc>
        <line x1="0" x2={W} y1={H} y2={H} className="weekly__base" />
        {weeks.map((w, i) => {
          // RTL: newest week on the left end of the reading direction → place oldest at right
          const x = W - (i + 1) * (bw + gap) + gap / 2;
          const ha = (w.analyses / max) * (H - 8);
          const hs = (w.simplifications / max) * (H - 8);
          const d = new Date(w.weekStart);
          return (
            <g key={w.weekStart} className="weekly__col" style={{ ["--i" as string]: i }}>
              <rect x={x} y={H - ha} width={bw} height={Math.max(0, ha)} rx="6" className="weekly__a" />
              <rect x={x} y={H - ha - hs} width={bw} height={Math.max(0, hs)} rx="6" className="weekly__s" />
              {w.analyses + w.simplifications > 0 && (
                <text x={x + bw / 2} y={H - ha - hs - 6} className="weekly__val">
                  {fmtNum(w.analyses + w.simplifications)}
                </text>
              )}
              <text x={x + bw / 2} y={H + 22} className="weekly__lbl">
                {fmtNum(d.getUTCDate())}/{fmtNum(d.getUTCMonth() + 1)}
              </text>
            </g>
          );
        })}
      </svg>
    </section>
  );
}

export function Stats() {
  const [state, setState] = useState<{ status: "loading" } | { status: "error"; message: string } | { status: "ok"; s: UsageStats }>({ status: "loading" });
  const empty = state.status === "ok" && state.s.analyses + state.s.simplifications === 0;
  useAssistantTopic(empty ? "stats-empty" : "stats");

  useEffect(() => {
    api
      .stats()
      .then((s) => setState({ status: "ok", s }))
      .catch((e) => setState({ status: "error", message: e instanceof ApiRequestError ? e.message : "تعذّر تحميل الإحصاءات." }));
  }, []);

  return (
    <div className="container page">
      <header className="page-head">
        <h1 className="page-title">إحصاءاتي</h1>
        <p className="page-lede">أرقام حقيقية من استخدامك أنت فقط. تُحتسب العمليات الناجحة وحدها، ولا تنقص بحذف السجلات.</p>
      </header>
      {state.status === "loading" && <div className="stats-grid" aria-busy="true">{[0, 1, 2].map((i) => <div key={i} className="kpi skeleton" />)}</div>}
      {state.status === "error" && <Notice tone="error" title="تعذّر التحميل">{state.message}</Notice>}
      {empty && (
        <EmptyState
          title="لا عمليات بعد"
          body="ستظهر هنا أرقامك بعد أول تحليل ناجح وأنت مسجّل الدخول."
          motif="ya"
          action={<Link to="/workspace" className="btn btn--primary">ابدأ أول تحليل</Link>}
        />
      )}
      {state.status === "ok" && !empty && (
        <>
          <dl className="stats-grid">
            <div className="kpi kpi--accent">
              <dt>تحليلات ناجحة</dt>
              <dd>{fmtNum(state.s.analyses)}</dd>
            </div>
            <div className="kpi">
              <dt>عمليات تبسيط ناجحة</dt>
              <dd>{fmtNum(state.s.simplifications)}</dd>
            </div>
            <div className="kpi">
              <dt>سجلات محفوظة حاليًا</dt>
              <dd>{fmtNum(state.s.savedRecords)}</dd>
            </div>
          </dl>
          <div className="stats-cols">
            <Weekly weeks={state.s.weekly} />
            <Distribution title="مستويات النصوص التي حلّلتها" note="المستوى الذي قدّره المصنِّف لكل تحليل ناجح." data={state.s.analysedLevels} />
            <Distribution title="المستويات التي اخترتها للتبسيط" note="المستوى المستهدف في كل عملية تبسيط ناجحة." data={state.s.targetLevels} />
          </div>
          <p className="fine-print">عضو منذ {fmtDate(state.s.memberSince)}</p>
        </>
      )}
    </div>
  );
}
