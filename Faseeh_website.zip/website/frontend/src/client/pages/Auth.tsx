import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import { Link, Navigate, useLocation, useNavigate, useSearchParams } from "react-router-dom";
import { validateConfirm, validateEmail, validatePassword } from "../../shared/validation";
import { LogoOutline } from "../brand/Logo";
import { Mascot } from "../brand/Mascot";
import { Field, Notice, PasswordInput, PasswordRules, Spinner } from "../components/ui";
import { ApiRequestError, api } from "../lib/api";
import { useAssistantTopic } from "../lib/assistant";
import { useSession } from "../lib/session";
import { useToast } from "../lib/toast";

/**
 * Shared layout of the four account-access pages: decorative logo panel on one
 * side, the form card on the other. Also tells the help panel to show account tips.
 */
function AuthShell({ title, lede, children, foot }: { title: string; lede: string; children: ReactNode; foot?: ReactNode }) {
  useAssistantTopic("auth");
  return (
    <div className="auth">
      <aside className="auth__art" aria-hidden="true">
        <LogoOutline className="auth__art-word" draw drawMs={3400} strokeWidth={1.6} />
        <div className="auth__art-say">
          <Mascot size={72} mood="happy" />
          <p>نصوص أوضح، لقرّاء أكثر.</p>
        </div>
      </aside>
      <div className="auth__panel">
        <div className="auth__card">
          <h1 className="auth__title">{title}</h1>
          <p className="auth__lede">{lede}</p>
          {children}
        </div>
        {foot && <div className="auth__foot">{foot}</div>}
      </div>
    </div>
  );
}

type Errors = Record<string, string | undefined>;

/**
 * Form state shared by the account pages.
 * `run(fn)` executes one request: it shows the busy state, and turns an
 * ApiRequestError into field errors (shown under each field) or a form-level
 * message, so every page reports server errors the same way.
 */
function useForm() {
  const [errors, setErrors] = useState<Errors>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const run = async (fn: () => Promise<void>) => {
    setBusy(true);
    setFormError(null);
    try {
      await fn();
    } catch (e) {
      if (e instanceof ApiRequestError) {
        setErrors(e.fields);
        // field-specific problems are shown under their fields; anything else as a form-level message
        if (!Object.keys(e.fields).length) setFormError(e.message);
      } else setFormError("حدث خطأ غير متوقع. حاول مرة أخرى.");
    } finally {
      setBusy(false);
    }
  };
  return { errors, setErrors, formError, busy, run };
}

/** Focus the first invalid field after a failed submit. */
function focusFirstError(form: HTMLFormElement) {
  requestAnimationFrame(() => (form.querySelector('[aria-invalid="true"]') as HTMLElement | null)?.focus());
}

type NavNotice = { notice?: string } | null;

/**
 * Sign in — Log In (backlog story 2, Jira FSEEH-7); C2b sign-in flow.
 * Valid credentials → "Firebase starts the session" → "Redirect to home page".
 */
export function Login() {
  const { user, setUser } = useSession();
  const navigate = useNavigate();
  const location = useLocation();
  const notice = (location.state as NavNotice)?.notice;
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const { errors, setErrors, formError, busy, run } = useForm();
  const toast = useToast();
  if (user) return <Navigate to="/" replace />;

  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    // Log In AC2: missing credentials prevent submission
    const errs = {
      email: email.trim() ? undefined : "يرجى إدخال البريد الإلكتروني.",
      password: password ? undefined : "يرجى إدخال كلمة المرور.",
    };
    setErrors(errs);
    if (errs.email || errs.password) return focusFirstError(form);
    void run(async () => {
      const r = await api.login(email, password);
      setUser(r.user);
      toast("تم تسجيل الدخول.", "success");
      navigate("/", { replace: true });
    });
  };

  return (
    <AuthShell
      title="تسجيل الدخول"
      lede="ادخل إلى حسابك في فصيح."
      foot={
        <>
          ليس لديك حساب؟ <Link to="/register">أنشئ حسابًا</Link>
        </>
      }
    >
      <form noValidate onSubmit={submit} className="form">
        {notice && <Notice tone="success">{notice}</Notice>}
        {formError && <Notice tone="error">{formError}</Notice>}
        <Field label="البريد الإلكتروني" error={errors.email}>
          {(p) => <input {...p} className="input" type="email" dir="ltr" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} />}
        </Field>
        <Field label="كلمة المرور" error={errors.password}>
          {(p) => <PasswordInput {...p} autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} />}
        </Field>
        <div className="form__row">
          <Link to="/forgot-password" className="link-quiet">
            نسيت كلمة المرور؟
          </Link>
        </div>
        <button type="submit" className="btn btn--primary btn--block" disabled={busy} aria-busy={busy}>
          {busy ? <Spinner /> : null}
          دخول
        </button>
      </form>
    </AuthShell>
  );
}

/**
 * Sign up — Create an Account (backlog story 1, Jira FSEEH-6); C2b sign-up flow.
 * Valid data → Firebase creates the account → profile in Cloud Firestore →
 * Firebase starts the session → "Redirect to home page" with a confirmation (AC6).
 */
export function Register() {
  const { user, setUser } = useSession();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const { errors, setErrors, formError, busy, run } = useForm();
  const toast = useToast();
  if (user) return <Navigate to="/" replace />;

  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const errs = {
      email: validateEmail(email) ?? undefined,
      password: validatePassword(password) ?? undefined,
      confirm: validateConfirm(password, confirm) ?? undefined,
    };
    // AC2–AC4 in the browser first (the server repeats every check).
    setErrors(errs);
    if (errs.email || errs.password || errs.confirm) return focusFirstError(form);
    void run(async () => {
      // On success the backend has created the Firebase account and the
      // Firestore profile, and has set the HttpOnly session cookie.
      const r = await api.register(email, password, confirm);
      setUser(r.user);
      toast("أُنشئ حسابك بنجاح. مرحبًا بك في فصيح!", "success");
      navigate("/", { replace: true });
    });
  };

  return (
    <AuthShell
      title="إنشاء حساب"
      lede="أنشئ حسابك في فصيح بالبريد الإلكتروني وكلمة مرور."
      foot={
        <>
          لديك حساب؟ <Link to="/login">سجّل الدخول</Link>
        </>
      }
    >
      <form noValidate onSubmit={submit} className="form">
        {formError && <Notice tone="error">{formError}</Notice>}
        <Field label="البريد الإلكتروني" error={errors.email}>
          {(p) => <input {...p} className="input" type="email" dir="ltr" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} />}
        </Field>
        <Field label="كلمة المرور" error={errors.password} hint={<PasswordRules value={password} />}>
          {(p) => <PasswordInput {...p} autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} />}
        </Field>
        <Field label="تأكيد كلمة المرور" error={errors.confirm}>
          {(p) => <PasswordInput {...p} autoComplete="new-password" value={confirm} onChange={(e) => setConfirm(e.target.value)} />}
        </Field>
        <button type="submit" className="btn btn--primary btn--block" disabled={busy} aria-busy={busy}>
          {busy ? <Spinner /> : null}
          أنشئ الحساب
        </button>
      </form>
    </AuthShell>
  );
}

/**
 * Forgot password — Recover a Forgotten Password AC1–AC4 (backlog story 3, Jira FSEEH-26); C2b "Forgot Password (from the sign-in page)".
 * Registered e-mail → Firebase sends the reset link and a confirmation is shown;
 * unregistered e-mail → "no account is associated with this email" (as documented).
 */
export function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [sentTo, setSentTo] = useState<string | null>(null);
  const { errors, setErrors, formError, busy, run } = useForm();

  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const err = validateEmail(email);
    setErrors({ email: err ?? undefined });
    if (err) return focusFirstError(e.currentTarget);
    void run(async () => {
      // An unregistered email is answered with a field error (AC4) by the backend.
      await api.requestPasswordReset(email.trim());
      // Switches the card to the confirmation message (AC3).
      setSentTo(email.trim());
    });
  };

  return (
    <AuthShell
      title="استعادة كلمة المرور"
      lede="أدخل بريدك المسجّل وسنرسل إليك رابطًا لتعيين كلمة مرور جديدة."
      foot={<Link to="/login">العودة إلى تسجيل الدخول</Link>}
    >
      {sentTo ? (
        <div className="form">
          <Notice tone="success" title="أُرسل رابط الاستعادة">
            أرسلنا رابط إعادة تعيين كلمة المرور إلى <bdi dir="ltr">{sentTo}</bdi>. افتح الرابط من بريدك لاختيار كلمة مرور جديدة.
          </Notice>
          <button type="button" className="btn btn--ghost btn--block" onClick={() => setSentTo(null)}>
            إرسال إلى بريد آخر
          </button>
        </div>
      ) : (
        <form noValidate onSubmit={submit} className="form">
          {formError && <Notice tone="error">{formError}</Notice>}
          <Field label="البريد الإلكتروني" error={errors.email}>
            {(p) => <input {...p} className="input" type="email" dir="ltr" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} />}
          </Field>
          <button type="submit" className="btn btn--primary btn--block" disabled={busy} aria-busy={busy}>
            {busy ? <Spinner /> : null}
            أرسل رابط الاستعادة
          </button>
        </form>
      )}
    </AuthShell>
  );
}

/**
 * Reset page reached from the e-mailed link — Recover a Forgotten Password AC5–AC8 (FSEEH-87, FSEEH-88); C2b "Is the link valid?
 * (not expired or used)" → "Enter and confirm new password" → "Password meets policy and
 * matches?" → "Firebase updates the password" → "Redirect to sign-in page".
 * Firebase appends `mode=resetPassword&oobCode=…` to the configured action URL.
 */
export function ResetPassword() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  // The one-time code Firebase put in the emailed link.
  const oobCode = params.get("oobCode") ?? "";
  // checking → the code is being verified; invalid → unknown/expired/used (AC7); valid → show the form.
  const [link, setLink] = useState<{ state: "checking" } | { state: "invalid" } | { state: "valid"; email: string }>({ state: "checking" });
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const { errors, setErrors, formError, busy, run } = useForm();

  useEffect(() => {
    if (!oobCode) {
      setLink({ state: "invalid" });
      return;
    }
    api
      .verifyPasswordReset(oobCode)
      .then((r) => setLink({ state: "valid", email: r.email }))
      .catch(() => setLink({ state: "invalid" }));
  }, [oobCode]);

  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const errs = { password: validatePassword(password) ?? undefined, confirm: validateConfirm(password, confirm) ?? undefined };
    setErrors(errs);
    if (errs.password || errs.confirm) return focusFirstError(e.currentTarget);
    void run(async () => {
      try {
        await api.confirmPasswordReset(oobCode, password, confirm);
      } catch (err) {
        // The link expired or was used while the page was open: show the invalid-link page.
        if (err instanceof ApiRequestError && err.code === "invalid_reset_link") {
          setLink({ state: "invalid" });
          return;
        }
        throw err;
      }
      navigate("/login", { replace: true, state: { notice: "تم تغيير كلمة المرور. سجّل الدخول بكلمة المرور الجديدة." } });
    });
  };

  if (link.state === "checking")
    return (
      <AuthShell title="تعيين كلمة مرور جديدة" lede="نتحقق من رابط الاستعادة…">
        <div className="form" aria-busy="true">
          <Spinner label="جارٍ التحقق من الرابط" />
        </div>
      </AuthShell>
    );

  if (link.state === "invalid")
    return (
      <AuthShell title="رابط غير صالح" lede="لا يمكن استخدام هذا الرابط لتغيير كلمة المرور." foot={<Link to="/login">العودة إلى تسجيل الدخول</Link>}>
        <div className="form">
          <Notice tone="warn">رابط الاستعادة غير صالح أو انتهت صلاحيته أو سبق استخدامه. اطلب رابطًا جديدًا.</Notice>
          <Link to="/forgot-password" className="btn btn--primary btn--block">
            اطلب رابطًا جديدًا
          </Link>
        </div>
      </AuthShell>
    );

  return (
    <AuthShell title="تعيين كلمة مرور جديدة" lede="اختر كلمة مرور قوية لحسابك." foot={<Link to="/login">العودة إلى تسجيل الدخول</Link>}>
      <form noValidate onSubmit={submit} className="form">
        <p className="fine-print">
          الحساب: <bdi dir="ltr">{link.email}</bdi>
        </p>
        {formError && <Notice tone="error">{formError}</Notice>}
        <Field label="كلمة المرور الجديدة" error={errors.password} hint={<PasswordRules value={password} />}>
          {(p) => <PasswordInput {...p} autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} />}
        </Field>
        <Field label="تأكيد كلمة المرور" error={errors.confirm}>
          {(p) => <PasswordInput {...p} autoComplete="new-password" value={confirm} onChange={(e) => setConfirm(e.target.value)} />}
        </Field>
        <button type="submit" className="btn btn--primary btn--block" disabled={busy} aria-busy={busy}>
          {busy ? <Spinner /> : null}
          احفظ كلمة المرور
        </button>
      </form>
    </AuthShell>
  );
}
