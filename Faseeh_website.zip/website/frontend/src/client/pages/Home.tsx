import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { LogoOutline, LogoWriting } from "../brand/Logo";
import { Mascot } from "../brand/Mascot";
import { LevelGuide } from "../components/Levels";
import { useAssistantTopic } from "../lib/assistant";
import { useReveal } from "../lib/motion";
import { useSession } from "../lib/session";

// Reset by every full page load, so the handwriting plays on each refresh but not
// again when navigating back to the home page within the site.
let heroPlayedThisLoad = false;

function HeroLogo() {
  // Clicking the logo replays it.
  const [run, setRun] = useState(0);
  const [play] = useState(() => !heroPlayedThisLoad);
  useEffect(() => {
    heroPlayedThisLoad = true;
  }, []);
  return (
    <button type="button" className="hero__logo-btn" onClick={() => setRun((r) => r + 1)} aria-label="أعد كتابة شعار فصيح">
      <LogoWriting key={run} className="hero__logo" play={play || run > 0} />
    </button>
  );
}

function Preview() {
  return (
    <figure className="preview" aria-label="مثال توضيحي لواجهة فصيح">
      <div className="preview__card preview__card--orig">
        <div className="preview__bar">
          <span className="preview__chip" data-level="4">
            المستوى ٤ · متقدّم
          </span>
        </div>
        <p className="preview__text">تتجلّى الإشكالية المعرفية في تضافر المقاربات المتباينة واستقراء السياقات المتشابكة.</p>
      </div>
      <svg className="preview__link" viewBox="0 0 170 110" aria-hidden="true">
        <path d="M150 6 C 168 52, 120 66, 84 60 S 22 70, 14 100 M6 88 L14 101 L26 92" pathLength={1} />
      </svg>
      <div className="preview__card preview__card--simple">
        <div className="preview__bar">
          <span className="preview__chip" data-level="2">
            المستوى ٢ · ميسَّر
          </span>
        </div>
        <p className="preview__text">تظهر المشكلة حين تجتمع آراء مختلفة، ونحتاج إلى فهم الظروف المحيطة بها.</p>
      </div>
      <figcaption className="preview__caption">مثال توضيحي لشكل المقارنة، وليس ناتجًا حيًّا من النموذج.</figcaption>
    </figure>
  );
}

function Reveal({ as: Tag = "div", className = "", children, ...rest }: { as?: "div" | "section" | "li"; className?: string; children: React.ReactNode } & Record<string, unknown>) {
  const ref = useReveal<HTMLDivElement>();
  return (
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    <Tag ref={ref as any} className={`reveal ${className}`} {...rest}>
      {children}
    </Tag>
  );
}

const STEPS = [
  { title: "ألصق النص", body: "جملة أو فقرة عربية تجد صعوبة في قراءتها." },
  { title: "اعرف مستواه", body: "يمنح المصنِّف النص مستوى مقروئية واحدًا من ١ إلى ٤." },
  { title: "اختر المستوى", body: "أنت من يحدّد المستوى المستهدف بحسب القارئ، لا النظام." },
  { title: "قارن واحفظ", body: "النص الأصلي والنص المبسّط للمستوى الذي اخترته، جنبًا إلى جنب." },
];

const AUDIENCE = [
  { who: "الطلاب", why: "لفهم نصوص المناهج والمقالات قبل التعمّق فيها." },
  { who: "المعلّمون", why: "لاختيار نصوص تناسب مستوى الصف وتهيئتها لطلابهم." },
  { who: "متعلّمو العربية", why: "لقراءة نصوص حقيقية بلغة أقرب إلى مستواهم." },
  { who: "ذوو صعوبات القراءة", why: "لنسخة أوضح من النص بجمل أقصر ومفردات مألوفة." },
];

export function Home() {
  useAssistantTopic("home");
  // `user` and `loading` come from the shared session (lib/session.tsx), so the
  // final call-to-action follows login, logout and session expiry automatically.
  const { config, user, loading } = useSession();
  const simplifierOn = config?.simplifierAvailable ?? false;

  return (
    <div className="home">
      {/* ── Hero ─────────────────────────────────────────── */}
      <section className="hero" aria-labelledby="hero-title">
        <div className="hero__bg" aria-hidden="true">
          <LogoOutline className="hero__bg-word" draw drawMs={7000} delayMs={600} strokeWidth={1.1} />
          <LogoOutline part="fa" className="hero__bg-fa" draw drawMs={5200} delayMs={1600} strokeWidth={1} />
        </div>
        <div className="container hero__grid">
          <div className="hero__copy">
            <HeroLogo />
            <h1 id="hero-title" className="hero__title">
              كلّ نصٍّ عربيّ يستحقّ أن يُفهَم
            </h1>
            <p className="hero__lede">
              يقيس فصيح مقروئية النص العربي على أربعة مستويات، ثم يبسّطه إلى المستوى الذي تختاره أنت، مع الحرص على بقاء المعنى كما هو.
            </p>
            <div className="hero__ctas">
              <Link to="/workspace" className="btn btn--primary btn--lg">
                ابدأ في مساحة العمل
                <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" className="btn__arrow"><path d="M14 6l-6 6 6 6" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" /></svg>
              </Link>
              <Link to={{ pathname: "/", hash: "#how" }} className="btn btn--ghost btn--lg">
                كيف يعمل فصيح؟
              </Link>
            </div>
          </div>
          <div className="hero__visual">
            <Preview />
            <div className="hero__mascot" aria-hidden="true">
              <Mascot size={64} mood="happy" />
              <span className="hero__mascot-say">أنا نقطة، سأرافقك!</span>
            </div>
          </div>
        </div>
      </section>

      {/* ── Two capabilities ─────────────────────────────── */}
      <section className="capabilities container" aria-labelledby="cap-title">
        <h2 id="cap-title" className="visually-hidden">
          ما يقدّمه فصيح
        </h2>
        <Reveal className="cap cap--measure">
          <LogoOutline part="sad" className="cap__motif" strokeWidth={1.3} />
          <p className="cap__kicker">قياس المقروئية</p>
          <h3 className="cap__title">اعرف صعوبة النص قبل أن تقرأه</h3>
          <p className="cap__body">
            نموذج تصنيف درّبه فريق فصيح على نصوص عربية مصنّفة بحسب صعوبتها، يمنح النص مستوى مقروئية واحدًا من أربعة مستويات.
          </p>
        </Reveal>
        <Reveal className="cap cap--simplify">
          <LogoOutline part="ya" className="cap__motif" strokeWidth={1.3} />
          <p className="cap__kicker">التبسيط الموجَّه</p>
          <h3 className="cap__title">نسخة أوضح، بالمستوى الذي تحدّده</h3>
          <p className="cap__body">
            تختار المستوى الذي تريده من بين المستويات الأسهل، فيعيد نموذج التبسيط صياغة النص لهذا المستوى تحديدًا مع الحفاظ على معناه.
          </p>
          {!simplifierOn && <p className="cap__status">نموذج التبسيط قيد التطوير، وسيُفعَّل في المنصّة عند جاهزيته.</p>}
        </Reveal>
      </section>

      <div className="knot-divider" aria-hidden="true">
        <LogoOutline part="knot" className="knot-divider__svg" draw drawMs={2200} strokeWidth={1.6} />
      </div>

      {/* ── How it works ─────────────────────────────────── */}
      <section id="how" className="how container" aria-labelledby="how-title">
        <Reveal className="section-head">
          <h2 id="how-title" className="display-title">
            من نصٍّ صعب إلى نصٍّ واضح
          </h2>
          <p className="section-lede">أربع خطوات متتابعة، وأنت من يقرّر في كل خطوة.</p>
        </Reveal>
        <ol className="how__steps">
          <svg className="how__thread" viewBox="0 0 1000 60" preserveAspectRatio="none" aria-hidden="true">
            <path d="M995 30 C 870 -6, 760 66, 630 30 S 380 -6, 255 30 S 60 60, 5 30" pathLength={1} />
          </svg>
          {STEPS.map((s, i) => (
            <Reveal as="li" key={s.title} className="how__step" style={{ ["--d" as string]: `${i * 90}ms` }}>
              {/* Direction markers instead of numbers, so steps aren't confused with levels 1–4:
                  an arrow pointing to the next step (RTL: leftward), and a check on the last one. */}
              <span className="how__num how__num--mark" aria-hidden="true">
                {i < STEPS.length - 1 ? (
                  <svg viewBox="0 0 24 24" width="26" height="26">
                    <path d="M19 12H5M11 6l-6 6 6 6" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                ) : (
                  <svg viewBox="0 0 24 24" width="26" height="26">
                    <path d="M5 12.5l4.2 4L19 7" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                )}
              </span>
              <h3 className="how__title">{s.title}</h3>
              <p className="how__body">{s.body}</p>
            </Reveal>
          ))}
        </ol>
      </section>

      {/* ── Levels ───────────────────────────────────────── */}
      <section id="levels" className="levels" aria-labelledby="levels-title">
        <LogoOutline part="ha" className="levels__motif" strokeWidth={1.2} />
        <div className="container">
          <Reveal className="section-head">
            <h2 id="levels-title" className="display-title">
              أربعة مستويات، من الأسهل إلى الأصعب
            </h2>
            <p className="section-lede">
              يعتمد فصيح سلّمًا مرتّبًا من أربعة مستويات، من الأسهل (١) إلى الأصعب (٤). لكل مستوى وصف قصير يساعدك على فهم نتيجة التحليل واختيار المستوى المستهدف.
            </p>
          </Reveal>
          <Reveal>
            <LevelGuide />
          </Reveal>
        </div>
      </section>

      {/* ── Audience ─────────────────────────────────────── */}
      <section className="audience container" aria-labelledby="aud-title">
        <Reveal className="audience__intro">
          <h2 id="aud-title" className="display-title">
            لمن صُمّم فصيح؟
          </h2>
          <p className="section-lede">لكل من يقرأ العربية ويريد أن يفهمها بلا عناء — لا يحتاج إلى أي معرفة بالذكاء الاصطناعي.</p>
        </Reveal>
        <ul className="audience__list">
          {AUDIENCE.map((a, i) => (
            <Reveal as="li" key={a.who} className="audience__item" style={{ ["--d" as string]: `${i * 80}ms` }}>
              <h3>{a.who}</h3>
              <p>{a.why}</p>
            </Reveal>
          ))}
        </ul>
      </section>

      {/* ── The level promise ──────────────────────────── */}
      <section className="honesty container" aria-labelledby="hon-title">
        <Reveal className="honesty__card">
          <div>
            <h2 id="hon-title" className="honesty__title">
              المستوى الذي تختاره هو ما تحصل عليه
            </h2>
            <p>
              يتحقق فصيح من أن النص المبسّط مكتوب بالمستوى الذي اخترته قبل أن يعرضه عليك. وإن لم يتمكن من بلوغه، يخبرك بذلك بوضوح ولا يعرض نصًّا بمستوى آخر.
            </p>
          </div>
          <dl className="honesty__stats">
            <div>
              <dt>مستويات مرتّبة</dt>
              <dd>٤</dd>
            </div>
            <div>
              <dt>مهمّتان: التصنيف والتبسيط</dt>
              <dd>٢</dd>
            </div>
            <div>
              <dt>جملة في بيانات التدريب</dt>
              <dd>٥٤٬٨٤٥</dd>
            </div>
          </dl>
        </Reveal>
      </section>

      {/* ── Final CTA ────────────────────────────────────── */}
      <section className="final-cta" aria-labelledby="final-title">
        <LogoOutline className="final-cta__word" draw drawMs={6000} strokeWidth={1.2} />
        <div className="container final-cta__inner">
          <h2 id="final-title" className="display-title">
            جرّب فصيح على نصّك الآن
          </h2>
          {/* Until the first session check answers, show neither version, so a signed-in
              user never briefly sees the guest message and buttons. */}
          {loading ? null : user ? (
            // Signed in: no account prompt; one button to the Workspace.
            <div className="hero__ctas">
              <Link to="/workspace" className="btn btn--primary btn--lg">
                ابدأ التجربة
              </Link>
            </div>
          ) : (
            // Guest: unchanged message and both buttons.
            <>
              <p className="section-lede">لا تحتاج إلى حساب لتحليل النص. أنشئ حسابًا حين تريد حفظ نتائجك ومتابعة إحصاءاتك.</p>
              <div className="hero__ctas">
                <Link to="/workspace" className="btn btn--primary btn--lg">
                  التجربة كزائر
                </Link>
                <Link to="/register" className="btn btn--ghost btn--lg">
                  إنشاء حساب
                </Link>
              </div>
            </>
          )}
        </div>
      </section>
    </div>
  );
}
