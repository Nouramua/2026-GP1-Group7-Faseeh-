/**
 * Faseeh's four ordered readability levels (1 = easiest, 4 = hardest).
 *
 * Derived from the BAREC corpus: the five-level BAREC grouping is adapted to four
 * levels by merging BAREC levels 4 and 5. In terms of BAREC's fine-grained
 * 19-level scale the resulting mapping (verified on the training data in
 * Data/BAREC_prepared_datasets.zip) is:
 *   Level 1 ← BAREC 1–7 · Level 2 ← BAREC 8–11 · Level 3 ← BAREC 12–13 · Level 4 ← BAREC 14–19
 * The four-level scheme is Faseeh's adaptation, not an official BAREC scheme.
 */
export type Level = 1 | 2 | 3 | 4;

export const LEVELS: readonly Level[] = [1, 2, 3, 4] as const;

export interface LevelInfo {
  level: Level;
  /** Arabic-Indic numeral for display */
  numeral: string;
  name: string;
  short: string;
  description: string;
  traits: string[];
  example: string;
}

export const LEVEL_INFO: Record<Level, LevelInfo> = {
  1: {
    level: 1,
    numeral: "١",
    name: "تأسيسي",
    short: "سهل جدًا",
    description: "نصّ قريب من القارئ المبتدئ: كلمات مألوفة وجمل قصيرة جدًا تُفهم من القراءة الأولى.",
    traits: ["جمل قصيرة جدًا", "مفردات يومية مألوفة", "فكرة واحدة واضحة"],
    example: "ذهب الولد إلى المدرسة.",
  },
  2: {
    level: 2,
    numeral: "٢",
    name: "ميسَّر",
    short: "سهل",
    description: "نصّ سلس بجمل قصيرة إلى متوسطة، مع كلمات أقل شيوعًا يسهل فهمها من السياق.",
    traits: ["جمل قصيرة إلى متوسطة", "مفردات شائعة مع قليل من الجديد", "روابط بسيطة"],
    example: "تعود التماسيح إلى موطنها حين تمتلئ الأنهار في موسم المطر.",
  },
  3: {
    level: 3,
    numeral: "٣",
    name: "متوسط",
    short: "متوسط",
    description: "نصّ أطول جملًا وأغنى مفردات، فيه تراكيب وروابط تحتاج إلى قراءة متأنية.",
    traits: ["جمل أطول وتراكيب متعددة", "مفردات فصيحة متنوعة", "أفكار مترابطة"],
    example: "يرى الباحثون أن تنظيم الوقت يرفع إنتاجية الطالب ويقلّل من توتره قبل الاختبارات.",
  },
  4: {
    level: 4,
    numeral: "٤",
    name: "متقدّم",
    short: "متقدّم",
    description: "نصّ أدبي أو متخصص بجمل طويلة متشعّبة ومفردات نادرة، يحتاج إلى قارئ متمرّس.",
    traits: ["جمل طويلة متشعّبة", "مفردات أدبية أو متخصصة", "معانٍ ضمنية ومجازية"],
    example: "تتجلّى الإشكالية المعرفية في تضافر المقاربات المتباينة واستقراء السياقات المتشابكة.",
  },
};

export function isLevel(value: unknown): value is Level {
  return value === 1 || value === 2 || value === 3 || value === 4;
}

export function toArabicDigits(n: number | string): string {
  return String(n).replace(/[0-9]/g, (d) => "٠١٢٣٤٥٦٧٨٩"[Number(d)]);
}
