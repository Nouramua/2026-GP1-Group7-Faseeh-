/** Validation rules shared by the browser and the server (the server always re-validates). */

export const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export function validateEmail(email: string): string | null {
  const v = email.trim();
  if (!v) return "يرجى إدخال البريد الإلكتروني.";
  if (v.length > 254 || !EMAIL_RE.test(v)) return "صيغة البريد الإلكتروني غير صحيحة، مثال: name@example.com";
  return null;
}

export interface PasswordCheck {
  key: "length" | "upper" | "lower" | "digit" | "special";
  label: string;
  ok: boolean;
}

/** Project report: at least 8 characters including upper-case, lower-case, a digit and a special character. */
export function passwordChecks(pw: string): PasswordCheck[] {
  return [
    { key: "length", label: "٨ أحرف على الأقل", ok: pw.length >= 8 },
    { key: "upper", label: "حرف إنجليزي كبير (A–Z)", ok: /[A-Z]/.test(pw) },
    { key: "lower", label: "حرف إنجليزي صغير (a–z)", ok: /[a-z]/.test(pw) },
    { key: "digit", label: "رقم واحد على الأقل", ok: /[0-9]/.test(pw) },
    { key: "special", label: "رمز خاص مثل ! @ # ؟", ok: /[^A-Za-z0-9\s]/.test(pw) },
  ];
}

export function validatePassword(pw: string): string | null {
  if (!pw) return "يرجى إدخال كلمة المرور.";
  if (pw.length > 128) return "كلمة المرور طويلة جدًا (الحد ١٢٨ حرفًا).";
  const missing = passwordChecks(pw).filter((c) => !c.ok);
  if (missing.length) return "كلمة المرور لا تستوفي الشروط: " + missing.map((m) => m.label).join("، ") + ".";
  return null;
}

export function validateConfirm(pw: string, confirm: string): string | null {
  if (!confirm) return "يرجى تأكيد كلمة المرور.";
  if (pw !== confirm) return "كلمتا المرور غير متطابقتين.";
  return null;
}

// Character class covering the Arabic letters of the Arabic, Arabic Supplement and
// Arabic Extended-A Unicode blocks (digits and punctuation are deliberately excluded).
const ARABIC_LETTER = /[ء-يٱ-ۓۺ-ۿݐ-ݿࢠ-ࣿ]/gu;
// Any letter in any script (Unicode property "L"), used as the denominator of the Arabic ratio.
const ANY_LETTER = /\p{L}/gu;

/**
 * Why a text was rejected. There is deliberately no length-based issue: the old
 * 3,000-character limit is no longer an approved requirement and was removed.
 */
export type TextIssue = "empty" | "not_arabic";

/** Result of validating the Workspace input. */
export interface TextValidation {
  /** true when the text may be sent for analysis or simplification */
  ok: boolean;
  /** which rule failed (absent when ok) */
  issue?: TextIssue;
  /** Arabic message shown under the text box (absent when ok) */
  message?: string;
  /** number of characters typed, counted by code point so emoji and rare letters count as one; feeds the character counter */
  length: number;
}

/** Arabic share of letters required for the text to be accepted. */
export const MIN_ARABIC_RATIO = 0.6;

/**
 * Validates text entered in the Workspace before any (demonstration) processing.
 *
 * Rules, in order:
 *  1. Empty or whitespace-only text is rejected.
 *  2. At least 60% of the letters must be Arabic letters (unsupported input is rejected).
 * The text is never truncated, and there is no maximum length.
 *
 * @param text the raw text exactly as the user typed or pasted it
 * @returns whether the text is acceptable, the failed rule and its message, and the character count
 */
export function validateArabicText(text: string): TextValidation {
  // Spread into code points so the counter matches what the user perceives as characters.
  const length = [...text].length;
  // Rule 1: nothing but whitespace → ask the user to type or paste text first.
  if (!text.trim()) return { ok: false, issue: "empty", message: "اكتب نصًّا عربيًّا أو ألصقه أولًا.", length };
  // Rule 2: count all letters and the Arabic ones; numbers and punctuation do not count either way.
  const letters = text.match(ANY_LETTER)?.length ?? 0;
  const arabic = text.match(ARABIC_LETTER)?.length ?? 0;
  if (letters === 0 || arabic / letters < MIN_ARABIC_RATIO)
    return {
      ok: false,
      issue: "not_arabic",
      message: "يدعم فصيح النصوص العربية فقط. تأكد أن معظم النص مكتوب بالعربية.",
      length,
    };
  return { ok: true, length };
}
