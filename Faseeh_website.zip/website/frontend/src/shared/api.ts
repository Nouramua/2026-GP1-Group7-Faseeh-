/** Typed contracts between the Faseeh web client and the Faseeh API server. */
import type { Level } from "./levels.js";

export type RequestType = "analysis" | "simplification";

/** The signed-in user as reported by the PHP backend (Firebase UID + e-mail). */
export interface PublicUser {
  uid: string;
  email: string;
}

/** View Profile (Use Case Diagram, Fig. 8): the account e-mail and when the account was created. */
export interface AccountProfile {
  email: string;
  createdAt: string | null;
}

/** Feature availability reported to the Workspace (no input length limit is reported: there is none). */
export interface AppConfig {
  classifierAvailable: boolean;
  simplifierAvailable: boolean;
  classifierModel: string | null;
  emailDelivery: "smtp" | "server-log";
}

export interface SentenceLevel {
  text: string;
  level: Level;
}

export interface AnalysisResult {
  /** Server id when the user is signed in (needed for saving); null for guests. */
  id: string | null;
  type: "analysis";
  originalText: string;
  originalLevel: Level;
  sentences: SentenceLevel[];
  createdAt: string;
  saved: boolean;
}

export interface SimplificationResult {
  id: string | null;
  type: "simplification";
  originalText: string;
  originalLevel: Level;
  targetLevel: Level;
  simplifiedText: string;
  /**
   * Internal verification value (backend phase). The interface never displays it:
   * a simplification is only returned as a result once it meets `targetLevel`.
   */
  outputLevel: Level | null;
  createdAt: string;
  saved: boolean;
  rating: Rating | null;
}

export type AnyResult = AnalysisResult | SimplificationResult;

export const RATING_ISSUES = ["unclear", "incorrect", "meaning_changed", "level_mismatch"] as const;
export type RatingIssue = (typeof RATING_ISSUES)[number];

export const RATING_ISSUE_LABELS: Record<RatingIssue, string> = {
  unclear: "صياغة غير واضحة",
  incorrect: "تبسيط غير صحيح",
  meaning_changed: "تغيّر المعنى",
  level_mismatch: "لا يناسب المستوى المختار",
};

export interface Rating {
  stars: 1 | 2 | 3 | 4 | 5;
  issues: RatingIssue[];
  comment: string;
  updatedAt: string;
}

export interface HistoryItem {
  id: string;
  type: RequestType;
  preview: string;
  originalLevel: Level;
  targetLevel: Level | null;
  outputLevel: Level | null;
  createdAt: string;
  savedAt: string;
}

export interface UsageStats {
  analyses: number;
  simplifications: number;
  savedRecords: number;
  /** distribution of predicted levels of analysed texts */
  analysedLevels: Record<Level, number>;
  /** distribution of chosen target levels */
  targetLevels: Record<Level, number>;
  /** last 8 weeks, oldest first: ISO week start + counts */
  weekly: { weekStart: string; analyses: number; simplifications: number }[];
  memberSince: string;
}

export type ApiErrorCode =
  | "validation"
  | "unauthorized"
  | "forbidden"
  | "not_found"
  | "conflict"
  | "rate_limited"
  | "classifier_unavailable"
  | "simplifier_unavailable"
  /** the simplifier could not produce a text verified at the requested level */
  | "level_not_met"
  | "service_error"
  | "internal"
  /* Sprint 2 authentication (PHP backend) */
  | "email_in_use"
  | "invalid_credentials"
  | "too_many_attempts"
  | "email_not_registered"
  | "invalid_reset_link"
  | "session_expired"
  | "configuration"
  /* features scheduled for Release 2 */
  | "not_available";

export interface ApiError {
  error: ApiErrorCode;
  message: string;
  fields?: Record<string, string>;
}
