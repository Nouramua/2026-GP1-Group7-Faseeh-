import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Development: Vite serves the pages, and every /api request is forwarded to the
// PHP backend (php -S 127.0.0.1:8080 …), so the browser only ever sees one origin.
const backend = process.env.FASEEH_BACKEND_URL ?? "http://127.0.0.1:8080";

export default defineConfig({
  plugins: [react()],
  build: { outDir: "dist", emptyOutDir: true, sourcemap: false },
  server: {
    port: 5173,
    strictPort: true,
    proxy: { "/api": { target: backend, changeOrigin: false } },
  },
});
