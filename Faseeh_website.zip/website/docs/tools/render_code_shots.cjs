/**
 * Renders genuine code images for the implementation documents.
 *
 * Each image shows EXACT lines of a current source file with their real line
 * numbers (nothing is retyped or edited). A spec entry names the file, the line
 * where the excerpt starts (a regex), and where it ends: either a regex, or by
 * default the line where the braces opened on the start line close again.
 *
 *   PLAYWRIGHT_CORE=/path/to/playwright-core CHROME_PATH=/path/to/chrome \
 *   node docs/tools/render_code_shots.cjs docs/tools/shots-firebase.json docs/firebase-screenshots
 *
 * Also writes <out>/_index.json with the file and line range of every image,
 * which the documents cite in their captions.
 */
const { chromium } = require(process.env.PLAYWRIGHT_CORE || 'playwright-core');
const fs = require('fs'), path = require('path');

const REPO = path.resolve(__dirname, '..', '..');
const [specFile, outDir] = process.argv.slice(2);
const spec = JSON.parse(fs.readFileSync(specFile, 'utf8'));
fs.mkdirSync(outDir, { recursive: true });

const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

/** Very small display-only highlighter: comments, strings, PHP variables, keywords, calls. */
function highlight(line, lang) {
  const kw = lang === 'php'
    ? /^(public|private|protected|function|return|throw|new|try|catch|if|else|foreach|as|static|final|class|interface|readonly|null|true|false|string|int|bool|array|void|self|use|const|match|default)\b/
    : /^(const|let|var|async|await|return|if|else|new|function|export|import|from|type|interface|true|false|null|undefined|instanceof|try|catch|finally|throw|allow|read|write|service|rules_version)\b/;
  const out = []; let i = 0;
  while (i < line.length) {
    const rest = line.slice(i); let m;
    if (/^\s*(\/\/|\/\*|\*)/.test(line) && i === 0) { out.push(`<span class="c">${esc(line)}</span>`); break; }
    if (rest.startsWith('//') || rest.startsWith('/*') || (lang === 'php' && rest.startsWith('# '))) { out.push(`<span class="c">${esc(rest)}</span>`); break; }
    if ((m = rest.match(/^('(?:[^'\\]|\\.)*'|"(?:[^"\\]|\\.)*"|`(?:[^`\\]|\\.)*`)/))) { out.push(`<span class="s">${esc(m[0])}</span>`); i += m[0].length; continue; }
    if ((m = rest.match(/^\$[A-Za-z_]\w*/))) { out.push(`<span class="v">${esc(m[0])}</span>`); i += m[0].length; continue; }
    if ((m = rest.match(kw)) && !/[\w$]/.test(line[i - 1] || '')) { out.push(`<span class="k">${m[0]}</span>`); i += m[0].length; continue; }
    if ((m = rest.match(/^[A-Za-z_]\w*(?=\()/))) { out.push(`<span class="f">${esc(m[0])}</span>`); i += m[0].length; continue; }
    if ((m = rest.match(/^[\w$]+/))) { out.push(esc(m[0])); i += m[0].length; continue; }
    out.push(esc(line[i])); i++;
  }
  return out.join('');
}

/** Finds the line where the braces opened from the start line are balanced again. */
function braceEnd(lines, startIdx) {
  let depth = 0, opened = false;
  for (let i = startIdx; i < lines.length; i++) {
    // ignore braces inside strings, comments and simple regex literals
    const code = lines[i].replace(/(['"`])(?:\\.|(?!\1).)*\1/g, '""').replace(/\/\/.*$/, '').replace(/\/(?![*/])(?:\\.|[^/\n])+\/[gimsuy]*/g, '0');
    for (const ch of code) {
      if (ch === '{') { depth++; opened = true; }
      if (ch === '}') depth--;
    }
    if (opened && depth <= 0) return i;
  }
  throw new Error('unbalanced braces');
}

function page(title, sub, rows) {
  return `<!doctype html><html><head><meta charset="utf-8"><style>
  body{margin:0;background:#fff;font-family:Consolas,'Cascadia Mono',monospace}
  .win{width:900px;border:1px solid #d9cfc6;border-radius:10px;overflow:hidden}
  .bar{background:#f3ece4;color:#4a3a31;font:600 14px 'Segoe UI',sans-serif;padding:8px 14px;border-bottom:1px solid #e3d7cb;display:flex;gap:10px}
  .sub{color:#8a7668;font-weight:400}
  pre{margin:0;padding:10px 0;color:#2f2520;font-size:15px;line-height:1.5;background:#fffdfa;white-space:pre-wrap;word-break:break-word}
  .row{display:block;padding-left:62px;text-indent:-62px}
  .ln{display:inline-block;width:46px;padding-right:16px;text-align:right;color:#a7968a;text-indent:0}
  .c{color:#6f7f66;font-style:italic}.s{color:#a3521b}.k{color:#b03a1a;font-weight:600}.v{color:#2c5d8a}.f{color:#7a4d00}
  </style></head><body><div class="win"><div class="bar">${esc(title)}<span class="sub">${esc(sub)}</span></div><pre>${rows}</pre></div></body></html>`;
}

(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROME_PATH || undefined });
  const p = await browser.newPage({ viewport: { width: 902, height: 300 }, deviceScaleFactor: 2 });
  const index = {};
  for (const s of spec) {
    const src = fs.readFileSync(path.join(REPO, s.file), 'utf8').replace(/\r\n/g, '\n');
    const lines = src.split('\n');
    const re = new RegExp(s.start);
    const a = lines.findIndex((l, i) => i >= (s.after ? lines.findIndex((x) => new RegExp(s.after).test(x)) : 0) && re.test(l));
    if (a < 0) throw new Error(`${s.name}: start not found (${s.start})`);
    let b;
    if (s.end) {
      // optional `endAfter`: only look for the end after this marker (when the end pattern repeats)
      const from0 = s.endAfter ? lines.findIndex((l, i) => i >= a && new RegExp(s.endAfter).test(l)) : a;
      b = lines.findIndex((l, i) => i >= from0 && new RegExp(s.end).test(l));
      if (b < 0) throw new Error(`${s.name}: end not found`);
    } else b = braceEnd(lines, a);
    b += s.endPlus || 0; // optional extra lines after the end match (e.g. a closing brace)
    const from = a + 1 - (s.before || 0), to = b + 1;
    const lang = s.file.endsWith('.php') ? 'php' : 'ts';
    // Long excerpts are split into parts of at most 40 lines, so each image fits on one PDF page.
    const total = to - from + 1, parts = Math.ceil(total / 40), size = Math.ceil(total / parts);
    for (let k = 0; k < parts; k++) {
      const f = from + k * size, t = Math.min(to, f + size - 1);
      const name = parts > 1 ? `${s.name}-part${k + 1}` : s.name;
      const rows = lines.slice(f - 1, t).map((l, j) => `<span class="row"><span class="ln">${f + j}</span>${highlight(l, lang) || ' '}</span>`).join('');
      await p.setContent(page(s.file, `  lines ${f}–${t}${parts > 1 ? ` (part ${k + 1} of ${parts})` : ''}`, rows));
      await (await p.$('.win')).screenshot({ path: path.join(outDir, `${name}.png`) });
      index[name] = { file: s.file, from: f, to: t };
      console.log(`${name.padEnd(46)} ${s.file}:${f}-${t}`);
    }
  }
  fs.writeFileSync(path.join(outDir, '_index.json'), JSON.stringify(index, null, 1));
  await browser.close();
})().catch((e) => { console.error(e.message); process.exit(1); });
