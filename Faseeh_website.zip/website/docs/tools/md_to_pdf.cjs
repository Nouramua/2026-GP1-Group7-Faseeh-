/**
 * Builds a PDF from a Markdown document, so the Markdown and the PDF always
 * contain the same text, images and headings.
 *
 *   PLAYWRIGHT_CORE=... CHROME_PATH=... node docs/tools/md_to_pdf.cjs docs/Firebase_Implementation.md
 *   → docs/Firebase_Implementation.pdf (A4, page numbers in the footer)
 *
 * Supports the Markdown used in these documents: headings, paragraphs, bold,
 * italics, inline code, links, images, bullet and numbered lists, tables,
 * block quotes, fenced code blocks and horizontal rules.
 */
const { chromium } = require(process.env.PLAYWRIGHT_CORE || 'playwright-core');
const fs = require('fs'), path = require('path');
const { pathToFileURL } = require('url');

const mdFile = path.resolve(process.argv[2]);
const pdfFile = mdFile.replace(/\.md$/, '.pdf');
const md = fs.readFileSync(mdFile, 'utf8').replace(/\r\n/g, '\n');

const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
function inline(s) {
  const codes = [];
  s = s.replace(/`([^`]+)`/g, (_, c) => { codes.push(c); return `\u0000${codes.length - 1}\u0000`; });
  s = esc(s)
    .replace(/!\[([^\]]*)\]\(([^)]+)\)/g, '<img src="$2" alt="$1">')
    .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2">$1</a>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/(^|[^*\w])\*([^*\s][^*]*?)\*(?!\*)/g, '$1<em>$2</em>');
  return s.replace(/\u0000(\d+)\u0000/g, (_, i) => `<code>${esc(codes[i])}</code>`);
}

function render(src) {
  const lines = src.split('\n'); const out = []; let i = 0;
  const isTableSep = (l) => /^\|?\s*:?-{3,}/.test(l);
  while (i < lines.length) {
    const l = lines[i];
    if (/^```/.test(l)) { const buf = []; i++; while (i < lines.length && !/^```/.test(lines[i])) buf.push(lines[i++]); i++; out.push(`<pre><code>${esc(buf.join('\n'))}</code></pre>`); continue; }
    if (/^#{1,6} /.test(l)) { const n = l.match(/^#+/)[0].length; out.push(`<h${n}>${inline(l.slice(n + 1))}</h${n}>`); i++; continue; }
    if (/^---+\s*$/.test(l)) { out.push('<hr>'); i++; continue; }
    if (/^\|/.test(l) && i + 1 < lines.length && isTableSep(lines[i + 1])) {
      const cells = (r) => r.replace(/^\||\|\s*$/g, '').split(/(?<!\\)\|/).map((c) => inline(c.trim().replace(/\\\|/g, '|')));
      const head = cells(l); i += 2; const rows = [];
      while (i < lines.length && /^\|/.test(lines[i])) rows.push(cells(lines[i++]));
      out.push(`<table><thead><tr>${head.map((c) => `<th>${c}</th>`).join('')}</tr></thead><tbody>${rows.map((r) => `<tr>${r.map((c) => `<td>${c}</td>`).join('')}</tr>`).join('')}</tbody></table>`);
      continue;
    }
    if (/^> ?/.test(l)) { const buf = []; while (i < lines.length && /^> ?/.test(lines[i])) buf.push(lines[i++].replace(/^> ?/, '')); out.push(`<blockquote>${render(buf.join('\n'))}</blockquote>`); continue; }
    if (/^\s*([-*]|\d+\.) /.test(l)) {
      const ordered = /^\s*\d+\./.test(l); const items = [];
      while (i < lines.length && (/^\s*([-*]|\d+\.) /.test(lines[i]) || (/^\s{2,}\S/.test(lines[i]) && items.length))) {
        if (/^\s*([-*]|\d+\.) /.test(lines[i]) && !/^\s{3,}/.test(lines[i])) items.push([lines[i].replace(/^\s*([-*]|\d+\.) /, '')]);
        else items[items.length - 1].push(lines[i].trim().replace(/^([-*]|\d+\.) /, '• '));
        i++;
      }
      out.push(`<${ordered ? 'ol' : 'ul'}>${items.map((it) => `<li>${it.map(inline).join('<br>')}</li>`).join('')}</${ordered ? 'ol' : 'ul'}>`);
      continue;
    }
    if (/^\s*$/.test(l)) { i++; continue; }
    const buf = []; while (i < lines.length && !/^\s*$/.test(lines[i]) && !/^(#{1,6} |```|\||> ?|\s*([-*]|\d+\.) |---+\s*$)/.test(lines[i])) buf.push(lines[i++]);
    const html = inline(buf.join(' '));
    // A paragraph that is only an image becomes a figure; a following *caption* paragraph is attached by CSS order.
    out.push(/^<img [^>]+>$/.test(html) ? `<figure>${html}</figure>` : `<p>${html}</p>`);
  }
  return out.join('\n');
}

const title = (md.match(/^# (.+)$/m) || [, path.basename(mdFile)])[1];
const html = `<!doctype html><html><head><meta charset="utf-8"><base href="${pathToFileURL(path.dirname(mdFile) + path.sep).href}"><title>${esc(title)}</title><style>
  @page { size: A4; margin: 18mm 16mm 20mm 16mm; }
  body { font-family: "Segoe UI", "Readex Pro", Tahoma, sans-serif; font-size: 10.5pt; line-height: 1.5; color: #2b211c; }
  h1 { font-size: 21pt; color: #a44f22; margin: 0 0 8pt; }
  h2 { font-size: 15pt; color: #a44f22; border-bottom: 1.5pt solid #ead9ca; padding-bottom: 3pt; margin: 18pt 0 8pt; break-after: avoid; }
  h3 { font-size: 12.5pt; color: #4a3a31; margin: 14pt 0 6pt; break-after: avoid; }
  h4 { font-size: 11pt; color: #4a3a31; margin: 10pt 0 4pt; break-after: avoid; }
  p { margin: 5pt 0; }
  code { font-family: Consolas, monospace; font-size: 9.2pt; background: #f6efe8; padding: 0 3pt; border-radius: 3pt; }
  pre { background: #fbf6f1; border: 1pt solid #eadfd4; padding: 7pt; border-radius: 5pt; white-space: pre-wrap; font-size: 9pt; break-inside: avoid; }
  pre code { background: none; padding: 0; }
  table { border-collapse: collapse; width: 100%; margin: 6pt 0; font-size: 9.2pt; break-inside: auto; }
  tr { break-inside: avoid; }
  th, td { border: 0.8pt solid #e0d2c4; padding: 3.5pt 5pt; vertical-align: top; text-align: left; }
  th { background: #f6ece2; }
  figure { margin: 8pt 0 2pt; text-align: center; break-inside: avoid; }
  figure img { max-width: 100%; max-height: 225mm; border: 0.6pt solid #e5d8cb; }
  figure + p em:only-child, figure + p > em:first-child { color: #6d5a4d; }
  figure + p { font-size: 9.2pt; color: #6d5a4d; text-align: center; margin-top: 2pt; break-before: avoid; }
  blockquote { margin: 6pt 0; padding: 4pt 10pt; border-left: 3pt solid #e7a571; background: #fdf6ef; }
  ul, ol { margin: 4pt 0 4pt 16pt; padding: 0; }
  li { margin: 1.5pt 0; }
  hr { border: none; border-top: 1pt solid #eadfd4; margin: 12pt 0; }
  a { color: #a44f22; text-decoration: none; }
  [dir=rtl], :lang(ar) { font-family: "Readex Pro", Tahoma, sans-serif; }
</style></head><body>${render(md)}</body></html>`;

(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROME_PATH || undefined, args: ['--allow-file-access-from-files'] });
  const p = await browser.newPage();
  const tmp = mdFile.replace(/\.md$/, '.print.html');
  fs.writeFileSync(tmp, html);
  await p.goto(pathToFileURL(tmp).href, { waitUntil: 'load' });
  await p.evaluate(() => Promise.all([...document.images].map((im) => (im.complete ? 0 : new Promise((r) => { im.onload = im.onerror = r; })))));
  const broken = await p.evaluate(() => [...document.images].filter((im) => !im.naturalWidth).map((im) => im.getAttribute('src')));
  if (broken.length) throw new Error('missing images: ' + broken.join(', '));
  await p.pdf({
    path: pdfFile, format: 'A4', printBackground: true, displayHeaderFooter: true,
    headerTemplate: `<div style="font-size:7.5pt;color:#9a8677;width:100%;padding:0 16mm;font-family:Segoe UI,sans-serif">${esc(title)}</div>`,
    footerTemplate: '<div style="font-size:8pt;color:#9a8677;width:100%;text-align:center;font-family:Segoe UI,sans-serif">Page <span class="pageNumber"></span> of <span class="totalPages"></span></div>',
    margin: { top: '18mm', bottom: '20mm', left: '16mm', right: '16mm' },
  });
  if (!process.env.KEEP_HTML) fs.unlinkSync(tmp); // KEEP_HTML=1 keeps the print HTML for inspection
  await browser.close();
  console.log('written', pdfFile, `(${(await import('fs')).statSync(pdfFile).size} bytes, ${document_count(html)} images)`);
})().catch((e) => { console.error(e.message); process.exit(1); });

function document_count(h) { return (h.match(/<img /g) || []).length; }
