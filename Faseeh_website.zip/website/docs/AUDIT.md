# Documentation audit — Release 1, Sprint 2

Source: *Faseeh — Text Simplification Document* (60-page PDF provided on 7 Nov 2026). Page numbers below are the **printed** page numbers in the report (PDF page = printed + 11).

## 1. Sprint 2 scope

| Source | What it says |
|---|---|
| Figure 2 *Product Roadmap*, p. 6 | Sprint 2 "System Design & Architecture" (Dec 2026, Release 1): design the overall system architecture; design the user interface; develop the web platform based on the system design; **implement user authentication (sign up, sign in and log out)**. "Release 1 delivered". |
| §4.1 *Methodology*, p. 17 | "Sprint 2 focuses on system architecture, user interface design and development, and user authentication." Release 2 covers the simplification model, its integration with the classifier, connecting both models to the web application, testing and deployment. |
| Table 11 *Key components and releases*, p. 45 | **C2 Authentication (C2a states, C2b registration, login and password recovery) → Release 1.** C1 and C3 are also listed as Release 1 designs, but their runtime use depends on the models, which Figure 2 places in Sprint 4. |

**Implemented in this delivery:** sign up, sign in, log out, password recovery (C2b), session handling and expiry (C2a), protected pages, and the PHP backend foundation (Figure 9).

**Deliberately not implemented (Release 2):** PBI 4–15 and 29 (text submission to models, analysis, simplification, saving, history, deletion, statistics, ratings, model connection) and NFR 1 and NFR 3. In the interface, analysis and simplification stay as labelled demonstrations. Saving, history, ratings and statistics are marked "available in Release 2".

## 2. Functional requirements in scope (Table 7)

| PBI | Page | Acceptance criteria |
|---|---|---|
| 1 Create an Account | 25 | AC1 email, password and password-confirmation fields · AC2 incomplete fields show validation and create no account · AC3 invalid email or mismatched passwords prevent registration and identify the error · AC4 at least 8 characters with uppercase, lowercase, a digit and a special character, with a clear validation message · AC5 no duplicate account for an email · AC6 valid registration creates one account, displays confirmation and redirects to the home page · AC7 a failure shows a failure message without reporting creation |
| 2 Log In | 26 | AC1 email and password fields and a password-recovery option · AC2 missing credentials show validation · AC3 valid credentials establish a session and open the user's home page · AC4 general error that does not reveal whether the email exists · AC5 a failed attempt grants no access · AC6 a protected page without a valid session directs to login |
| 3 Log Out | 26 | AC1 clearly labelled logout control · AC2 logout invalidates the current session and returns to a public page · AC3 saved results and account information are preserved · AC4 the user's personal records are not shown to the next visitor |
| 30 Edit Profile *(added)* | BACKLOG_UPDATES.md | AC1 profile page with email and creation date, protected · AC2 validation · AC3 current password required · AC4 email of another account refused · AC5 email updated in Firebase Authentication and Firestore, sign-in uses the new email · AC6 failure changes nothing |
| 31 Delete Account *(added)* | BACKLOG_UPDATES.md | AC1 clearly labelled option · AC2 confirmation and current password · AC3 cancel or wrong password changes nothing · AC4 removes the account, profile, and (Release 2) records · AC5 session ends, public page, no access, email reusable · AC6 failure removes nothing · AC7 other accounts unaffected |
| 16 Recover a Forgotten Password | 34 | AC1 recovery option on the login page that accepts an email · AC2 empty or badly formatted email shows validation · AC3 registered email: reset link sent and confirmation shown · AC4 unregistered email: message that no account is associated, and no email is sent · AC5 new password must meet the policy · AC6 mismatched or invalid passwords prevent the reset · AC7 expired, invalid or used links cannot change the password · AC8 after reset the new password works, the old one does not, and the link cannot be reused |

## 3. Non-functional requirements (Table 8, pp. 39–40)

| NFR | Applies to Sprint 2? | Notes |
|---|---|---|
| 1 Performance | No | Measures analysis (≤ 10 s) and simplification (≤ 30 s), which are Release 2 work. |
| 2 Security | **Yes** | AC1: all 10 tests of unauthorised access to protected records are rejected, including after logout and access to another user's records. AC2: the account database contains zero plaintext passwords. |
| 3 Usability | No | Measured on the analysis and simplification tasks. |
| 4 Compatibility | **Partly** | AC1 (analysis and simplification tests in Chrome, Safari and Edge) is Release 2. AC2 (no clipped or overlapping controls at 1366×768 and 1024×768) also applies to the account pages. §1.2.2 Scope (pp. 3–4): laptops and tablets, not phones; Chrome, Safari and Edge. |

## 4. Architecture — Figure 9, p. 41

- **Presentation layer:** the "Account pages: Sign Up / Sign In / Log Out" connect to the PHP backend, not to Firebase directly.
- **Application layer:** "All requests from the presentation layer pass through the PHP backend, which handles each request, verifies the user's Firebase session and routes the request to the appropriate service." Firebase Authentication "registers users, verifies their credentials and manages their sessions."
- **Data layer:** "Firebase stores user accounts, history and ratings". The diagram's data store is "Firebase (Cloud Firestore): Users, history, ratings".
- **AI model service and offline training:** not touched.

**How the implementation follows it:**
- The browser talks only to `/api/*` on the PHP backend.
- PHP calls Firebase Authentication through the official Admin SDK for PHP, using a server-held service account, and writes to Cloud Firestore.
- The session is a Firebase **session cookie**: Firebase issues it, PHP verifies it on each request, and it's stored HttpOnly.
- No Firebase SDK or Firebase settings are shipped to the browser.

## 5. Data flow diagrams

- **Level 0, Figure 10, p. 42:** User → "registration / login details" → Faseeh System → "authentication result".
- **Level 1, Figure 11 p. 43 and Tables 9–10 p. 44:** Process **1.0 Manage User Authentication** "receives registration and login details, stores new accounts in D1 and verifies credentials against the stored user record". D1 Users holds "user accounts and credentials".
- **Mapping in the code:**
  - Process 1.0 = `AuthController` (PHP).
  - The account and credentials in D1 live in **Firebase Authentication**, the only place passwords exist (NFR 2 AC2).
  - The user profile in D1 lives in **Cloud Firestore**, keyed by the Firebase UID.
  - Processes 2.0–8.0 and stores D2 and D3 are Release 2.

## 6. Authentication diagrams

**C2a, Figure 13, p. 46:**

| Transition | Implemented as |
|---|---|
| Guest → Signing Up → [valid data] "Firebase creates account and starts session" → Authenticated | `POST /api/auth/register` |
| [invalid data or email in use] → error and retry | 400 or 409 with field messages |
| Guest → Signing In → [valid credentials] "Firebase starts session" → Authenticated | `POST /api/auth/login` |
| [invalid credentials] → error and retry | 401 with one general message |
| "Log out or session expires / Firebase ends session" → Guest | `POST /api/auth/logout`; an expired or revoked cookie is detected by `GET /api/auth/session` and every protected check. The interface then returns to Guest and says the session ended. |

**C2b, Figure 14, p. 47:**

- **Sign Up:** input valid? → email already registered? (Firebase check) → Firebase creates the account → **create user profile in Cloud Firestore** → Firebase starts the session → redirect to home page.
- **Sign In:** credentials valid? (Firebase check) → No: «البريد الإلكتروني أو كلمة المرور غير صحيحة» ("invalid email or password"); Yes: Firebase starts the session → redirect to home page.
- **Forgot Password (from the sign-in page):**
  1. Email format valid?
  2. Email registered? (Firebase check). If not: «لا يوجد حساب مرتبط بهذا البريد الإلكتروني» ("no account is associated with this email"). If so: Firebase sends the reset link and a confirmation is shown.
  3. The user opens the link. Is it valid (not expired or used)? If not: the invalid-link message.
  4. Enter and confirm the new password; it must meet the policy and match.
  5. Firebase updates the password → redirect to the sign-in page.

All steps are implemented in this order (see TESTING.md).

## 7. Firebase Authentication vs Cloud Firestore

| # | Question | Answer |
|---|---|---|
| 1 | What Firebase Authentication stores | Email, password (hashed by Firebase), UID and account metadata. It also issues and verifies sessions. |
| 2 | What Cloud Firestore stores | The user profile. The document says only "create user profile in Cloud Firestore" (C2b) and "Firestore: Users, history, ratings" (Fig. 9). **Fields and collection name are not documented** → DECISIONS.md D1. Implemented minimum: `{email, createdAt}`. |
| 3 | How they're linked | The Firestore document ID is the Firebase Authentication **UID**. |
| 4 | How PHP verifies requests | `verifySessionCookie(cookie, checkIfRevoked: true)` through the Admin SDK on every protected request (Fig. 9: "verifies the user's Firebase session"). |
| 5 | Preventing access to other users' data | The UID comes only from the verified session, never from the request. Firestore security rules (`firestore.rules`) deny all direct browser access; only the backend's service account writes. The record endpoints that use this guard are Release 2. |
| 6 | Expiry and logout | The session cookie expires after `SESSION_TTL_SECONDS` (value not documented → D2). Logout revokes the user's Firebase sessions and deletes the cookie (D3). A password reset also ends earlier sessions. |
| 7 | Collections and fields that are documented | None, beyond "Users, history, ratings" (Fig. 9) and D1 "User accounts and credentials" (Table 10). |
| 8 | What needs a team decision | The profile collection and fields (D1), session length (D2), logout scope (D3), and Firestore location (Firebase setup). |

## 8. Contradictions and gaps found in the document

1. **Recovery reveals whether an email is registered.** PBI 16 AC4 and C2b both say so, while PBI 2 AC4 forbids revealing it at login. Implemented as documented, because the two sources agree. Firebase's own "email enumeration protection" hides this information, so the check uses the Admin SDK. → D4
2. **Profile fields and collection** are not documented. → D1
3. **Session duration** is not documented, although C2a mentions expiry. → D2
4. **"End access on the current device" (PBI 3 story) vs "invalidates the current session" (PBI 3 AC2).** A Firebase session can only be invalidated by revoking all of the user's sessions. → D3
5. **"Home page" after sign-in or registration.** PBI 2 AC3 says "the user's home page"; C2b says "home page". Implemented as the site's home page `/`, with the account shown in the header. → D5
6. Table 8's text says "seven non-functional requirements", but **only four are listed** (pp. 39–40).
7. §4.4.2 *Technologies and System Configuration* refers to a table of technologies and versions, but **the PDF ends at p. 49**, before it. The PHP version and hosting aren't documented. → D6
8. **Use case diagram, Figure 8 p. 24:** shows *View Profile, Edit Profile, Delete Account* with no backlog stories or acceptance criteria. **Resolved (11 Nov 2026):** new backlog items 30 Edit Profile (includes viewing the profile) and 31 Delete Account in docs/BACKLOG_UPDATES.md, implemented as the «حسابي» page. *Delete History* still has no story → D11
9. **"download results"** appears in the usage report flows (Fig. 9 and 10) with no acceptance criteria. Release 2.
10. **Output level.** PBI 10 AC3, PBI 12 AC3, Table 10 D2 and Process 5.0 store or display the "output level". This conflicts with your earlier instruction not to show a different output level. **Resolved (11 Nov 2026):** corrected wording for PBI 6 AC3, 8 (new AC7), 10 AC3 and 12 AC3 in docs/BACKLOG_UPDATES.md §B. Classifying the simplified text is a check against the selected target, not a displayed level. The website shows no output level. Related non-backlog text is listed there for optional clarification.
11. PBI 4 AC5's "agreed limit" for input length and PBI 15's "agreed rating scale" are not given. Release 2.
