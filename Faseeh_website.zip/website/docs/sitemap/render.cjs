// Renders docs/sitemap/sitemap_release1.html to PNG and PDF.
//   PLAYWRIGHT_CORE=/path/to/playwright-core CHROME_PATH=/path/to/chrome node docs/sitemap/render.cjs
// The HTML loads the Readex Pro font from frontend/node_modules, so run `npm install` in frontend/ first.
const { chromium } = require(process.env.PLAYWRIGHT_CORE || 'playwright-core');
const { pathToFileURL } = require('url');
const path = require('path');
const dir = __dirname;
(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME_PATH || undefined, args: ['--allow-file-access-from-files'] });
  const p = await b.newPage({ viewport: { width: 1600, height: 920 }, deviceScaleFactor: 2 });
  await p.goto(pathToFileURL(path.join(dir, 'sitemap_release1.html')).href);
  await p.evaluate(() => document.fonts.ready);
  await p.screenshot({ path: path.join(dir, 'sitemap_release1.png'), clip: { x: 0, y: 0, width: 1600, height: 920 } });
  await p.pdf({ path: path.join(dir, 'sitemap_release1.pdf'), width: '1600px', height: '920px', printBackground: true, pageRanges: '1' });
  await b.close();
  console.log('rendered');
})();
