# Release 1 Final Verification

**Date:** 22 November 2026.

**Environment:** Windows 11, Chrome, PHP 8.x, Node 26.

**What the automated tests ran against:**
- the real PHP backend and the real frontend;
- Firebase replaced by the **in-memory test double**.

**Real Firebase results** come from the Release 1 demo recording on 15–16 November 2026, which used a temporary dummy account that was deleted afterwards.

**No production data was used.** No real account was created, changed or deleted during this audit.

## 1. Checks run

| Check | Command | Result |
|---|---|---|
| Typecheck + production build | `cd frontend && npm run build` | **Pass** |
| PHP syntax | `php -l` on all `backend/src` and `public` files | **Pass** |
| Backend unit tests | `cd backend && php vendor/bin/phpunit --testsuite unit` | **40 tests, 135 assertions, OK** |
| Browser end-to-end | `node backend/tests/Browser/release1.e2e.cjs` (see its README) | **105/105 passed** |
| Level descriptions | Browser probe (5 checks) | **5/5 passed** |
| Layout at 1366×768 and 1024×768 | Horizontal-overflow check on 6 public pages | **0 px overflow everywhere** |
| Dependencies | `npm audit`, `composer audit` | npm: 4 dev-tool / router advisories (major upgrades needed; see `Code_Cleanup_Report.md` §3 item 11). Composer: none. |
| Accessibility (automated scanner) | — | **Not run.** No axe or Lighthouse tool is installed. The keyboard behaviour of the help system was tested directly. |

## 2. Required verifications

| # | Requirement | Result | Evidence |
|---|---|---|---|
| 1 | Existing Release 1 pages still work | ✅ | E: all public pages load for a guest; protected pages behind login |
| 2 | No unintended UI layout or design change | ✅ | The only visible change is the Workspace counter, now "N حرف" without the limit bar. The help panel keeps its look (no focus ring on the container). No overflow at either size. |
| 3 | Registration works | ✅ test double, ✅ real Firebase (demo) | E: Registration group; R |
| 4 | Login works | ✅ test double, ✅ real Firebase (demo) | E: Login group; R |
| 5 | Password recovery works | ✅ test double, ✅ real Firebase with an Admin-SDK reset code | E: recovery group; R. **Inbox delivery not confirmed.** |
| 6 | Profile editing works | ✅ test double, ✅ real Firebase (final demo, 22 Nov) | E: Edit Profile group (including failure rollback). Real Firebase: the email changed, then **login with the new email succeeded**. The rollback path was tested only with the test double. |
| 7 | Account deletion works | ✅ test double, ✅ real Firebase (final demo, 22 Nov) | E: Delete Account group (including failure rollback). Real Firebase: password dialog, deletion, guest state and protected-page redirect; an Admin SDK lookup confirmed the account is gone. The Firestore profile was not inspected separately (see `Firebase_Implementation.md` §9). |
| 8 | Logout works | ✅ test double, ✅ real Firebase (demo) | E: cookie removed; old cookie replay → 401 |
| 9 | Expired sessions return the user to Guest | ✅ test double (clock advanced past the TTL) | E: backend `expired: true`, header → guest, protected page → login without a loop, private data 401, **expiry while My Account is open (fixed)**. **Not yet run with a real short TTL.** |
| 10 | Protected routes require authentication | ✅ | E: `/profile`, `/history` after logout, after expiry and after deletion → `/login`; backend 401 |
| 11 | Help button and panel support the keyboard | ✅ (after fix) | E: focusable, visible focus, Enter opens, focus enters the panel, Tab → close → FAQ, Space and Enter toggle the FAQ, Esc closes and returns focus, text preserved |
| 12 | The 3,000-character limit is completely removed | ✅ | No remaining references (grep); a 4,080-character text is accepted, counted and not truncated |
| 13 | The character counter and Clear still work | ✅ | E: counter shows the full length and returns to 0; Clear empties the text and the result |
| 14 | Release 2 rating is not implemented early | ✅ | No rating form rendered; `api.rate` rejects with "Release 2"; no storage or API added |
| 15 | No security or accessibility function removed | ✅ | Validation, guards, cookie flags, rules and rollbacks are untouched (U and E pass). Accessibility was improved (help focus). |

## 3. Release 1 stories

| Backlog | Jira | Story | Verified |
|---|---|---|---|
| 1 | FSEEH-6 | Create an Account | ✅ (U, E, R) |
| 2 | FSEEH-7 | Log In | ✅ (U, E, R) |
| 3 | FSEEH-26 | Recover a Forgotten Password | ✅ (U, E, R); inbox delivery pending |
| 4 | FSEEH-12 | Log Out (incl. session expiry) | ✅ (U, E); one defect fixed |
| 5 | FSEEH-49 | Edit Profile | ✅ (U, E, R on 22 Nov) |
| 6 | FSEEH-50 | Delete Account | ✅ (U, E, R on 22 Nov); Release 2 data handling not applicable yet |
| 7 | FSEEH-51 | Learn About Faseeh | ✅ (E) |
| 10 | FSEEH-16 | Understand Readability Levels | ✅ (L) |
| 11 | FSEEH-52 | Get Contextual Help | ✅ (E); two defects fixed |
| 23, 24, 26–29 | FSEEH-43 – 48 | Sprint 0–1 research | Outside the website; the mapping is documented in code; notebooks are not in this workspace |

## 4. Remaining issues

**Real Firebase checks still to run.** Do these once, with a test account, following `docs/TESTING.md` §3:
- item 8: a reset email reaches an inbox;
- item 12: session expiry with `SESSION_TTL_SECONDS=300`.

Items 14 (Edit Profile) and 15 (Delete Account) were done on 22 Nov in the final demo recording (§6).

**Other items:**
1. **Safari and Edge** compatibility runs (Compatibility NFR, story 41) are scheduled for Release 2, Sprint 5.
2. **Document updates (yours to change):**
   - backlog story 8 AC5 (3,000-character limit);
   - story 38 AC2 ("maximum permitted input length");
   - report §4.3 C3 text ("within the allowed length");
   - report Figure 13 → replace with `docs/sitemap/sitemap_release1.png` if you approve.
3. **`History.tsx` / `Stats.tsx`** are unreachable Release 2 prototypes. Decide whether to keep them for Sprint 4.
4. **npm advisories** need major upgrades of Vite and react-router; plan them for Release 2.
5. **Ponytail plugin:** not installed. `/plugin` isn't available in the VS Code panel (second-pass check). Its audit procedure was applied by hand (`Code_Cleanup_Report.md` §1 and §1a).
6. **Site wording to review:** three sentences describe the Release 2 level check and model as if they were already live. They are listed in `Release1_Code_Implementation.md` §18 and were not changed.

## 5. Exact list of changed files

### Modified: behaviour

**Frontend:**
- `frontend/src/shared/validation.ts`
- `frontend/src/shared/api.ts`
- `frontend/src/client/pages/Workspace.tsx`
- `frontend/src/client/pages/Home.tsx`
- `frontend/src/client/pages/Profile.tsx`
- `frontend/src/client/lib/assistant.tsx`
- `frontend/src/client/components/Assistant.tsx`
- `frontend/src/client/services/demo/demoService.ts`
- `frontend/src/client/styles/pages.css`
- `frontend/src/client/styles/components.css`

**Backend:**
- `backend/src/Firebase/FirestoreRestProfileStore.php`
- `backend/src/Firebase/KreaitAuthGateway.php`

### Modified: comments only

**Frontend:**
- `frontend/src/client/App.tsx`
- `frontend/src/client/lib/api.ts`
- `frontend/src/client/lib/session.tsx`
- `frontend/src/client/services/http.ts`
- `frontend/src/client/services/types.ts`
- `frontend/src/client/pages/Auth.tsx`
- `frontend/src/client/components/Results.tsx`

**Backend:**
- `backend/src/App.php`
- `backend/src/Config.php`
- `backend/src/Controllers/AuthController.php`
- `backend/src/Controllers/AccountController.php`
- `backend/src/Firebase/AuthGateway.php`
- `backend/src/Firebase/ProfileStore.php`
- `backend/src/Firebase/Exceptions.php`
- `backend/src/Http/Request.php`
- `backend/src/Http/Response.php`
- `backend/src/Http/ApiException.php`
- `backend/src/Session/SessionCookie.php`
- `backend/src/Validation/AuthValidator.php`

### Added

**Tests:**
- `backend/tests/Browser/release1.e2e.cjs`
- `backend/tests/Browser/test-double-control.php`
- `backend/tests/Browser/README.md`

**Documentation:**
- `docs/Release1_Implementation_Audit.md`
- `docs/Code_Cleanup_Report.md`
- `docs/Firebase_Implementation.md`
- `docs/Release1_Final_Verification.md`
- `docs/firebase-screenshots/fb-*.png` (43 images; replaced in the second pass)

**Site map:**
- `docs/sitemap/sitemap_release1.html` (editable source)
- `docs/sitemap/sitemap_release1.png`
- `docs/sitemap/sitemap_release1.pdf`
- `docs/sitemap/render.cjs`

### Not changed

- **Firebase:** configuration, the `.env` file, `firestore.rules`, and any Firebase project data.
- **Project management:** Jira, the Product Backlog, the report and Overleaf.
- **Models:** the AI models and the training code.
- **Existing project docs:** `docs/AUDIT.md`, `DECISIONS.md`, `BACKLOG_UPDATES.md`, `FIREBASE_SETUP.md`, `TESTING.md`.
- **GitHub:** not accessed.

## 6. Second pass (22 November 2026, evening)

### What was done
1. **Ponytail:** verified **not installed**. `/plugin` isn't available in the VS Code panel; no plugin files exist. The manual review of the earlier cleanup found no regressions (`Code_Cleanup_Report.md` §1a). **No website code was changed in this pass.**
2. **Firebase documentation expanded:**
   - `docs/Firebase_Implementation.md` and `.pdf` (35 pages, numbered);
   - 43 code images in `docs/firebase-screenshots/`, rendered from the exact current lines, each with a caption and an explanation.
3. **New code documentation:**
   - `docs/Release1_Code_Implementation.md` and `.pdf` (37 pages, numbered);
   - 35 code images and 13 real-website frames in `docs/release1-screenshots/`.
4. **Final demo video:** `docs/demo/Faseeh_Release1_Final_Demo.mp4`, recorded on the real website with the **real Firebase project** and disposable `@example.com` accounts.

### Real Firebase data touched in this pass
- **Accounts:** the recording created `demo.faseeh@example.com`, changed its email to `demo.faseeh.new@example.com`, and then **deleted it through the website's own Delete Account**.
- **Confirmed afterwards:** an Admin SDK lookup confirmed that neither address exists. No real user's account was touched.

### Video content (3:05, 1920×1080, 30 fps, H.264 + AAC)
| Part | What it shows |
|---|---|
| Intro and Release 1 roadmap | Same design as before |
| Home | Workflow and intended users |
| About Faseeh | Approaches and team |
| Workspace demonstration | Sample text, analysis labelled «عيّنة», the four-levels guide, target level, comparison |
| Nuqta help | Panel open, FAQ |
| Sign up | Disposable account |
| **Edit Email** | My Account → new email + current password → confirmation → new email on the page and in the header |
| **Login with the new email** | Log out → log in with the new address → success, the account shows the new email |
| **Delete Account** | Delete button → dialog requiring the current password → deletion confirmation → guest state → History redirects to login |
| Summary and credits | Same design as before |

**Audio:** soft background music and click/success sounds. **No voice-over:** the Azure Speech key is not set, so the steps are explained by on-screen Arabic captions instead.

**File checks:** `ffprobe` and a full decode — h264 1920×1080 30 fps + AAC, 185.5 s, no decode errors, mean audio −22.7 dB.

### Checks after this pass
| Check | Result |
|---|---|
| Build | Pass |
| PHPUnit | 40 tests, 135 assertions: OK |
| Browser suite | 105/105 |
| Markdown ↔ PDF | Every heading and figure caption of each `.md` was found in its `.pdf` (checked by text extraction) |
| Image legibility | Rendered PDF pages inspected |

### Files added or changed in this pass
**Documentation:**
- `docs/Firebase_Implementation.md` (rewritten)
- `docs/Firebase_Implementation.pdf` (new)
- `docs/firebase-screenshots/fb-01 … fb-42*.png` (43 images; they replace the earlier 15)
- `docs/firebase-screenshots/_index.json`
- `docs/Release1_Code_Implementation.md` (new)
- `docs/Release1_Code_Implementation.pdf` (new)
- `docs/release1-screenshots/ui-*.png` (35) and `site-*.jpg` (13)
- `docs/release1-screenshots/_index.json`
- `docs/tools/render_code_shots.cjs`, `md_to_pdf.cjs`, `shots-firebase.json`, `shots-release1.json` (new)
- `docs/demo/Faseeh_Release1_Final_Demo.mp4` (new)
- `docs/Code_Cleanup_Report.md`, `docs/Release1_Final_Verification.md`, `docs/Release1_Implementation_Audit.md` (updated)

**Video tooling** (outside the website, in `Downloads/faseeh-release1-demo/src/`):
- `record_final.cjs`, `make_compositor_final.cjs`, `compositor_final.html`, `build_final.cjs` (new)
- `demo_account.php` (now also allows the second disposable address)
- `frames_to_clips.cjs` (build folder is configurable)

**Website source (`frontend/`, `backend/src`):** **no changes in this pass.**
