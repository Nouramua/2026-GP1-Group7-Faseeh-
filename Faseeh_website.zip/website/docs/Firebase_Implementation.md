# Firebase Implementation — Faseeh Release 1

This document explains, function by function, how Faseeh uses **Firebase Authentication** and **Cloud Firestore** in Release 1. It follows a user's account lifecycle: configuration, registration, login, sessions, logout, password recovery, My Account, email change, and account deletion. It is written to support the implementation chapter of the graduation report.

**How the code images were made.** Every code image is a rendering of the **exact current lines** of the named source file, with their real line numbers. Nothing is retyped, shortened or edited.
- The images were generated on 22 November 2026 by `docs/tools/render_code_shots.cjs`, from the list in `docs/tools/shots-firebase.json`.
- Re-running the tool regenerates them from the current code.
- They are not photographs of an editor window.
- No credential, key, token, `.env` value or real user's email appears in any image.

**Evidence labels used throughout:**

| Label | What was run | Firebase used |
|---|---|---|
| **U** | Backend unit tests: PHPUnit, 40 tests, 135 assertions, all passing on 22 Nov 2026 | **Test double** (in-memory stand-in for Firebase) |
| **E** | Browser test suite: `backend/tests/Browser/release1.e2e.cjs`, 105/105 passing on 22 Nov 2026 | **Test double**, with the real PHP backend and real frontend |
| **R1** | First demo recording, 15–16 Nov 2026: sign up, log out, wrong-password error, log in, reset request, reset with a real Firebase reset code, log in with the new password | **Real Firebase project**, disposable `@example.com` account, deleted afterwards |
| **R2** | Final demo recording, 22 Nov 2026: sign up, **My Account, change email, log out, log in with the new email, delete account**, protected-page redirect | **Real Firebase project**, disposable `@example.com` accounts. Both addresses were confirmed absent through the Admin SDK afterwards. |

---

## 1. Overview and architecture

Faseeh never stores passwords itself.
- **Firebase Authentication** creates accounts, stores the hashed passwords, checks sign-ins, issues and verifies **session cookies**, sends password-reset emails, changes emails and deletes accounts.
- **Cloud Firestore** stores one **profile document** per user. In Release 1 the profile holds `email` and `createdAt`; in Release 2 Firestore will also hold saved results and ratings.

**Only the PHP backend talks to Firebase.** The React frontend calls only `/api/...` on the PHP backend. No Firebase SDK, key or configuration is sent to the browser, and the Firestore security rules refuse every direct browser request. This is the application and data layer of the System Architecture diagram: the account pages talk to the PHP backend, which "handles requests and verifies the user's Firebase session".

```
Browser (React pages)  ──JSON /api/...──►  PHP backend (App → AuthController / AccountController)
   ▲  HttpOnly session cookie                 │  KreaitAuthGateway  ── Admin SDK ──►  Firebase Authentication
   └──────────────────────────────────────────┤  FirestoreRestProfileStore ─ REST ─►  Cloud Firestore
```

The Firestore profile's **document ID is the Firebase Authentication UID**, which links the two services. The backend always takes the UID from the **verified session cookie**, never from the request body, so a user can act only on their own account.

---

## 2. Configuration and connection

### 2.1 Loading the Firebase configuration

**What it does.** Reads the Firebase project ID, the path to the service-account key, the Firestore collection and the session lifetime from environment variables (or `backend/.env`). It refuses to start if a required value is missing or unsafe.

**Step by step:**
1. `public/index.php` calls `Config::fromEnvironment(backend/.env)`.
2. Real environment variables win over the file.
3. Without `FIREBASE_CREDENTIALS`, or with an unreadable key file, the server stops. The only exception is when an emulator is configured.
4. The session lifetime must be between 300 s and 1,209,600 s (14 days), which is Firebase's limit for session cookies.

**Frontend:** none. **Backend:** `Config::fromEnvironment()`. **Firebase:** configuration only. **Jira:** FSEEH-82 (session lifetime).

![Loading and validating the Firebase configuration](firebase-screenshots/fb-01-config-firebase-settings.png)

*Figure 1 — `backend/src/Config.php`, lines 52–87.*

- **Lines 58–66:** the service-account key is referenced **by file path only**. The key file lives outside the project, so the code never contains or prints the key.
- **Lines 68–72:** reject a session lifetime Firebase would refuse, so the problem appears at start-up instead of at the first login.
- **Lines 74–86:** build the immutable `Config` object that the rest of the backend receives.

### 2.2 Initialising the Firebase Admin SDK

**What it does.** Creates the Firebase Admin SDK client for Authentication, and the Firestore REST client, both authorised with the same service account.

**Step by step:**
1. `App::create()` builds a `Factory` with the project ID.
2. It attaches the service-account file.
3. It creates the Authentication client, wrapped in `KreaitAuthGateway`.
4. It creates `FirestoreRestProfileStore` with the same project, database, collection and credentials.

**Frontend:** none. **Backend:** `App::create()`. **Firebase:** Admin SDK (`kreait/firebase-php` 7.x) and the Firestore REST API. **Jira:** FSEEH-79, FSEEH-82.

![Admin SDK initialisation](firebase-screenshots/fb-02-admin-sdk-factory.png)

*Figure 2 — `backend/src/App.php`, lines 61–82.*

- **Lines 63–66:** only for local emulator testing; not used with the real project.
- **Lines 67–70:** the `Factory` receives the project ID and the service-account path. This is the only place the backend is authorised as a Firebase administrator.
- **Line 72:** the Authentication client is wrapped in `KreaitAuthGateway`, so controllers depend on Faseeh's own `AuthGateway` interface. The tests can therefore replace Firebase with a test double.
- **Lines 73–80:** Firestore is reached through its REST API with the same credentials.

### 2.3 Cloud Firestore connection

**What it does.** Sends authorised HTTPS requests to the Firestore REST API and turns every error into one domain error, `ProfileWriteFailed`.

**Why REST.** The Firestore PHP client needs the `grpc` PHP extension, which typical PHP hosting doesn't provide. The REST API needs only HTTPS.

**Backend:** `FirestoreRestProfileStore::send()`, `collectionUrl()`, `accessToken()`. **Jira:** FSEEH-79.

![One authorised Firestore REST request](firebase-screenshots/fb-03-firestore-rest-request.png)

*Figure 3 — `backend/src/Firebase/FirestoreRestProfileStore.php`, lines 125–151.*

- **Line 128:** every request carries `Authorization: Bearer <access token>`.
- **Lines 129–130:** HTTP errors are inspected rather than thrown, and a 15-second timeout prevents endless waiting.
- **Lines 135–140:** a network failure becomes `ProfileWriteFailed`.
- **Lines 141–144:** "nothing there" statuses such as 404 are tolerated where the caller allows it.
- **Lines 145–148:** any other error status is reported with **only** the method and status, never the token or the document.

![Firestore URL and service-account access token](firebase-screenshots/fb-04-firestore-access-token.png)

*Figure 4 — `backend/src/Firebase/FirestoreRestProfileStore.php`, lines 160–189.*

- **Lines 162–171:** the document path is `projects/{id}/databases/{db}/documents/{collection}`, with each part URL-encoded.
- **Lines 183–188:** `ServiceAccountCredentials` signs a JWT with the service account and exchanges it for an OAuth 2.0 access token with the `datastore` scope.
- **Reuse:** the token is kept for the rest of the PHP request (a small efficiency change made in the cleanup), so one API call never fetches it twice.

---

## 3. Account registration

**Jira:** FSEEH-6 (Create an Account), with subtasks FSEEH-77, 78, 79 and 80.
**Endpoint:** `POST /api/auth/register`.
**Tests:** U, E, R1, R2.

### 3.1 Password and form validation

**What it does.** Checks the email format, the password policy (at least 8 characters, with uppercase, lowercase, a digit and a special character) and the confirmation, **in the browser and again on the server**.

**Step by step:**
1. The registration page shows a live checklist while the user types.
2. On submit, the page validates all three fields and focuses the first invalid one.
3. The request is sent.
4. The server repeats every check and returns field messages (HTTP 400) without creating anything.

**Frontend:** `Register` in `pages/Auth.tsx`; `PasswordRules` in `components/ui.tsx`; rules in `shared/validation.ts`. **Backend:** `AuthValidator`, `AuthController::register()`.

![Registration submit in the browser](firebase-screenshots/fb-06-register-form-browser.png)

*Figure 5 — `frontend/src/client/pages/Auth.tsx`, lines 157–176.*

- **Lines 160–164:** the three checks use the shared validation rules.
- **Line 167:** stops before any request if a field is invalid.
- **Lines 168–175:** on success, the backend has already created the account and set the HttpOnly session cookie. The page stores the returned user, shows the confirmation and goes to the home page (FSEEH-80).

![Server-side password policy](firebase-screenshots/fb-05-password-policy-server.png)

*Figure 6 — `backend/src/Validation/AuthValidator.php`, lines 43–81.*

- **Lines 45–51:** one regular expression per policy rule.
- **Lines 59–81:** build one Arabic message that lists every unmet rule. The 128-character ceiling is a security bound on what is sent to Firebase, not a product rule.

![Registration endpoint: server validation](firebase-screenshots/fb-07-register-validation-endpoint.png)

*Figure 7 — `backend/src/Controllers/AuthController.php`, lines 57–72.*

`V::collect()` keeps only the failed checks. A non-empty result is returned as HTTP 400 with per-field messages, and nothing reaches Firebase (FSEEH-78).

### 3.2 Creating the Firebase Authentication account

**What it does.** Asks Firebase to create the user. Firebase hashes and stores the password and returns the new **UID**.

![Creating the Firebase Authentication account](firebase-screenshots/fb-08-create-auth-account.png)

*Figure 8 — `backend/src/Firebase/KreaitAuthGateway.php`, lines 40–49.*

- `createUserWithEmailAndPassword` runs with administrator rights.
- Firebase compares emails case-insensitively. If the email already has an account, Firebase raises `EmailExists`; Faseeh turns it into `EmailAlreadyRegistered`, and the controller answers 409 with the message «هذا البريد مسجّل مسبقًا» (FSEEH-79, AC5).

### 3.3 Creating the Firestore profile, starting the session, and rolling back on failure

**What it does.** Creates the profile document right after the account, then signs the user in. If anything fails, the account is removed again, so a registration is **all or nothing**.

![Registration: profile, session and rollback](firebase-screenshots/fb-09-register-profile-session-rollback.png)

*Figure 9 — `backend/src/Controllers/AuthController.php`, lines 74–112.*

- **Lines 88–93:** the Firestore profile is created with the UID as its document ID. The backend then signs in to get an ID token and exchanges it for a session cookie (§4.2).
- **Lines 94–108:** if any step fails, the profile (if it was written) and the Firebase account are deleted, and the user sees a failure message that does not claim success (AC7).
- **Lines 110–112:** HTTP 201, with the user and a `Set-Cookie` header. The user is now signed in (C2a: Signing Up → Authenticated).

![Firestore profile document creation](firebase-screenshots/fb-10-create-firestore-profile.png)

*Figure 10 — `backend/src/Firebase/FirestoreRestProfileStore.php`, lines 63–74.*

- `?documentId={uid}` makes Firestore **refuse to overwrite** an existing document.
- The document holds only `email` (a `stringValue`) and `createdAt` (a `timestampValue`). **No password is ever written to Firestore** (Security NFR, story 39 AC3).

---

## 4. Login and sessions

**Jira:** FSEEH-7 (Log In), with subtasks FSEEH-81, 82, 83 and 84.
**Endpoint:** `POST /api/auth/login`.
**Tests:** U, E, R1, R2.

### 4.1 Credential verification

**What it does.** Firebase checks the email and password. Every failure produces the **same** general message, so the login page never reveals whether an email is registered (AC4).

![Login submit in the browser](firebase-screenshots/fb-11-login-form-browser.png)

*Figure 11 — `frontend/src/client/pages/Auth.tsx`, lines 91–107.*

- Both fields are required before sending (AC2).
- On success the page stores the user, shows «تم تسجيل الدخول» and opens the home page (AC3).

![Credential check with Firebase](firebase-screenshots/fb-12-credential-check-firebase.png)

*Figure 12 — `backend/src/Firebase/KreaitAuthGateway.php`, lines 68–89.*

- **Lines 74–77:** Firebase's "too many attempts" becomes HTTP 429.
- **Lines 78–81:** EMAIL_NOT_FOUND, INVALID_PASSWORD, INVALID_LOGIN_CREDENTIALS and USER_DISABLED are **deliberately collapsed** into one `InvalidCredentials` error (FSEEH-83).
- **Lines 83–88:** a successful sign-in returns a short-lived Firebase **ID token**.

![Login endpoint](firebase-screenshots/fb-13-login-endpoint.png)

*Figure 13 — `backend/src/Controllers/AuthController.php`, lines 124–154.*

- **Lines 138–142:** sign in, create the session cookie, and read the user back from it exactly as later requests will.
- **Lines 143–145:** the single message «البريد الإلكتروني أو كلمة المرور غير صحيحة».

### 4.2 Session-cookie creation and security

**What it does.** Exchanges the ID token for a **Firebase session cookie**: a signed token that Firebase issues and the backend can verify on every request (FSEEH-82). The browser stores it in an HttpOnly cookie.

![Creating and verifying the session cookie](firebase-screenshots/fb-14-session-cookie-create-verify.png)

*Figure 14 — `backend/src/Firebase/KreaitAuthGateway.php`, lines 98–126.*

- **Line 100:** `createSessionCookie(idToken, ttl)`. Firebase signs a session valid for `SESSION_TTL_SECONDS`.
- **Line 115:** `verifySessionCookie(cookie, true)` checks the signature and the expiry. The `true` also asks Firebase whether the user's sessions were **revoked** after the cookie was issued, which happens on logout, password reset or account deletion.
- **Lines 116–118:** any failure becomes `InvalidSession`.
- **Lines 119–125:** the UID comes from the token's `sub` claim. It is the only identity the backend trusts.

![Session cookie flags](firebase-screenshots/fb-15-session-cookie-flags.png)

*Figure 15 — `backend/src/Session/SessionCookie.php`, lines 54–73.*

- **`HttpOnly`:** page scripts cannot read the cookie, so injected script cannot steal it.
- **`SameSite=Lax`:** the cookie is not sent with cross-site form posts.
- **`Max-Age`:** the browser forgets the cookie when Firebase stops accepting it.
- **`Secure`:** added in production (HTTPS).
- **Clearing:** a negative TTL produces `Max-Age=0` plus a past `Expires`, which deletes the cookie.

**Test evidence (E):** the browser suite read the real `Set-Cookie` header: `HttpOnly; SameSite=Lax; Path=/; Max-Age=3600`. It also confirmed that `document.cookie` cannot see the session.

### 4.3 Protected routes and session verification

**What it does.** Every protected endpoint first verifies the session (FSEEH-84). Every protected page re-checks the session on entry and sends guests to the login page.

![Backend guard for protected endpoints](firebase-screenshots/fb-16-protected-endpoint-guard.png)

*Figure 16 — `backend/src/Controllers/AuthController.php`, lines 299–310.*

- No cookie returns 401 `unauthorized`.
- An expired or revoked cookie returns 401 `session_expired`.
- Otherwise the guard returns `{uid, email}` from the verified token. Every account operation starts here.

![Frontend route guard](firebase-screenshots/fb-17-protected-route-browser.png)

*Figure 17 — `frontend/src/client/App.tsx`, lines 20–41.*

- On every entry to `/profile`, `/history` or `/stats`, `RequireAuth` asks the backend for the session again.
- A guest is redirected to `/login` with `replace`, so the Back button does not loop.
- This guard is for the interface only; the backend guard in Figure 16 is the security boundary.

---

## 5. Session expiration and the guest state

**Jira:** FSEEH-113 (subtask of FSEEH-12).
**Endpoint:** `GET /api/auth/session`.
**Tests:** U, E. Expiry was **not** tested against real Firebase; see §10.

**What it does.** When a session cookie expires or is revoked, the interface returns to the **Guest** state, says that the session ended, and protected pages require login (Log Out AC5).

**Step by step:**
1. **Expiry is enforced in two places:** the browser drops the cookie after `Max-Age`, and Firebase rejects an expired cookie.
2. `GET /api/auth/session` answers `{user: null, expired: true}` and clears the cookie.
3. **When the frontend re-checks:**
   - on load;
   - when the tab becomes visible;
   - every 5 minutes;
   - on every protected page.
4. When a session that existed is gone, the header switches to the guest buttons and a "your session ended" message appears.
5. **Expiry while My Account is open** (fixed in this audit): a request that gets 401 also triggers the switch to Guest, then a redirect to login.

![Session state endpoint](firebase-screenshots/fb-18-session-state-endpoint.png)

*Figure 18 — `backend/src/Controllers/AuthController.php`, lines 188–199.*

- No cookie means Guest.
- A valid cookie returns the user.
- An invalid cookie returns `expired: true` and deletes the cookie, so the browser stops sending a dead session.

![Frontend session re-check](firebase-screenshots/fb-19-session-recheck-browser.png)

*Figure 19 — `frontend/src/client/lib/session.tsx`, lines 66–82.*

- **Lines 69–73:** if the backend says "no user" while the page still had one, the session has expired. The Workspace draft is cleared and `expired` is set.
- **Lines 76–78:** if the backend is unreachable, the current state is kept; protected pages check again on entry.

![Expiry while My Account is open](firebase-screenshots/fb-20-expiry-while-on-my-account.png)

*Figure 20 — `frontend/src/client/pages/Profile.tsx`, lines 40–46.*

- Only a 401 counts as a lost session; a wrong current password is a 400 field error.
- `refreshSession()` switches the interface to Guest, and the user is sent to the login page.

![The "session ended" message](firebase-screenshots/fb-21-session-ended-message.png)

*Figure 21 — `frontend/src/client/components/Layout.tsx`, lines 157–167.*

The layout shows «انتهت جلستك. سجّل الدخول مرة أخرى.» once, then clears the flag.

**Test evidence (E), with the test double's clock moved past the 3,600-second TTL:**
- the backend answered `expired: true`;
- the protected page went to `/login` without a loop;
- the header showed the guest buttons;
- `/api/account` returned 401;
- the email was unchanged after the rejected request;
- expiry while My Account was open returned the interface to Guest and the login page.

---

## 6. Logout and session invalidation

**Jira:** FSEEH-12 (Log Out), with subtasks FSEEH-89, 90 and 91.
**Endpoint:** `POST /api/auth/logout`.
**Tests:** U, E, R1, R2.

**What it does.** The user's Firebase sessions are revoked, the cookie is deleted, and the page returns to Guest without showing private data. The account and profile are kept (AC3).

![Logout endpoint](firebase-screenshots/fb-22-logout-endpoint.png)

*Figure 22 — `backend/src/Controllers/AuthController.php`, lines 163–179.*

- The cookie is verified so the backend knows whose sessions to end.
- An already-expired cookie is not an error.
- If Firebase cannot be reached, the cookie is still deleted, and the Firebase session ends by itself when its lifetime runs out.
- The response always clears the cookie.

![Revoking the sessions in Firebase](firebase-screenshots/fb-23-revoke-sessions-firebase.png)

*Figure 23 — `backend/src/Firebase/KreaitAuthGateway.php`, lines 133–136.*

- **Why all sessions:** Firebase cannot revoke a single session cookie, so `revokeRefreshTokens(uid)` ends **all** of the user's sessions (decision D3). From then on, `verifySessionCookie(…, true)` rejects every older cookie.
- **Test evidence (E):** a copied old cookie returned 401 after logout.

![Logout in the browser](firebase-screenshots/fb-24-logout-browser.png)

*Figure 24 — `frontend/src/client/lib/session.tsx`, lines 109–118.*

Even if the request fails, the page forgets the user and clears the Workspace draft, so nothing private stays on screen (AC4).

---

## 7. Password recovery

**Jira:** FSEEH-26 (Recover a Forgotten Password), with subtasks FSEEH-85, 86, 87 and 88.
**Endpoints:** `POST /api/auth/password-reset/request`, `/verify` and `/confirm`.
**Tests:** U, E, R1. **Not verified:** that the email reaches an inbox.

### 7.1 Forgot Password and the reset email

**What it does.** The user enters an email.
- **Registered:** Firebase emails a reset link and a confirmation is shown.
- **Not registered:** the message «لا يوجد حساب مرتبط بهذا البريد الإلكتروني» appears and no email is sent. AC4 of the backlog requires this. Login deliberately hides it, so the two differ by design (decision D4).

![Forgot-password endpoint](firebase-screenshots/fb-25-forgot-password-endpoint.png)

*Figure 25 — `backend/src/Controllers/AuthController.php`, lines 210–233.*

The steps run in the order of the C2b diagram:
1. Validate the email format.
2. Check whether the email is registered.
3. For an unknown email, return 404 with a field message.
4. Otherwise ask Firebase to send the link.

Each Firebase failure becomes a safe 502 message.

![Registration lookup and reset email](firebase-screenshots/fb-26-reset-email-firebase.png)

*Figure 26 — `backend/src/Firebase/KreaitAuthGateway.php`, lines 143–160.*

- `getUserByEmail` answers "registered or not".
- `sendPasswordResetLink(email, null, 'ar')` makes Firebase send its reset email in Arabic.

### 7.2 Invalid or expired reset links, and the new password

**What it does.** The emailed link opens `/reset-password?oobCode=…`.
1. The page first asks the backend whether the code is valid.
2. If the code is unknown, expired or already used, the page shows "invalid link" (AC7).
3. Otherwise the user sets a new password that meets the same policy.
4. Firebase consumes the code, so the link can't be reused, and ends the old sessions (AC8).

![Reset-link endpoints](firebase-screenshots/fb-27-reset-link-endpoints-part1.png)

*Figure 27a — `backend/src/Controllers/AuthController.php`, lines 241–264: verifying the code.*

![Reset-link endpoints, continued](firebase-screenshots/fb-27-reset-link-endpoints-part2.png)

*Figure 27b — the same file, lines 265–287: checking the new password's policy and match, then updating it.*

![Firebase reset-code calls](firebase-screenshots/fb-28-reset-code-firebase.png)

*Figure 28 — `backend/src/Firebase/KreaitAuthGateway.php`, lines 169–202.*

- `verifyPasswordResetCode` returns the account's email for a valid code.
- `confirmPasswordReset(code, password, true)` sets the password; `true` ends the sessions opened with the old password.
- Unknown and expired codes become `InvalidResetLink`.

![Reset page checks the link on open](firebase-screenshots/fb-29-reset-page-browser.png)

*Figure 29 — `frontend/src/client/pages/Auth.tsx`, lines 279–288.*

Without a code, or with a code Firebase rejects, the page shows the invalid-link screen, which offers to request a new link.

---

## 8. My Account and email change

**Jira:** FSEEH-49 (Edit Profile), with subtasks FSEEH-92, 93, 94 and 116.
**Endpoints:** `GET /api/account`, `POST /api/account/email`.
**Tests:** U, E, **R2**.

### 8.1 Retrieving the profile

**What it does.** My Account shows the account's email and creation date. It is open only with a valid session.

![My Account endpoint](firebase-screenshots/fb-30-my-account-endpoint.png)

*Figure 30 — `backend/src/Controllers/AccountController.php`, lines 50–63.*

The user comes from `requireUser()`. The email comes from the verified session, because Firebase Authentication is the source of truth; `createdAt` comes from the Firestore profile.

![Reading the profile from Firestore](firebase-screenshots/fb-31-profile-read-firestore.png)

*Figure 31 — `backend/src/Firebase/FirestoreRestProfileStore.php`, lines 90–102.*

A 404 means "no profile" (`null`). Firestore's typed values are unwrapped into plain strings.

### 8.2 Changing the email

**What it does.** The user enters a new email and the **current password**. The email changes in Firebase Authentication **and** in the Firestore profile. The page and the header show the new email, and the next login works only with it.

**Step by step:**
1. **Validate:** the email must be present, well-formed and different from the current one, and the password must be present.
2. **Re-authenticate:** check the current password.
3. **Firebase Authentication:** `changeUserEmail`.
4. **Firestore:** update the `email` field.
5. **New session:** the old cookie still carries the old email.
6. **On failure after step 3:** both changes are undone.

![Change-email form in the browser](firebase-screenshots/fb-32-change-email-browser.png)

*Figure 32 — `frontend/src/client/pages/Profile.tsx`, lines 75–105.*

- **Lines 78–87:** field validation before sending.
- **Lines 89–95:** on success, the new user (with the new email) is stored, so the header and the page update together (AC7).
- **Lines 96–101:** a lost session goes to Guest; field errors appear under their fields.

![Change-email validation and re-authentication](firebase-screenshots/fb-33-change-email-validation.png)

*Figure 33 — `backend/src/Controllers/AccountController.php`, lines 77–97.*

`strcasecmp` rejects an unchanged email whatever its letter case. `confirmPassword()` (Figure 38) runs **before** anything changes, so a wrong password changes nothing (AC5).

### 8.3 Keeping Firebase Authentication and Firestore in sync, and handling failures

![Email change: Auth, Firestore, new session, rollback](firebase-screenshots/fb-34-change-email-sync-rollback.png)

*Figure 34 — `backend/src/Controllers/AccountController.php`, lines 99–128.*

- **Lines 99–108:** Firebase Authentication changes first. If the email belongs to another account, the result is 409 with the message under the email field (AC6, FSEEH-116).
- **Lines 110–113:** the Firestore profile is updated, and a new session cookie is issued for the new email.
- **Lines 114–123:** if either step fails, the old email is written back to **both** Firebase Authentication and Firestore. The user sees "nothing changed" (AC9, FSEEH-116).

![Email change in Firebase Authentication](firebase-screenshots/fb-35-change-email-firebase.png)

*Figure 35 — `backend/src/Firebase/KreaitAuthGateway.php`, lines 208–215.*

![Email change in the Firestore profile](firebase-screenshots/fb-36-change-email-firestore.png)

*Figure 36 — `backend/src/Firebase/FirestoreRestProfileStore.php`, lines 109–113.*

- `updateMask.fieldPaths=email` changes only that field.
- `currentDocument.exists=true` makes the update fail instead of creating a new document if the profile is missing.

**Test evidence:**
- **E (test double):**
  - unchanged email rejected;
  - wrong password rejected;
  - another account's email rejected;
  - a **simulated Firestore failure** left the old email in both stores;
  - a valid change updated both stores, the page and the header;
  - afterwards the old email failed to log in and the new one succeeded.
- **R2 (real Firebase, 22 Nov 2026):** the disposable account's email was changed on My Account. The confirmation «تم تغيير بريدك الإلكتروني» appeared and the header showed the new address. After logging out, **login with the new email succeeded**, and My Account showed the new email.

---

## 9. Account deletion

**Jira:** FSEEH-50 (Delete Account), with subtasks FSEEH-95, 96 and 97.
**Endpoint:** `POST /api/account/delete`.
**Tests:** U, E, **R2**.

**What it does.** After a confirmation dialog and the current password, the Firestore profile and the Firebase Authentication account are deleted, the session ends, and the user returns to the home page as a Guest.

**Step by step:**
1. **Confirmation dialog** (FSEEH-95): it requires the current password. Cancel changes nothing.
2. **Password check:** a missing or wrong password returns 400 and deletes nothing.
3. **Keep a copy:** the backend reads the profile so it can be restored if needed.
4. **Firestore:** delete the profile (FSEEH-96).
5. **Firebase Authentication:** delete the account, which removes its email and invalidates every session (FSEEH-96).
6. **If step 5 fails:** the profile is recreated from the copy, so nothing is half-deleted (AC8).
7. **End the session:** the cookie is cleared. The page forgets the user and shows the confirmation on the home page (FSEEH-97).

![Delete confirmation in the browser](firebase-screenshots/fb-38-delete-dialog-browser.png)

*Figure 37 — `frontend/src/client/pages/Profile.tsx`, lines 114–144.*

- An empty password stops in the browser.
- On success the Workspace draft is cleared, the user is set to Guest, the dialog closes, and the home page shows «حُذف حسابك وكل بياناته».

![Re-authentication with the current password](firebase-screenshots/fb-37-current-password-check.png)

*Figure 38 — `backend/src/Controllers/AccountController.php`, lines 187–201.*

- Signing in with the typed password proves the user knows it.
- A wrong password is a **400 field error, not a 401**: the session is still valid, only the typed password is wrong.

![Delete Account endpoint](firebase-screenshots/fb-39-delete-account-endpoint.png)

*Figure 39 — `backend/src/Controllers/AccountController.php`, lines 144–179.*

The order (profile first, then account, restoring the profile on failure) means a failure can never leave an account without its profile. The response clears the cookie.

![Deleting the Firebase Authentication user](firebase-screenshots/fb-40-delete-auth-user-firebase.png)

*Figure 40 — `backend/src/Firebase/KreaitAuthGateway.php`, lines 56–59.*

![Deleting the Firestore profile](firebase-screenshots/fb-41-delete-firestore-profile.png)

*Figure 41 — `backend/src/Firebase/FirestoreRestProfileStore.php`, lines 80–83.*

A 404 is tolerated: a profile that is already gone counts as deleted.

> **Release 1 compared with Release 2:**
> - **Release 1:** the account and its profile are the only stored user data, and both are deleted.
> - **Release 2 (story 6 AC5; stories 15 and 21):** deleting the account's **saved records**, and keeping its ratings and feedback only as **anonymised** evaluation data. These are **not implemented** because those records don't exist yet.

**Test evidence:**
- **E (test double):**
  - cancel, a missing password and a wrong password deleted nothing;
  - a **simulated Firebase Authentication failure** left the account and profile intact;
  - success removed both;
  - the user was signed out, and protected pages required login;
  - the old credentials failed, and the email could register again;
  - another account was unaffected.
- **R2 (real Firebase, 22 Nov 2026):**
  - the dialog required the password;
  - deletion showed «حُذف حسابك وكل بياناته» on the home page, with the guest header;
  - opening History then redirected to the login page;
  - afterwards, an Admin SDK lookup confirmed that **neither test address exists** in Firebase Authentication.
- **About the Firestore profile in R2:** it was not inspected separately in the console. The code deletes the profile **before** the account and stops with an error if that fails, so the account's successful deletion means the profile deletion succeeded too.

---

## 10. Security summary

| Control | Where |
|---|---|
| Firebase is reached only by the backend; the browser holds no Firebase configuration | Architecture; `services/http.ts` calls only `/api` |
| Firestore rules deny all client reads and writes | `firestore.rules`, Figure 42 |
| Session verified on every protected request, including revocation | Figures 14 and 16 |
| Identity only from the verified token | `requireUser()` |
| Cookie `HttpOnly`, `SameSite=Lax`, `Max-Age`, `Secure` in production | Figure 15 |
| State-changing requests must be JSON from the same origin | `App::guardCrossSite()` |
| Server-side validation of every field | Figures 6 and 7 |
| General login error | Figure 12 |
| Current password required to change the email or delete the account | Figure 38 |
| Rollback so Authentication and Firestore never disagree | Figures 9, 34 and 39 |
| No password in Firestore; secrets referenced by path | Figures 1 and 10 |

![Firestore security rules](firebase-screenshots/fb-42-firestore-security-rules.png)

*Figure 42 — `firestore.rules`, lines 1–13: `allow read, write: if false` for every document. The backend's service account is not subject to these rules; browsers are.*

---

## 11. Verification status

| Functionality | Test double (U, E) | Real Firebase |
|---|---|---|
| Registration (account + profile + session) | ✅ | ✅ R1, R2 |
| Login and general error | ✅ | ✅ R1 (wrong password, then success), R2 (login with the new email) |
| Logout | ✅ (including old-cookie replay) | ✅ R1, R2 |
| Protected-page redirect | ✅ | ✅ R2 (History → login after deletion) |
| Session expiration | ✅ (clock advanced past the TTL) | ❌ **not yet tested.** Needs `SESSION_TTL_SECONDS=300` and a 5-minute wait (`docs/TESTING.md` §3 item 12). |
| Forgot password: registered and unregistered | ✅ | ✅ R1 (registered; request accepted by Firebase) |
| Reset email delivered to an inbox | — | ❌ **not verified.** R1 obtained the reset code through the Admin SDK because `@example.com` cannot receive email. |
| Reset link: invalid, used, new password | ✅ | ✅ R1 (valid code, new password, login with it) |
| My Account profile | ✅ | ✅ R2 |
| Change email (Auth + Firestore) | ✅ (including rollback) | ✅ R2. The rollback path was tested only with the double. |
| Delete account (Auth + Firestore) | ✅ (including rollback) | ✅ R2. Auth deletion was confirmed by lookup; Firestore deletion is inferred from the code path. The rollback path was tested only with the double. |

**Release 2 functionality is not documented here as implemented:** saving, history, ratings, statistics, downloads, and deleting or anonymising saved records.
