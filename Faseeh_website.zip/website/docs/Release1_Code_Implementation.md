# Release 1 Code Implementation — Faseeh

This document explains how each Release 1 user-facing feature of the Faseeh website is implemented. For each feature it gives the user interface (React + TypeScript) first, then the backend (PHP) where there is one, with the matching Jira items. The Firebase side of the account features is covered in more depth in **`Firebase_Implementation.md`**, which this document refers to rather than repeating.

**How the images were made:**
- **Code images** (`release1-screenshots/ui-*.png`, `firebase-screenshots/fb-*.png`) are renderings of the **exact current lines** of the named file, with their real line numbers. They were generated on 22 November 2026 by `docs/tools/render_code_shots.cjs` from `docs/tools/shots-release1.json` and `shots-firebase.json`.
- **Website images** (`release1-screenshots/site-*.jpg`) are frames from the recording of the **real website** made on 22 November 2026. That recording used the real PHP backend and the real Firebase project, with disposable `@example.com` test accounts that the website itself deleted at the end. Passwords appear only as dots.

**Status of each feature:**

| Status | Meaning |
|---|---|
| **Complete (R1)** | Implemented and verified for Release 1 |
| **Demonstration** | The interface is complete, but its results are labelled sample data until the models are connected in Release 2 |
| **Release 2** | Reserved; shown only as "available in Release 2" or not shown |

**Test evidence:** **U** = PHPUnit, 40 tests (test double). **E** = browser suite, 105 checks (real backend + Firebase test double). **R** = real Firebase recordings (15–16 Nov and 22 Nov 2026). Details are in `Release1_Final_Verification.md`.

---

## 1. Application structure

**Status:** Complete (R1).

The single-page app has one route table. Protected pages are wrapped in `RequireAuth`, which re-checks the session with the backend on every entry (Jira FSEEH-84). The Release 2 pages (`/history`, `/stats`) exist behind real authentication and only say they arrive in Release 2.

![Route table](release1-screenshots/ui-01-routes-and-guard.png)

*Figure 1 — `frontend/src/client/App.tsx`, lines 92–107: every page of the site.*
- **Public pages:** Home, Workspace, About, Login, Register, Forgot Password, Reset Password.
- **Protected pages** (wrapped in `RequireAuth`): My Account, History and Statistics.
- **Fallback:** a "not found" page.

All server communication goes through one function. It calls only `/api/...` on Faseeh's own origin, so the browser never talks to Firebase. It also turns any error response into an `ApiRequestError` with an Arabic message and per-field errors.

![The browser's only API client](release1-screenshots/ui-29-browser-api-client.png)

*Figure 2 — `frontend/src/client/services/http.ts`, lines 21–52.*
- `credentials: "same-origin"` lets the browser attach the HttpOnly session cookie automatically.
- The JSON content type is what the backend's cross-site guard requires.
- The body is read as text first, so an empty or invalid response cannot crash the page.

---

## 2. Home page

**Status:** Complete (R1). **Jira:** FSEEH-51 (Learn About Faseeh), FSEEH-98. **Backend:** none (static page). **Tests:** E.

**What it does.** Introduces Faseeh to guests:
- its purpose and the logo animation;
- the four-step workflow;
- the four readability levels;
- the intended users;
- an illustrative before/after example;
- buttons to try the Workspace as a guest or to create an account.

![Home page (real website)](release1-screenshots/site-01-home.jpg)

*Figure 3 — the home page as it is now (recording, 22 Nov 2026).*

![Home page workflow section (real website)](release1-screenshots/site-02-home-workflow.jpg)

*Figure 4 — the "how Faseeh works" section further down the home page.*

![Workflow steps and intended users](release1-screenshots/ui-02-home-workflow-audience.png)

*Figure 5 — `frontend/src/client/pages/Home.tsx`, lines 65–77.*
- The four workflow steps and the intended users are data arrays that the page maps into sections.
- The first step no longer mentions a character limit; it was removed in the 22 Nov audit.

![Illustrative example, labelled](release1-screenshots/ui-03-home-illustrative-preview.png)

*Figure 6 — `Home.tsx`, lines 28–53.*
- The before/after example is fixed text written for the page.
- Its caption says «مثال توضيحي لشكل المقارنة، وليس ناتجًا حيًّا من النموذج» ("an illustrative example, not live model output"), as Learn About Faseeh AC4 requires.

![Guest and sign-up options](release1-screenshots/ui-04-home-guest-and-signup.png)

*Figure 7 — `Home.tsx`, lines 247–264.*
- The closing section offers «التجربة كزائر» (try as a guest) and «إنشاء حساب» (create an account), as AC2 requires.
- No login is needed to see any of this page (AC5).

---

## 3. About Faseeh page

**Status:** Complete (R1). **Jira:** FSEEH-99. **Backend:** none. **Tests:** E (reachable from the header and the footer).

![About page, team section (real website)](release1-screenshots/site-03-about-team.jpg)

*Figure 8 — the About page's team section (recording, 22 Nov 2026).*

![Processing steps and team list](release1-screenshots/ui-05-about-pipeline-team.png)

*Figure 9 — `frontend/src/client/pages/About.tsx`, lines 7–15.*
- The team names and the five processing steps are data arrays: text → classifier → target level → simplification model → level check.

![Approaches and supervisor](release1-screenshots/ui-06-about-approaches-supervisor.png)

*Figure 10 — `About.tsx`, lines 61–93.*
- **Three cards:** the data, the classification approach (the traditional and deep-learning models compared in Sprint 1) and the simplification approach.
- **Simplification card:** it says the simplification model is still in development and will be connected later.
- **Team card:** it names the team and the supervisor (AC3).

---

## 4. Registration

**Status:** Complete (R1). **Jira:** FSEEH-6; subtasks FSEEH-77 (page and live checklist), 78 (server validation), 79 (Firebase account and Firestore profile), 80 (messages). **Tests:** U, E, R.

### 4.1 User interface

![Registration with the live password checklist (real website)](release1-screenshots/site-08-register-checklist.jpg)

*Figure 11 — registration with a disposable account; the checklist ticks rules off as the password is typed (recording, 22 Nov 2026).*

![Password rules shared by the browser and the server](release1-screenshots/ui-08-password-rules-browser.png)

*Figure 12 — `frontend/src/shared/validation.ts`, lines 19–36.*
- **Rules:** at least 8 characters, an uppercase letter, a lowercase letter, a digit and a special character.
- **Each rule** has an Arabic label shown in the checklist.
- **`validatePassword`** builds one message that lists the rules not yet met.

![Live checklist component](release1-screenshots/ui-09-password-checklist-component.png)

*Figure 13 — `frontend/src/client/components/ui.tsx`, lines 63–75.*
- Each rule is a list item marked "met" as the user types.
- A visually hidden text, «(مستوفى)» or «(غير مستوفى)» ("met" or "not met"), tells screen-reader users the state of each rule.

![Shared form error handling](release1-screenshots/ui-10-shared-form-errors.png)

*Figure 14 — `frontend/src/client/pages/Auth.tsx`, lines 47–67.*
- All account forms use `run()`.
- A server error with field messages shows each message under its field; any other error appears once at the top of the form.

The submit handler is shown in `Firebase_Implementation.md`, Figure 5.

### 4.2 Backend

- **Validation:** `AuthController::register()` re-validates with `AuthValidator`.
- **Account:** it creates the Firebase account.
- **Profile:** it creates the Firestore profile keyed by the account's UID.
- **Session:** it starts the session.
- **Rollback:** if a step fails, it removes the half-created account.

See `Firebase_Implementation.md` §3, Figures 6–10.

---

## 5. Login

**Status:** Complete (R1). **Jira:** FSEEH-7; FSEEH-81 (page), 82 (session cookie), 83 (general error), 84 (protected pages). **Tests:** U, E, R.

**User interface:** the `Login` page in `Auth.tsx` (`Firebase_Implementation.md`, Figure 11).
- Both fields are required.
- A "forgot password?" link leads to recovery.
- On success the page stores the user, shows «تم تسجيل الدخول» and opens the home page.

**Backend:** `AuthController::login()` checks the credentials with Firebase and issues the HttpOnly session cookie. A wrong password and an unknown email give the **same** message. See `Firebase_Implementation.md` §4, Figures 12–15.

---

## 6. Logout

**Status:** Complete (R1). **Jira:** FSEEH-12; FSEEH-89 (control), 90 (revoke and delete the cookie), 91 (guest state). **Tests:** U, E, R.

![Header navigation and account menu with Log Out](release1-screenshots/ui-07-header-nav-account-menu-part1.png)

*Figure 15 — `frontend/src/client/components/Layout.tsx`, lines 39–64.*
- **The logout handler:** waits for the session logout, shows «سُجّل خروجك بأمان» ("you were signed out safely") and returns to the public home page.
- **The account menu:** closes when the user clicks outside it or presses Esc.

![Account menu markup](release1-screenshots/ui-07-header-nav-account-menu-part2.png)

*Figure 16 — `Layout.tsx`, lines 65–89.*
- **Signed in:** the header shows the account email. The menu offers «حسابي» (My Account), «سجلّي» (History), «إحصاءاتي» (Statistics) and the clearly labelled «تسجيل الخروج» (Log Out).
- **Guest:** the header shows Log In and Create Account instead.

**Backend:** `AuthController::logout()` revokes the user's Firebase sessions and deletes the cookie (`Firebase_Implementation.md` §6).

---

## 7. Password recovery

**Status:** Complete (R1). Delivery of the reset email to an inbox has not been verified. **Jira:** FSEEH-26; FSEEH-85, 86, 87, 88. **Tests:** U, E, R.

![Forgot-password page logic](release1-screenshots/ui-11-forgot-password-page.png)

*Figure 17 — `frontend/src/client/pages/Auth.tsx`, lines 213–230.*
1. The email format is checked first.
2. An unregistered email comes back as a field error, «لا يوجد حساب مرتبط بهذا البريد الإلكتروني».
3. Success switches the card to a confirmation naming the address.

**Reset page.** The reset page checks the link's code as soon as it opens (`Firebase_Implementation.md`, Figure 29).
- An unknown, expired or used code shows «رابط غير صالح» (invalid link) and offers a new link.
- A valid code shows the new-password form, with the same live checklist as registration.

**Backend:** `Firebase_Implementation.md` §7.

---

## 8. My Account

**Status:** Complete (R1). **Jira:** FSEEH-49; FSEEH-92 (page). **Tests:** U, E, R (22 Nov).

![My Account page markup](release1-screenshots/ui-12-my-account-forms-part1.png)

*Figure 18 — `frontend/src/client/pages/Profile.tsx`, lines 153–179.*
- **Account panel:** shows the email and «عضو منذ» (member since), the creation date.
- **Loading and errors:** the panel shows a loading state while the data loads, and a retry button if loading fails.

![Edit-email form markup](release1-screenshots/ui-12-my-account-forms-part2.png)

*Figure 19 — `Profile.tsx`, lines 180–205.*
- The edit form has exactly two fields: the new email and the current password. **Only the email can be edited** (Edit Profile AC3).
- Each field shows its own error underneath.

**Backend:** `AccountController::show()` (`Firebase_Implementation.md`, Figures 30–31).

---

## 9. Edit Email

**Status:** Complete (R1). **Jira:** FSEEH-49; FSEEH-93 (form + password check), 94 (Authentication + Firestore update), 116 (duplicate email and failure). **Tests:** U, E, R (22 Nov: change, then log in with the new email).

![Email changed (real website)](release1-screenshots/site-09-email-changed.jpg)

*Figure 20 — right after a successful change: the confirmation «تم تغيير بريدك الإلكتروني», the new email in the account panel and in the header (recording, 22 Nov 2026, real Firebase).*

![Signed in again with the new email (real website)](release1-screenshots/site-10-login-new-email.jpg)

*Figure 21 — after logging out and **logging in with the new email**: «تم تسجيل الدخول», and the header shows the new address.*

**User interface:** `submitEmail` in `Profile.tsx` (`Firebase_Implementation.md`, Figure 32).
1. It validates the fields first.
2. It sends the change.
3. On success it stores the returned user, so the header and the page show the new email at the same moment.
4. On failure it shows the server's field errors under the matching fields.

**Backend:** `AccountController::changeEmail()`, in this order:
1. Validate the input.
2. Check the current password.
3. Change the email in Firebase Authentication.
4. Change the email in the Firestore profile.
5. Issue a new session for the new email.

If a step fails, the old email is restored in both places. See `Firebase_Implementation.md` §8, Figures 33–36.

---

## 10. Delete Account

**Status:** Complete (R1). Removing saved records and anonymising feedback on deletion are Release 2. **Jira:** FSEEH-50; FSEEH-95 (dialog with password), 96 (Authentication + Firestore deletion), 97 (end session, confirmation). **Tests:** U, E, R (22 Nov).

![Delete dialog (real website)](release1-screenshots/site-11-delete-dialog.jpg)

*Figure 22 — the confirmation dialog: the current password is required before anything is deleted (recording, 22 Nov 2026).*

![Deleted, back to Guest (real website)](release1-screenshots/site-12-deleted-guest.jpg)

*Figure 23 — after deletion: the home page shows «حُذف حسابك وكل بياناته» and the guest buttons.*

![Protected page requires login again (real website)](release1-screenshots/site-13-protected-redirect.jpg)

*Figure 24 — opening History as a guest leads to the login page.*

![Delete section and dialog markup](release1-screenshots/ui-13-delete-dialog-markup-part1.png)

*Figure 25 — `frontend/src/client/pages/Profile.tsx`, lines 206–229.*
- The danger section has a clearly labelled «حذف الحساب» (Delete Account) button that opens the dialog.

![Dialog actions and password field](release1-screenshots/ui-13-delete-dialog-markup-part2.png)

*Figure 26 — `Profile.tsx`, lines 230–253.*
- **Buttons:** the dialog offers «نعم، احذف حسابي» (yes, delete my account) and «إلغاء» (cancel).
- **Password field:** the dialog asks for the password, and pressing Enter in it confirms.
- **Errors:** they appear inside the dialog.

![Native dialog component](release1-screenshots/ui-14-native-dialog-part1.png)

*Figure 27 — `frontend/src/client/components/ui.tsx`, lines 78–98.*
- The dialog uses the browser's native `<dialog>` with `showModal()`, which provides the modal focus trap and closing with Esc.

![Native dialog component, continued](release1-screenshots/ui-14-native-dialog-part2.png)

*Figure 28 — `ui.tsx`, lines 99–118.*
- The dialog is labelled by its title (`aria-labelledby`).
- Clicking the backdrop cancels.

**Backend:** `AccountController::delete()`, in this order:
1. Check the current password.
2. Delete the Firestore profile.
3. Delete the Firebase Authentication account. If this fails, the profile is restored.
4. Clear the session cookie.

See `Firebase_Implementation.md` §9.

---

## 11. Readability-level descriptions

**Status:** Complete (R1). **Jira:** FSEEH-16; FSEEH-110 (descriptions from the agreed mapping), 111 (shown before target selection and with results), 112 (consistent labels). **Tests:** browser probe, 5/5.

![Level guide dialog (real website)](release1-screenshots/site-05-level-guide.jpg)

*Figure 29 — the «ما المستويات الأربعة؟» ("what are the four levels?") dialog in the Workspace (recording, 22 Nov 2026).*

![Level definitions](release1-screenshots/ui-15-level-definitions.png)

*Figure 30 — `frontend/src/shared/levels.ts`, lines 26–35.*
- `LEVEL_INFO` is the **single source** of each level's numeral, name, short label, description, traits and example. Level 1 is shown here.
- Every component reads from it, so labels and order are always consistent (FSEEH-112).

![Level guide](release1-screenshots/ui-16-level-guide.png)

*Figure 31 — `frontend/src/client/components/Levels.tsx`, lines 114–151.*
- `LevelGuide` lists the four levels in order with a description, and, in the full version, their traits and an example.
- The headings include visually hidden text («المستوى ١: …»), so screen readers announce the level number.

![Target-level picker](release1-screenshots/ui-17-level-picker.png)

*Figure 32 — `Levels.tsx`, lines 74–111.*
- **All four levels** are shown as radio buttons.
- **Harder levels** are disabled, with a tooltip saying they are not easier than the text's level.
- **The text's own level** is tagged «مستوى نصّك» ("your text's level").
- **Keyboard:** the arrow keys move between options.
- **Unchanged text:** opening the guide does not change the entered text or the selected level (verified by the probe).

---

## 12. Nuqta help button and help panel

**Status:** Complete (R1). **Jira:** FSEEH-52; FSEEH-100 (button and panel), 101 (page guidance and FAQ). **Tests:** E.

![Help panel open (real website)](release1-screenshots/site-07-help-panel.jpg)

*Figure 33 — «نقطة» open in the Workspace: guidance for the current state, and the frequently asked questions (recording, 22 Nov 2026).*

![Topic per page](release1-screenshots/ui-18-help-topics-and-faq.png)

*Figure 34 — `frontend/src/client/lib/assistant.tsx`, lines 43–56.*
- Each page or state calls `useAssistantTopic("…")`.
- The help panel then shows the matching predefined tip from `TIPS`.
- No AI model is involved (AC8).

![FAQ content](release1-screenshots/ui-19-help-faq-content.png)

*Figure 35 — `assistant.tsx`, lines 159–180: the predefined questions and answers.*

![Help panel markup](release1-screenshots/ui-22-help-panel-markup-part1.png)

*Figure 36 — `frontend/src/client/components/Assistant.tsx`, lines 80–107.*
- The panel is a labelled, non-modal `role="dialog"` with a close button «إغلاق المساعدة» (close help).

![Help panel markup, FAQ](release1-screenshots/ui-22-help-panel-markup-part2.png)

*Figure 37 — `Assistant.tsx`, lines 108–135.*
- Each FAQ question is a real `<button>` with `aria-expanded` and `aria-controls`, so it opens and closes with Enter or Space.

![Help button](release1-screenshots/ui-22-help-panel-markup-part3.png)

*Figure 38 — `Assistant.tsx`, lines 136–161.*
- **The help button:** has `aria-expanded`, `aria-controls` and a label that names the current tip.
- **The greeting bubble:** shown on the first visit.
- **The new-guidance dot:** shown when the guidance changed while the panel was closed.

---

## 13. Keyboard accessibility of the help system

**Status:** Complete (R1). A focus defect was fixed on 22 Nov. **Jira:** FSEEH-115. **Tests:** E (12 keyboard checks).

![Indicator, focus into the panel, Esc](release1-screenshots/ui-21-help-indicator-focus-esc.png)

*Figure 39 — `Assistant.tsx`, lines 52–78.*
- **Opening:** when the panel opens, focus moves **into** it. The panel comes before the button in the page, so without this, Tab would move away from the help content. Tab now reaches the close button and then the FAQ.
- **Esc:** closes the panel and returns focus to the help button.
- **Unchanged state:** opening and closing never touch the Workspace text, the level or the results, because they live in other components.
- **Focus ring:** the global `:focus-visible` style gives every control a visible focus ring.

---

## 14. First-visit greeting and new-guidance indicator

**Status:** Complete (R1). A timing defect was fixed on 22 Nov. **Jira:** FSEEH-114. **Tests:** E.

![First-visit greeting](release1-screenshots/ui-20-help-first-visit-greeting.png)

*Figure 40 — `Assistant.tsx`, lines 22–50.*
- **Timing:** on a first visit, the greeting appears after 3.2 s and disappears at 11 s (AC6).
- **The fix:** the "seen" flag is written **when the greeting is shown**, not when the page loads. Otherwise a visitor who left within 3.2 s, or React's development double-run, would lose the greeting.

**New-guidance indicator:** Figure 39, first effect. When the page state changes while the panel is closed, a small dot appears on the help button (AC4). Opening the panel clears it.

---

## 15. Session expiration in the interface

**Status:** Complete (R1). Tested only with the Firebase test double. **Jira:** FSEEH-113. **Tests:** U, E.

**How it works in the interface:**
1. **Session mirror:** the session provider re-checks the session on load, when the tab becomes visible, every 5 minutes, and on every protected page.
2. **When an expiry is found:** if a session that existed is gone, the interface becomes Guest, clears private state and shows «انتهت جلستك».
3. **On My Account:** a 401 response also triggers this switch, and the user is sent to the login page.

See `Firebase_Implementation.md` §5, Figures 18–21.

---

## 16. Workspace (demonstration interface)

**Status:** **Demonstration.** The interface is complete; results are labelled samples. Analysis, simplification and comparison become real in **Release 2** (stories 9, 12, 13, 14 and 36). Saving, rating, history and statistics are **Release 2** (stories 15–21).

![Analysis result with the sample label (real website)](release1-screenshots/site-04-workspace-analysis.jpg)

*Figure 41 — the analysis result and target selection; the result carries the «عيّنة» label (recording, 22 Nov 2026).*

![Comparison with the sample label (real website)](release1-screenshots/site-06-workspace-comparison.jpg)

*Figure 42 — the original and simplified comparison. «عيّنة» says it was written by the team for display. Saving shows «حفظ النتائج متاح في الإصدار الثاني» ("saving results is available in Release 2").*

### 16.1 Input validation with no length limit

![Text validation](release1-screenshots/ui-23-workspace-validation-no-limit.png)

*Figure 43 — `frontend/src/shared/validation.ts`, lines 81–97.*
- **Rejected:** empty text, and text where less than 60% of the letters are Arabic.
- **No maximum length:** the 3,000-character limit was removed on 22 Nov 2026.
- **Never truncated:** the text is never cut short.

![Character counter and Clear](release1-screenshots/ui-24-workspace-counter-clear.png)

*Figure 44 — `frontend/src/client/pages/Workspace.tsx`, lines 282–299.*
- **Counter:** shows «N حرف» (N characters), with no maximum.
- **Clear:** «مسح» empties the text and any result without sending a request.

### 16.2 Demonstration results and labels

![Demonstration analysis](release1-screenshots/ui-25-demo-service-analyze.png)

*Figure 45 — `frontend/src/client/services/demo/demoService.ts`, lines 143–157.*
- **No model is called.**
- **Built-in samples:** the level comes from the team's prepared data.
- **Other text:** the level comes from a sentence-length estimate.
- **Not saved:** the result has `id: null` because nothing can be saved in Release 1.

![Sample and simulation labels](release1-screenshots/ui-26-demo-labels.png)

*Figure 46 — `frontend/src/client/components/Results.tsx`, lines 88–105.*
- Every result shows «عيّنة» (prepared sample) or «محاكاة» (simulation), with a sentence saying it is not model output.

### 16.3 Release 2 features kept out of Release 1

![Release 2 routing](release1-screenshots/ui-27-release2-routing.png)

*Figure 47 — `frontend/src/client/lib/api.ts`, lines 19–38.*
- Saving, rating, history and statistics all reject with «تتوفر هذه الميزة في الإصدار الثاني» ("available in Release 2").
- `recordsAvailable = false` hides their controls.

![Rating hidden in Release 1](release1-screenshots/ui-28-rating-hidden-release1.png)

*Figure 48 — `Results.tsx`, lines 259–269.*
- The rating and feedback form (story 21) **returns nothing** while `recordsAvailable` is false, so no rating is collected or stored in Release 1.

---

## 17. Summary of status

| Feature | Status | Jira |
|---|---|---|
| Home page | Complete (R1) | FSEEH-51, 98 |
| About Faseeh | Complete (R1) | FSEEH-99 |
| Registration | Complete (R1) | FSEEH-6, 77–80 |
| Login | Complete (R1) | FSEEH-7, 81–84 |
| Logout | Complete (R1) | FSEEH-12, 89–91 |
| Password recovery | Complete (R1); inbox delivery not verified | FSEEH-26, 85–88 |
| My Account | Complete (R1) | FSEEH-49, 92 |
| Edit Email | Complete (R1); verified on real Firebase 22 Nov | FSEEH-49, 93, 94, 116 |
| Delete Account | Complete (R1); verified on real Firebase 22 Nov; Release 2 data handling pending | FSEEH-50, 95–97 |
| Readability-level descriptions | Complete (R1) | FSEEH-16, 110–112 |
| Nuqta help button and panel | Complete (R1) | FSEEH-52, 100, 101 |
| Keyboard accessibility (help) | Complete (R1), fixed 22 Nov | FSEEH-115 |
| Greeting and new-guidance indicator | Complete (R1), fixed 22 Nov | FSEEH-114 |
| Session expiration | Complete (R1); tested with the test double only | FSEEH-113 |
| Workspace analysis / target / simplify / compare | **Demonstration** (labelled) | Release 2: stories 9, 12, 13, 14, 36 |
| Save, history, statistics, rating, download | **Release 2** (not available) | Stories 15–22 |

## 18. Wording on the site to review (not changed)

These sentences describe how the system is **designed** to work once the models are connected (Release 2). They were left unchanged because the website's content was not to be modified. The team may want to reword them, or keep them as statements of the design:

1. **Home page, the "level promise" card:** «يتحقق فصيح من أن النص المبسّط مكتوب بالمستوى الذي اخترته قبل أن يعرضه عليك» ("Faseeh checks that the simplified text is at the level you chose before showing it"). The Release 1 demonstration does not perform that check.
2. **About page:** the processing steps include «التحقق من المستوى» (level check), and the data card says the classifier "was trained on" labelled texts. This is true of Sprint 1, but that classifier is not what produces the Workspace results yet.
3. **FAQ:** «يقدّرها فصيح بنموذج تعلّم آلي» ("Faseeh estimates it with a machine-learning model"). In Release 1, levels shown in the Workspace come from samples or a heuristic, and are labelled as such.
