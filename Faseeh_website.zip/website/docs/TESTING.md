# Testing — Sprint 2 authentication

Results are grouped by **what was actually tested**. Nothing here was tested against the team's real Firebase project, because it hasn't been configured yet.

## 1. Executed and passed

### 1a. Backend logic — PHPUnit, 31 tests, 86 assertions, all passing

`cd backend && vendor/bin/phpunit --testsuite unit`

These tests run the real PHP router, controller, validation and session-cookie code. **Firebase is replaced by an in-memory test double** (`tests/Support/InMemoryFirebase.php`) that imitates the behaviours the code depends on. They prove the backend's own logic, **not** that Firebase is configured correctly.

| Requirement | Test |
|---|---|
| PBI 1 AC2 | Incomplete fields rejected, no account created |
| PBI 1 AC3 | Invalid email or mismatch identified |
| PBI 1 AC4 | Password policy enforced on the server (each missing character class rejected) |
| PBI 1 AC5 | Duplicate email, including different letter case, rejected; one account remains |
| PBI 1 AC6 | One account + Firestore profile (keyed by UID) + session created |
| PBI 1 AC7 | Profile-write failure → failure message, account and profile rolled back, no session |
| NFR 2 AC2 | The profile contains only `uid`/`email`/`createdAt`, never the password |
| PBI 2 AC2–AC5 | Validation; session on valid credentials; identical general error for a wrong password and an unknown email; no session after a failed attempt |
| PBI 2 AC6 | The protected-request guard returns 401 without a session |
| PBI 3 AC2–AC3 | Logout clears the cookie; a replayed old cookie is rejected; account and profile are kept |
| C2a | An expired session returns to Guest and the cookie is removed |
| PBI 16 AC2–AC8 | Validation; registered vs unregistered email; policy and match on the new password; expired, unknown and used links rejected; new password works, old does not; earlier sessions end |
| Security | Non-JSON or foreign-origin requests refused; cookie is HttpOnly + SameSite=Lax with Max-Age |

**Added 11 Nov 2026 — `tests/Unit/AccountFlowTest.php`, 9 tests.** Suite total now **40 tests, 135 assertions, all passing**.

| Requirement | Test |
|---|---|
| PBI 30/31 access | All account endpoints return 401 without a session |
| PBI 30 AC1 | The profile shows only the signed-in account (email, creation date) |
| PBI 30 AC2–AC4 | Validation; current password required and checked; same email refused; another account's email refused |
| PBI 30 AC5 | Email updated in Auth and in the Firestore profile; session shows the new email; old email can't sign in, new one can |
| PBI 30 AC6 | Profile-write failure → error; account and profile keep the old email |
| PBI 31 AC2–AC3 | Password required; wrong password deletes nothing |
| PBI 31 AC4–AC5, AC7 | Account and profile removed; cookie cleared; old cookie rejected; credentials fail; email can be registered again; other accounts untouched |
| PBI 31 AC6 | Account-deletion failure → error; profile restored unchanged; still signed in |

### 1b. Interface — browser tests, 29 checks, all passing

The real pages run in Chromium at 1366×768. They're served by Vite and talk to the real PHP backend, again **with the Firebase test double** (test-only entry point `backend/tests/Support/ui-test-server.php`).

- Protected page without a session → sign-in (PBI 2 AC6)
- Registration: all field errors; invalid email and mismatch; policy; success shows confirmation and goes to the home page with the account in the header (PBI 1 AC1–AC6); duplicate (AC5)
- Logout control labelled; logout → public page; no account shown; protected page → sign-in; session invalid on the server (PBI 3 AC1–AC4, NFR 2)
- Login: fields and recovery link; validation; **identical** general error for a wrong password and an unknown email; no session after failure; success → home page (PBI 2 AC1–AC5)
- Session expiry → Guest, protected page → sign-in (C2a)
- Recovery: format validation; "no account is associated"; confirmation; policy; mismatch; success → sign-in page with a notice; used link → invalid-link page; old password rejected, new accepted (PBI 16 AC2–AC8, C2b)
- Analysis and simplification stay labelled as demonstrations, and saving is marked Release 2

**Added 11 Nov 2026 — 39 checks in Chrome**, same setup (test double), all passing:
- **Account page (PBI 30–31):** without a session → sign-in; «حسابي» in the account menu; email and member-since shown; validation; wrong current password; another account's email; successful change updates page, header and confirmation; old email no longer signs in, new one does; delete dialog asks for the password; cancel keeps the account; empty or wrong password deletes nothing; deletion → home page, signed out, confirmation; account page and old credentials no longer work; other account unaffected
- **Regression:** sign-up, logout, login, and recovery for a registered and a deleted email
- **Bar below the header removed:** no bar or toggles in the page; content starts directly under the header
- **Logo animation:** writes itself on first load and on two consecutive refreshes; no session storage flag; returning to the home page within the site shows the finished logo
- **Preview arrow:** start and arrowhead are hit-tested as the arrow (not hidden by a card) at 1366×768, 1024×768, 768×1024 and 400×860
- **Password field:** the typed text area starts at least 4px clear of «إظهار» at 1366px and 400px; show/hide still works

### 1c. Compatibility — NFR 4 AC2, account pages only

At **1366×768 and 1024×768**, the login, registration, forgot-password and reset pages have **no horizontal overflow and no clipped controls** (Chromium). The new account page was also checked at 1366×768, 1024×768 and 400×860, with no overflow and no clipped controls.

*Seen but not changed:* between about 641px and 900px wide (e.g. a 768px tablet in portrait), the **header's** navigation doesn't fit and the page scrolls sideways by up to 79px. This predates these changes and is outside the documented 1366×768 / 1024×768 targets.

## 2. Prepared but not run

- `backend/tests/Emulator/FirebaseEmulatorTest.php` runs the **real** Admin SDK gateway and Firestore code end to end (register → profile check in Firestore → duplicate → logout and replay → login errors → recovery with the emailed code → old/new password).
- It needs the Firebase Emulator Suite, which **you haven't approved yet** (DECISIONS.md D9).
- Results from it would be labelled "emulator".

## 3. Requires the real Firebase project (not yet tested)

Do these after FIREBASE_SETUP.md and the root README.md. Tick each one.

1. [ ] Register a new email → confirmation + home page. **Firebase console → Authentication → Users** shows the account.
2. [ ] **Firestore → Data →** your users collection has a document whose ID equals that user's UID, with `email` and `createdAt` only.
3. [ ] Register the same email again → "already registered" message, and still only one user in the console.
4. [ ] Log out → home page; opening `/history` sends you to sign-in.
5. [ ] Log in with a wrong password, then with an unknown email → the same message both times.
6. [ ] Log in correctly → home page, account shown in the header.
7. [ ] Forgot password with an unregistered email → "no account is associated".
8. [ ] Forgot password with your email → an email arrives, and its link opens `localhost:5173/reset-password?...`.
9. [ ] Weak or mismatched new password is rejected; a valid one → sign-in page.
10. [ ] Opening the same email link again → invalid-link page.
11. [ ] Old password fails; new password works.
12. [ ] With `SESSION_TTL_SECONDS=300`, stay idle for more than 5 minutes, then open `/stats` → sign-in, with a "session ended" message.
13. [ ] NFR 2 AC2: in the console, Authentication holds the accounts (Firebase hashes the passwords) and Firestore holds no password fields.
14. [ ] PBI 30: account menu → «حسابي» shows your email and creation date. Change the email (current password required) → the console shows the new email in **both** Authentication → Users and Firestore → your users document. Log out; the old email fails and the new one works.
15. [ ] PBI 31: «حذف الحساب» → cancel keeps everything; a wrong password deletes nothing; the right password → home page, signed out. The user is gone from Authentication → Users **and** the Firestore document is gone. Registering the same email again works.

## 4. Not tested

- **Safari and Edge** (NFR 4 AC1): only Chromium is available in this environment. Please check the account pages in both.
- **"Another user's records"** (NFR 2 AC1): there are no records until Release 2. The guard that will protect them (`AuthController::requireUser`) is tested in §1a.
