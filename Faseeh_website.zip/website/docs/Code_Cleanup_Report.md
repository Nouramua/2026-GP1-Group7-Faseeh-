# Code Cleanup Report — Release 1

**Date:** 22 November 2026.

**Scope:** the Faseeh website, i.e. `frontend/` (React + TypeScript) and `backend/` (PHP + Firebase).

**Rules followed:**
- verify first, then make the smallest safe change;
- no redesign and no new features;
- nothing from Release 2;
- no changes to the AI models, Jira, the backlog, the report, the Firebase project or production data.

---

## 1. How the Ponytail audit was applied

Before applying it, I read Ponytail's official documentation (`README.md`, `INSTALL.md`, `skills/ponytail/SKILL.md`, and `commands/ponytail-audit.toml` and `ponytail-review.toml`, from github.com/DietrichGebert/ponytail).

**Installation: not installed, by choice.** The only official Claude Code installation is two interactive slash commands that you type yourself:

```
/plugin marketplace add DietrichGebert/ponytail
/plugin install ponytail@ponytail
```

They can't be run on your behalf. The plugin also installs Node lifecycle hooks and writes outside the project: `~/.claude/.ponytail-active`, `%APPDATA%\ponytail\config.json`, and a status-line script plus a `settings.json` entry. That is software installed on your computer outside the project, and your rules require your approval for that, so it was not installed.

**What was done instead.** The documented `/ponytail-audit` procedure (whole repository) and `/ponytail-review` procedure (the diff) were applied by hand, step by step:
1. Map the repository: README, build configuration, dependencies, entry points, tests.
2. Trace the main flows, and fully read every path that touches user input, authentication or data writes.
3. Look for problems in this order: bugs, risk, scale, risky logic without tests, slow code, then "lean" items (dead code, duplicates, unnecessary abstraction).
4. Grep the whole tree before calling any code unused.
5. Report the findings as Must fix / Should fix / Nice to have.

**To run the real plugin yourself later**, type the two commands above in an interactive Claude Code session, then `/ponytail-audit` and `/ponytail-review`.

### 1a. Second pass (22 Nov 2026, evening): Ponytail still not available

**What was attempted.** The two `/plugin` commands were entered in the VS Code Claude Code panel. The panel answered **"/plugin isn't available in this environment."**

**Verification before any review.** No reinstall was attempted.

| Check | Result |
|---|---|
| `~/.claude/plugins/` | Only the plugin-directory cache and one built-in entry; no Ponytail plugin |
| `~/.claude/.ponytail-active` | Does not exist |
| `%APPDATA%\ponytail\` | Does not exist |
| Ponytail skills or commands (`/ponytail-audit`, `/ponytail-review`) | Not available in the session |

**Result: Ponytail was not installed and was not executed.** No Ponytail output exists, and none is reported as if it did.

**How to run it for real.**
1. Open Claude Code in a **terminal** (the `claude` CLI), where `/plugin` is supported.
2. Run the two install commands.
3. Start a new session in this folder.
4. Run `/ponytail-audit`, then `/ponytail-review`.

**What was done instead (manual review of the earlier cleanup).** The diff-review procedure was applied again by hand to the changes made earlier the same day, looking for regressions or code removed by mistake:

| Check | Result |
|---|---|
| Removed `demoService` code (save, rate, history, stats, flags, demo store) | No remaining references (`tsc --noEmit` passes). The Workspace's error screens for `level_not_met` and `simplifier_unavailable` are still present for Release 2. |
| Release 2 placeholders | `History.tsx`, `Stats.tsx`, `ReleaseTwoPage`, `RatingForm` and `SaveButton` are all still present, and none was removed |
| Security and validation | `AuthValidator`, `requireUser`, `guardCrossSite`, the cookie flags, `firestore.rules` and the rollbacks are unchanged since the first pass. All 40 unit tests pass. |
| Accessibility | The help-panel focus fix and `aria-controls` are present; the 12 keyboard checks pass |
| Comments | Still accurate after the first pass, and no comment refers to removed code |

- **Findings:** none.
- **Website code changed in the second pass:** none.

**Verification after the second pass (22 Nov 2026, evening):**

| Check | Result |
|---|---|
| `npm run build` | Pass |
| PHPUnit | 40 tests, 135 assertions: OK |
| Browser suite | 105/105 |

---

## 2. Files reviewed

| Area | Files |
|---|---|
| Backend (all) | `public/index.php`; `src/App.php`, `Config.php`; `Controllers/AuthController.php`, `AccountController.php`; `Firebase/AuthGateway.php`, `KreaitAuthGateway.php`, `ProfileStore.php`, `FirestoreRestProfileStore.php`, `Exceptions.php`; `Http/Request.php`, `Response.php`, `ApiException.php`; `Session/SessionCookie.php`; `Validation/AuthValidator.php`; `tests/**`; `composer.json`; `firestore.rules` |
| Frontend | `main.tsx`, `App.tsx`; `pages/*` (Home, About, Workspace, Auth, Profile, History, Stats); `components/*` (Layout, Assistant, Levels, Results, ui); `lib/*` (api, session, assistant, toast, format, motion); `services/*` (http, types, errors, demo/demoService, demo/samples); `shared/*` (api, levels, validation); `styles/*`; `package.json`, `vite.config.ts` |

---

## 3. Audit findings (Ponytail format)

**What this repo does:** the Faseeh Release 1 website. It is a React single-page app that talks only to a PHP backend, which uses Firebase Authentication (Admin SDK) and Cloud Firestore (REST) for accounts. The Workspace (analysis and simplification) is a labelled browser-side demonstration until Release 2.

**Assumed load:** a graduation-project deployment with tens of users. It runs one PHP process per request and keeps no background jobs.

### Must fix

**1. `frontend/src/client/components/Assistant.tsx`: keyboard focus did not enter the help panel (FSEEH-115)**
- **What this is:** the help panel is rendered *before* the help button in the DOM.
- **Problem:** after opening the panel with Enter or Space, Tab moved forward, away from the panel. Keyboard users could reach the FAQ only with Shift+Tab, which breaks the "logical focus order" requirement.
- **Fix (done):** focus the panel when it opens (`tabIndex={-1}`, so it doesn't add a Tab stop) and add `aria-controls`. Esc and the close button still return focus to the button. One CSS rule hides the focus ring on the non-interactive panel container, so the look is unchanged.
- **If we skip it:** FSEEH-115 stays only partly met.

**2. `frontend/src/client/components/Assistant.tsx`: the first-visit greeting could be lost (FSEEH-114)**
- **What this is:** the "seen" flag was written to `localStorage` when the component mounted, 3.2 s *before* the greeting appeared.
- **Problem:**
  - a visitor who left or reloaded within 3.2 s was marked as greeted but never saw the greeting;
  - in development, React StrictMode runs effects twice, so the greeting never appeared at all.
- **Fix (done):** write the flag only when the greeting is actually shown.
- **If we skip it:** AC6 fails for real visitors in the cases above.

**3. `frontend/src/client/pages/Profile.tsx`: an expired session left the interface signed in (FSEEH-113)**
- **What this is:** account requests answered 401 when the session expired while My Account was open.
- **Problem:** the page showed only the error text. The header stayed "signed in" until the next 5-minute background check, contradicting Log Out AC5 ("the interface returns to the guest state").
- **Fix (done):** `handleLostSession()` routes any 401 through the existing `refreshSession()`, which sets Guest and the "session ended" message, and redirects to `/login`. A wrong *current password* is a 400, so it is never mistaken for a lost session.
- **If we skip it:** the interface shows stale signed-in state, and account forms keep failing with no clear way forward.

**4. Input length limit (removed requirement)**
- **Files:** `shared/validation.ts`, `shared/api.ts`, `services/demo/demoService.ts`, `pages/Workspace.tsx`, `pages/Home.tsx`, `lib/assistant.tsx`, `styles/pages.css`.
- **What this is:** a 3,000-character limit enforced in validation, shown in the counter, and stated on the Home page and in a help tip.
- **Problem:** the limit is no longer an approved requirement.
- **Fix (done):** removed it in every layer, with no replacement limit. The counter, Clear button and empty / not-Arabic validation are kept, and nothing is truncated. Details: `Release1_Implementation_Audit.md` §6.

### Should fix

**5. `frontend/src/client/services/demo/demoService.ts` (was 383 lines, now 186): dead code**
- **What this is:** a full browser-storage "fake backend" from the early design demo: demo accounts, session, reset token, saved results, ratings, events, and `save/rate/history/historyItem/deleteHistory/stats`. Also four `demoFlags` toggles, `setDemoFlag`, `onDemoFlags` and `resetDemoData`.
- **Problem:** none of it is reachable in Release 1. I grepped the whole tree:
  - `lib/api.ts` routes save, rate, history and stats to a "Release 2" rejection;
  - the demo session is never set (accounts are real), so every result had `id: null`;
  - `setDemoFlag`, `onDemoFlags` and `resetDemoData` have no callers, so every flag was always `false`.
- **Fix (done):** kept `config`, `analyze` and `simplify` with identical behaviour and labels; removed the rest (−197 lines). The service type is now `Pick<FeatureService, "config" | "analyze" | "simplify">`, so the compiler confirms nothing else used it.
- **Why it is safe:**
  - typecheck and build pass;
  - the browser suite exercises analysis, simplification, the demonstration labels and the "Release 2" save note;
  - the Workspace's error screens (`level_not_met`, `simplifier_unavailable`) were **kept**, because they handle real error codes the Release 2 service will return.

**6. `backend/src/Firebase/FirestoreRestProfileStore.php`: one OAuth token fetch per Firestore call**
- **What this is:** `accessToken()` signed a JWT and fetched a new Google access token for every REST call.
- **Problem:** Delete Account makes two Firestore calls (read, then delete), and a failed deletion makes a third (restore). That is extra latency and extra Google token requests.
- **Fix (done):** reuse the token for the rest of the PHP request (a private `?string $token`). A PHP request lasts well under a token's one-hour lifetime.
- **If we skip it:** slower account operations; still correct.

**7. `backend/src/Firebase/KreaitAuthGateway.php`: redundant rethrow**
- **What this is:** `updatePassword()` ended with `catch (Throwable $e) { throw $e; }`, which does nothing.
- **Fix (done):** removed it, along with the now-unused `use Throwable`.

**8. Comments that cite outdated requirement numbers**
- **What this is:** backend and frontend comments cited the *old* backlog numbering ("PBI 16", "items 30/31") and old report page numbers.
- **Fix (done):** they now cite the final backlog story numbers and Jira keys. See §6.

### Nice to have (not changed; reported for the team)

**9. `frontend/src/client/pages/History.tsx` (245 lines) and `Stats.tsx` (143 lines): unreachable Release 2 page prototypes**
- **What this is:** these files are not imported anywhere. `/history` and `/stats` render the `ReleaseTwoPage` notice in `App.tsx`. Vite doesn't bundle them; `tsc` still type-checks them.
- **Why kept:** they hold the designed Release 2 interface (history list, open and delete, statistics). Deleting them would throw away design work the team will need in Sprint 4. This is a team decision, not a cleanup.
- **If we skip it:** about 390 lines of unused code stay in the repository.

**10. `AuthController::failure()` and `AccountController::failure()`: identical 4-line helpers**
- **Why kept:** merging them would add a shared class or trait for 4 lines, which is more abstraction than duplication.

**11. npm advisories (`npm audit`: 3 moderate, 1 high)**

| Package | Advisory | Affects | Fix |
|---|---|---|---|
| vite 5.4 / esbuild 0.21 | Dev-server issues (path traversal, `server.fs` bypass, launch-editor on Windows, cross-origin requests to the dev server) | **Local development only.** The production build is static files served by PHP. | vite 8: a major upgrade |
| react-router-dom 6.30 | Open redirect via backslash in `<Link>` / `useNavigate`; SSR hydration | Faseeh navigates only to fixed internal paths and doesn't use SSR | react-router 7: a major upgrade |

**Why not upgraded:** both fixes are major-version upgrades, which conflicts with "no large refactoring". Plan them for Release 2. Until then, don't expose the Vite dev server to a network. `composer audit` found no advisories.

**12. `Request::fromGlobals()` reads the whole request body**
- PHP's `post_max_size` bounds it. This was acceptable for Release 1, where the bodies are small account forms.
- When Release 2 adds text endpoints, decide an explicit size policy (`Release1_Implementation_Audit.md` §6).

**Verdict:** the Release 1 code is sound. There are three real interface defects and one removed requirement (all fixed), plus a large block of dead demonstration code (removed). The security design (backend-only Firebase, verified and revocable session cookies, deny-all Firestore rules, re-authentication, rollbacks) needed no change.

**Lean:** −197 lines in `demoService.ts`, −20 CSS lines, −4 lines of redundant PHP. About −390 more lines are possible if the team retires `History.tsx` and `Stats.tsx`. No dependency can be removed: all six runtime and six dev dependencies are used.

**Not checked:**
- the real plugin, because it was not installed;
- Safari and Edge;
- real Firebase for Edit Profile, Delete Account and session expiry;
- reset-email delivery to an inbox.

---

## 4. Diff review of the changes (Ponytail `/ponytail-review` lens)

**What this change does:** removes the input limit, fixes three help and session defects, deletes unreachable demonstration code, makes small backend efficiency and cleanliness changes, and adds comments.

- **Callers checked:**
  - `validateArabicText` had two callers (Workspace and demoService); both were updated.
  - `AppConfig.maxInputChars` had two readers; both were removed.
  - `demoService` methods: `lib/api.ts` uses only `config`, `analyze` and `simplify`.
  - `handleLostSession` is used in all three `Profile` request paths.
- **Tests:** the existing PHPUnit suite still passes, and the browser suite covers every changed behaviour.
- **Looks good.** No new dependency, no new feature, no visual redesign. The only visual change is the counter, which lost its limit bar.

---

## 5. Files changed

### Behaviour changes

| File | Change | Why it is safe |
|---|---|---|
| `frontend/src/shared/validation.ts` | Limit removed; full JSDoc | Only 2 callers, both updated; E checks |
| `frontend/src/shared/api.ts` | `AppConfig.maxInputChars` removed | Compiler confirms no readers |
| `frontend/src/client/pages/Workspace.tsx` | Counter without limit; error shown after interaction; comments | E: counter, Clear, validation, long text |
| `frontend/src/client/styles/pages.css` | Limit-bar CSS removed | Classes no longer used (grep) |
| `frontend/src/client/pages/Home.tsx` | "حتى ٣٬٠٠٠ حرف" removed | Text only |
| `frontend/src/client/lib/assistant.tsx` | Help tip: limit wording removed | Text only |
| `frontend/src/client/services/demo/demoService.ts` | Dead code removed; comments | §3 item 5 |
| `frontend/src/client/components/Assistant.tsx` | Focus into the panel; `aria-controls`; greeting flag timing; comments | E: 12 help checks, greeting check |
| `frontend/src/client/styles/components.css` | `.assistant__panel:focus { outline: none }` | Keeps the look identical |
| `frontend/src/client/pages/Profile.tsx` | `handleLostSession` for 401; header comment | E: expiry while open; all profile and delete checks |
| `backend/src/Firebase/FirestoreRestProfileStore.php` | Token reuse per request; comments | Same token, same calls |
| `backend/src/Firebase/KreaitAuthGateway.php` | Redundant catch removed; comments | Identical behaviour |

### Comments only (no executable change)

**Backend:**
- `src/App.php`, `Config.php`
- `Controllers/AuthController.php`, `AccountController.php`
- `Firebase/AuthGateway.php`, `ProfileStore.php`, `Exceptions.php`
- `Http/Request.php`, `Response.php`, `ApiException.php`
- `Session/SessionCookie.php`
- `Validation/AuthValidator.php`

**Frontend:**
- `App.tsx`
- `lib/api.ts`, `lib/session.tsx`
- `services/http.ts`, `services/types.ts`
- `pages/Auth.tsx`
- `components/Results.tsx`: one comment

### New files

**Tests:**
- `backend/tests/Browser/release1.e2e.cjs`
- `backend/tests/Browser/test-double-control.php`
- `backend/tests/Browser/README.md`

**Documentation:**
- `docs/Firebase_Implementation.md`
- `docs/firebase-screenshots/*.png` (replaced in the second pass by 43 `fb-*.png` images)
- `docs/Release1_Implementation_Audit.md`
- `docs/Code_Cleanup_Report.md`
- `docs/Release1_Final_Verification.md`

**Site map:**
- `docs/sitemap/sitemap_release1.html`, `.png`, `.pdf`
- `docs/sitemap/render.cjs`

---

## 6. Comment pass

**Backend:**
- Every class, public method and non-obvious branch has PHPDoc or inline comments explaining what it does and why.
- Topics covered:
  - Firebase Admin SDK calls;
  - session-cookie creation, verification, revocation and expiry;
  - the cookie flags;
  - Firestore REST payloads and query parameters;
  - each validation rule;
  - every rollback;
  - the 400-vs-401 distinction for passwords;
  - why the login error is general;
  - what is deliberately left for Release 2.

**Frontend:**
- **Fully commented:** the session provider, the HTTP client, the service routing, the route guard, the auth pages' request logic, the help component's effects, and the validation and demonstration services.
- **Not commented line by line:** presentational JSX (markup and CSS classes), where a comment on each line would only repeat the markup.
- **Release 2 prototypes:** `History.tsx` and `Stats.tsx` still carry their old references, because they are unreachable (§3 item 9).

**Accuracy:** each comment was written against the code next to it. No secrets, tokens or personal data appear in any comment.

---

## 7. Bugs and security issues fixed

| # | Type | Issue |
|---|---|---|
| 1 | Accessibility | Help panel focus order (FSEEH-115) |
| 2 | Bug | First-visit greeting could be lost (FSEEH-114) |
| 3 | Session state | Expired session left the interface signed in on My Account (FSEEH-113) |

No security vulnerability was found in Faseeh's own code.

---

## 8. Tests performed

| Check | Result |
|---|---|
| `npm run build` (`tsc --noEmit` + Vite production build) | Pass |
| `php -l` on every backend file | No syntax errors |
| PHPUnit unit suite | 40 tests, 135 assertions: **OK** |
| Browser suite (105 checks; test double) | **105/105** |
| Level-description probe | 5/5 |
| No horizontal overflow at 1366×768 and 1024×768 (6 public pages) | Pass |
| `npm audit` / `composer audit` | See §3 item 11 / none |

---

## 9. Remaining risks

1. **Real Firebase not yet run:**
   - Edit Profile and Delete Account have only been tested against the test double;
   - session expiry has not been tested with a real short `SESSION_TTL_SECONDS`;
   - reset-email delivery has not been confirmed from an inbox.

   `docs/TESTING.md` §3 has the checklist.
2. **Browsers:** Safari and Edge were not tested.
3. **Dev-tool advisories:** they remain until Vite and react-router get major upgrades.
4. **Documents to update (yours to change):** backlog story 8 AC5, story 38 AC2 and the report's C3 text still mention a length limit.
