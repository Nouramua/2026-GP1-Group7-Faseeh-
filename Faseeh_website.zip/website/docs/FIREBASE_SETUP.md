# Setting up Firebase for Faseeh — step by step

You only do this once. It takes about 15 minutes. Everything happens in the Firebase website (the "console"), plus one file you keep on your own computer.

> **Why this is needed.** Our architecture (report Figure 9, p. 41) uses **Firebase Authentication** for accounts and sessions and **Cloud Firestore** for user profiles. The PHP backend talks to both using a *service account*, a private key file that proves the backend is allowed to manage your project. The website itself never talks to Firebase directly.

---

## Step 1 — Create the Firebase project

1. Open https://console.firebase.google.com and sign in with the Google account the team will use.
2. Click **Create a project** (or **Add project**).
3. Name it, for example `faseeh`. Firebase shows the **project ID** under the name (e.g. `faseeh-1a2b3`). Write it down; you'll need it in step 6.
4. Google Analytics isn't needed for Sprint 2, so you can turn it off. Click **Create project**.

## Step 2 — Turn on email and password sign-in

*Why:* PBI 1 and PBI 2 use email and password only.

1. In the left menu: **Build → Authentication → Get started**.
2. Open the **Sign-in method** tab, click **Email/Password**, switch on the **first** toggle (Email/Password), and click **Save**.
3. Leave "Email link (passwordless sign-in)" **off**. It isn't in our requirements.

> The password rule (8+ characters with uppercase, lowercase, a digit and a special character) is enforced by Faseeh's PHP backend on every registration and password reset, so it works whatever your Firebase plan.

## Step 3 — Make the reset email open Faseeh's own page

*Why:* C2b and PBI 16 AC5 require the new password to meet our policy. Firebase's default reset page doesn't check our policy, so the email link must open Faseeh's reset page instead.

1. **Authentication → Templates** tab → **Password reset** → click the pencil (edit) icon.
2. Click **Customize action URL** and enter `http://localhost:5173/reset-password`. Later, when the site is deployed, change it to the real address, e.g. `https://your-domain/reset-password`.
3. Click **Save**.
4. Optional: in the same screen you can switch the template language to Arabic.

## Step 4 — Create the Cloud Firestore database

*Why:* C2b creates the user's profile in Cloud Firestore when they register.

1. **Build → Firestore Database → Create database**.
2. Choose **Standard edition** if asked.
3. **Location:** the report doesn't specify one. **It can't be changed later.** Pick the location closest to your users (for Saudi Arabia, a Middle East location if one is offered).
4. Choose **Start in production mode**, which blocks all access until rules allow it, and click **Create**.
5. Open the **Rules** tab and replace everything with the contents of `firestore.rules` from this project (it blocks all direct browser access; only the PHP backend writes). Click **Publish**.

## Step 5 — Download the service-account key (keep it secret)

*Why:* the PHP backend uses it to create accounts, verify sessions and write profiles.

1. Click the **gear icon → Project settings → Service accounts** tab.
2. Make sure **Firebase Admin SDK** is selected and click **Generate new private key → Generate key**. A `.json` file downloads.
3. Move that file to a folder **outside** the Faseeh project, for example:
   - Windows: `C:\Users\<you>\secrets\faseeh-service-account.json`
   - macOS: `/Users/<you>/secrets/faseeh-service-account.json`
4. **Never** upload it to GitHub, email it, or paste its contents into a chat (including with Claude). If it is ever exposed, delete the key on the same page and generate a new one.

## Step 6 — Fill in the backend settings

1. In `backend/`, copy `.env.example` to a new file called `.env`.
2. Fill in:
   - `FIREBASE_PROJECT_ID` = the project ID from step 1
   - `FIREBASE_CREDENTIALS` = the **full path** to the key file from step 5
   - `FIRESTORE_USERS_COLLECTION` = your decision D1 (proposed: `users`)
   - `SESSION_TTL_SECONDS` = your decision D2 (e.g. `86400` for one day)
   - leave `FIRESTORE_DATABASE_ID=(default)` unless you created a database with a different name
3. `.env` is already in `.gitignore`, so it won't be uploaded.

## Step 7 — Check it works

Follow the root README.md (§4.6 and §5), then the manual checks in TESTING.md §3. If something fails, share the error message only (never the key).

---

### What you do **not** need

- **No Firebase web settings** (apiKey and so on) in the website. The browser only talks to our PHP backend, as in Figure 9.
- **No Firebase Hosting, Functions or Storage** for Sprint 2.
- **Authorized domains:** `localhost` is already allowed. Add the real domain later when deploying (Authentication → Settings → Authorized domains).
