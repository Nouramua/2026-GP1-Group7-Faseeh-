# Product Backlog updates

Changes to **Table 7, Functional product backlog** (§4.2.4, pp. 24–39) of *Text_Simplification_Document (2).pdf*. The report is only available as a PDF, so the exact text to paste into the report's source (and into Jira, which §4.2.4 says stays consistent with the backlog) is below. Columns follow Table 7: **# · PBI (User Story) · Size · Type · Status · Acceptance Criteria**.

Nothing else in the report needs to change for these items; related report text that you may want to clarify is listed at the end.

---

## A. New items: account management from the Use Case Diagram

*Why:* Figure 8 (p. 24) shows **Edit Profile** and **Delete Account**, both extending **View Profile**, but Table 7 had no stories for them. They are numbered after the last item (29), following the table's numbering. Viewing the profile is covered by PBI 30 AC1, so View Profile doesn't need a separate story.

| # | PBI (User Story) | Size (Story Points) | Type | Status | Acceptance Criteria |
|---|---|---|---|---|---|
| 30 | **Edit Profile**<br>As a logged-in user, I want to view and edit my profile so that my account details stay correct. | 3 points | Feature | In progress | **1.** A logged-in user can open a profile page from the account menu that displays the account's email address and creation date; opening it without a valid session directs the user to login.<br>**2.** Submitting the edit form with a missing or incorrectly formatted email, or without the current password, displays validation messages and changes nothing.<br>**3.** Changing the email requires the current password; an incorrect password displays an error and changes nothing.<br>**4.** An email already associated with another account cannot be used, and the relevant error is identified.<br>**5.** A valid change updates the email in Firebase Authentication and in the user profile in Cloud Firestore, displays confirmation, and the user then signs in with the new email; the old email no longer signs in.<br>**6.** If the change fails, the system displays a failure message without reporting success, and the account and profile keep the previous email. |
| 31 | **Delete Account**<br>As a logged-in user, I want to delete my account so that my personal information is no longer kept by Faseeh. | 3 points | Feature | In progress | **1.** The profile page provides a clearly labeled delete-account option.<br>**2.** Selecting it requests confirmation and the current password before anything is removed.<br>**3.** Cancelling, or entering an incorrect password, leaves the account unchanged.<br>**4.** Confirmed deletion removes the account from Firebase Authentication, the user profile from Cloud Firestore, and the user's saved records and ratings.<br>**5.** After deletion the session ends, the user is returned to a public page with a confirmation, protected pages and the old credentials no longer give access, and the email can be registered again.<br>**6.** If deletion fails, the system displays an error without reporting successful deletion, and nothing is removed.<br>**7.** Deleting one account does not affect other accounts or their records. |

*Status* is "In progress": both are implemented and tested with a Firebase test double, but not yet against the team's real Firebase project (docs/TESTING.md). Change it to "Done" after the checks in TESTING.md §3. Saved records and ratings (PBI 31 AC4) don't exist until Release 2; their removal joins the delete operation when they are built.

---

## B. Corrected items: the output level

**Intended behaviour, from the report.** The user explicitly selects the target level (§1.2.1 "Multi-Level Arabic Text Simplification": "The target readability level is explicitly selected by the user"). The simplification service uses the model for that level (Fig. 9; Process 4.0), and the classifier evaluates the simplified text (§1.4 p. 5; Process 5.0; Fig. 9 step 5).

**Correction.** That second classification is a **check that the output matches the selected target**. It is not a second level shown to the user, so a result at a different level is never presented as a successful simplification. Each item below keeps its other criteria unchanged.

| # | Criterion | Current text (report) | Corrected text |
|---|---|---|---|
| 6 Understand Readability Levels (p. 28) | AC3 | "Level labels and their ordering are consistent across input analysis, target selection, and output analysis." | "Level labels and their ordering are consistent across input analysis, target selection, and the simplification result." |
| 8 Simplify Arabic Text (p. 29) | new AC7 | — | "**7.** Before the generated text is displayed, the readability classifier verifies that it matches the selected target level; text that does not match is not presented as a successful simplification, and the user is informed and can retry or choose another target level." |
| 10 Save Results (p. 30) | AC3 | "A simplification record additionally includes the generated text and selected target the predicted output level is stored when available." | "A simplification record additionally includes the generated text and the selected target level." |
| 12 Open a Saved Result (p. 31) | AC3 | "Simplification records also display the generated text, selected target, and recorded output level when available." | "Simplification records also display the generated text and the selected target level." |

PBI 8 AC4 ("displays non-empty generated Arabic text with its selected target level") and AC6, PBI 9, and PBI 29 already match this behaviour and stay as they are.

---

## Related report text (not backlog) — suggested clarification only

These sections describe the same classify-the-output step. They don't contradict the corrected backlog if read as a verification step, but a one-line clarification would make that explicit. **Not changed:**

- §4.3.1 Figure 9 caption, "(5) the classifier predicts the output level", and "Readability classifier: Input and output levels" (p. 41)
- Table 9, Process 5.0 *Classify Simplified Readability* and 6.0 "…original and simplified texts with their readability levels" (p. 44)
- Table 10, D2 "…input level, target level and output level" (p. 44)
- Figure 10 / §4.3.2 Level 0: "original + simplified text + readability levels" (p. 42)

Figure 8 also shows **Delete History** (extending View History), which still has no backlog item. See docs/DECISIONS.md D11.
