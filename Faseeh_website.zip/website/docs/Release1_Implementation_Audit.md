# Release 1 Implementation Audit

**Date:** 22 November 2026.

**Sources compared:**
1. `Jira.pdf`: 65 Done items exported on 22 Nov 2026 (9 stories, 56 subtasks).
2. `Faseeh_Final_Product_Backlog.md`: the final backlog, 21 Nov 2026.
3. *Text_Simplification_Document (4).pdf*: the latest report.
4. The six separately provided architecture images: System Architecture, C1 classification flowchart, C2a state diagram, C3 activity diagram, DFD Level 0 and DFD Level 1.
5. The current source code in this workspace.

**Statuses used:**

| Status | Meaning |
|---|---|
| **Verified** | Implemented and verified |
| **Corrected** | Implemented, but a defect was found and fixed in this audit |
| **Partial** | Partially implemented |
| **Missing** | Not implemented |
| **N/A** | Not part of the deployed Release 1 website scope |
| **Unable** | Unable to verify in this workspace |

**Test evidence:**

| Abbreviation | Meaning |
|---|---|
| **U** | PHPUnit unit suite, 40 tests, all passing (Firebase test double) |
| **E** | Browser suite `backend/tests/Browser/release1.e2e.cjs`, 105/105 passing (real PHP backend + Firebase test double) |
| **L** | Level-description probe, 5/5 passing |
| **R** | Run against the **real Firebase project** while recording the Release 1 demo (15–16 Nov 2026) |

---

## 1. Release 1 scope

Release 1 stories (final backlog, traceability table):

| Sprint | Stories |
|---|---|
| Sprint 0 | 23 Understand BAREC Readability Levels (FSEEH-43); 24 Select a Readability Classification Approach (FSEEH-44) |
| Sprint 1 | 26 Prepare the BAREC Dataset (FSEEH-45); 27–28 train classifiers (FSEEH-46, 47); 29 compare and select (FSEEH-48) |
| Sprint 2 (website) | 1 Create an Account (FSEEH-6); 2 Log In (FSEEH-7); 3 Recover a Forgotten Password (FSEEH-26); 4 Log Out (FSEEH-12); 5 Edit Profile (FSEEH-49); 6 Delete Account (FSEEH-50); 7 Learn About Faseeh (FSEEH-51); 10 Understand Readability Levels (FSEEH-16); 11 Get Contextual Help (FSEEH-52) |

**Release 2 items with an interface already present in Release 1:**
- **Stories 8, 9, 12, 13, 14 (Submit, Analyze, Select Target, Simplify, Compare):** the Workspace interface exists, but its results are demonstrations labelled «عيّنة» / «محاكاة».
- **Stories 15–22 (saving, history, statistics, rating, download):** shown only as "available in Release 2".

These were checked so that they are not misrepresented. They are not counted as Release 1 deliverables.

---

## 2. Implementation matrix: Sprint 2 (website)

### FSEEH-6: Create an Account (backlog 1)

| Jira key | Subtask | Acceptance criterion / requirement | Status | Evidence (file · function) | Test | Action |
|---|---|---|---|---|---|---|
| FSEEH-77 | Registration page with live password checklist | AC1 email, password and confirmation fields; live policy checklist | Verified | `pages/Auth.tsx` · `Register`; `components/ui.tsx` · `PasswordRules` | E, R | None |
| FSEEH-78 | Server-side email and password validation | AC2 incomplete fields; AC3 invalid email or mismatch; AC4 policy (8+, upper, lower, digit, special) | Verified | `Validation/AuthValidator.php` · `email/password/confirm`; `AuthController::register` | U, E | None |
| FSEEH-79 | Create the Firebase account and Firestore profile | AC5 no duplicate (409, case-insensitive); AC6 one account + profile `{uid}` with `email`, `createdAt` | Verified | `KreaitAuthGateway::createAccount`; `FirestoreRestProfileStore::createProfile` | U, E, R | None |
| FSEEH-80 | Registration error and confirmation messages | AC6 confirmation + home page; AC7 failure message, account rolled back | Verified | `AuthController::register` (rollback); `Register` toast + navigate | U (profile-failure rollback), E, R | None |

### FSEEH-7: Log In (backlog 2)

| Jira key | Subtask | Acceptance criterion / requirement | Status | Evidence | Test | Action |
|---|---|---|---|---|---|---|
| FSEEH-81 | Login page | AC1 fields + recovery link; AC2 missing credentials → validation | Verified | `pages/Auth.tsx` · `Login` | E, R | None |
| FSEEH-82 | Session creation with Firebase session cookie | AC3 valid → session + home page; cookie HttpOnly, SameSite=Lax, Max-Age, Secure in production | Verified | `KreaitAuthGateway::startSession` (`createSessionCookie`); `SessionCookie::build` | U, E (flags checked), R | None |
| FSEEH-83 | General invalid-credentials message | AC4 same message for a wrong password and an unknown email; AC5 no access after failure | Verified | `KreaitAuthGateway::signIn` (one `InvalidCredentials`); `AuthController::login` | U, E, R | None |
| FSEEH-84 | Redirect protected pages to login | AC6 protected page without a valid session → login; backend 401 | Verified | `App.tsx` · `RequireAuth`; `AuthController::requireUser` | U, E | None |

### FSEEH-26: Recover a Forgotten Password (backlog 3)

| Jira key | Subtask | Acceptance criterion / requirement | Status | Evidence | Test | Action |
|---|---|---|---|---|---|---|
| FSEEH-85 | Forgot-password page | AC1 option on login; AC2 empty or invalid email → validation | Verified | `pages/Auth.tsx` · `ForgotPassword` | E, R | None |
| FSEEH-86 | Send the Firebase reset email | AC3 registered → link + confirmation; AC4 unregistered → "no account is associated", no email | Verified (logic). Email delivery unconfirmed. | `AuthController::requestPasswordReset`; `KreaitAuthGateway::sendPasswordResetEmail` | U, E (test double records sent emails), R (request accepted by Firebase) | Confirm one real reset email reaches an inbox (`TESTING.md` §3 item 8) |
| FSEEH-87 | Reset page with password policy | AC5 policy; AC6 mismatch rejected; AC8 new password works, old does not | Verified | `ResetPassword`; `AuthController::confirmPasswordReset`; `KreaitAuthGateway::updatePassword` | U, E, R | None |
| FSEEH-88 | Expired and used reset links | AC7 invalid, expired or used link cannot change the password; AC8 link not reusable | Verified | `AuthController::verifyPasswordReset`; `KreaitAuthGateway::verifyPasswordResetLink` | U, E | None |

### FSEEH-12: Log Out (backlog 4)

| Jira key | Subtask | Acceptance criterion / requirement | Status | Evidence | Test | Action |
|---|---|---|---|---|---|---|
| FSEEH-89 | Logout control in the account menu | AC1 clearly labelled control | Verified | `components/Layout.tsx` · account menu «تسجيل الخروج» | E, R | None |
| FSEEH-90 | Revoke the session and delete the cookie | AC2 session invalidated; replayed cookie rejected | Verified | `AuthController::logout` → `endSessions` (`revokeRefreshTokens`); `SessionCookie::clear` | U, E | None (revokes all devices: decision D3) |
| FSEEH-91 | Return to the guest state on a public page | AC2 public page; AC3 account kept; AC4 nothing private shown | Verified | `lib/session.tsx` · `logout`, `clearPrivateUiState` | U, E, R | None |
| FSEEH-113 | Expired sessions → guest; protected pages require login | AC5 | **Corrected** | `AuthController::session` (`expired: true`); `SessionProvider`; `Layout` · `SessionExpiryNotice`; **`Profile.tsx` · `handleLostSession` (new)** | U, E (5 expiry checks) | Defect fixed: expiry while My Account was open left the header signed in. Real-Firebase expiry not yet run. |

### FSEEH-49: Edit Profile (backlog 5)

| Jira key | Subtask | Acceptance criterion / requirement | Status | Evidence | Test | Action |
|---|---|---|---|---|---|---|
| FSEEH-92 | My Account page with email and creation date | AC1 from the account menu; AC2 without a session → login; AC3 only the email is editable | Verified | `pages/Profile.tsx`; `AccountController::show` | U, E | None |
| FSEEH-93 | Change-email form with current-password check | AC4 empty, invalid or unchanged email, or missing password → field errors; AC5 wrong password → error under the password field | Verified | `Profile` · `submitEmail`; `AccountController::changeEmail`, `confirmPassword` | U, E | None |
| FSEEH-94 | Update email in Authentication and the Firestore profile | AC7 updated in both, on the page and in the header; AC8 new email signs in, old does not | Verified (test double + real Firebase) | `KreaitAuthGateway::changeEmail`; `FirestoreRestProfileStore::updateEmail` | U, E | **Done 22 Nov:** verified on real Firebase in the final demo recording (change, then login with the new email) |
| FSEEH-116 | Error handling for a duplicate email and a failed update | AC6 another account's email → error under the email field; AC9 failure → error, previous email kept in both | Verified | `AccountController::changeEmail` (409; rollback) | U, E (simulated Firestore failure) | None |

### FSEEH-50: Delete Account (backlog 6)

| Jira key | Subtask | Acceptance criterion / requirement | Status | Evidence | Test | Action |
|---|---|---|---|---|---|---|
| FSEEH-95 | Delete-account confirmation dialog with password | AC1 labelled control; AC2 dialog requires the password; AC3 cancel → unchanged; AC4 missing or wrong password → nothing deleted | Verified | `Profile` · `Dialog`, `confirmDelete`; `AccountController::delete` | U, E | None |
| FSEEH-96 | Delete the Firebase account and Firestore profile | AC5 Auth account + profile removed; AC7 email can register again; AC8 failure → nothing removed; AC9 other accounts unaffected | Verified (test double + real Firebase) | `AccountController::delete` (restores the profile on failure); `deleteUser`; Firestore `DELETE` | U, E (simulated Auth failure) | **Done 22 Nov:** verified on real Firebase in the final demo recording (deletion, guest state, redirect; account confirmed absent) |
| FSEEH-97 | End the session and show the deletion confirmation | AC6 session ends; home page confirmation; protected pages need login; credentials fail | Verified | `AccountController::delete` (cookie cleared); `Profile` (toast, navigate) | U, E | None |
| — | AC5 second sentence: delete saved records; anonymise ratings and feedback | Release 2 (stories 15, 21) | N/A | Documented in `AccountController::delete` docblock | — | Implement in Release 2 |

### FSEEH-51: Learn About Faseeh (backlog 7)

| Jira key | Subtask | Acceptance criterion / requirement | Status | Evidence | Test | Action |
|---|---|---|---|---|---|---|
| FSEEH-98 | Home page sections (purpose, workflow, four levels) | AC1 purpose, 4-step workflow, four levels, intended users; AC2 try Workspace + create account; AC4 illustrative example labelled «مثال توضيحي … وليس ناتجًا حيًّا من النموذج»; AC5 no login | Verified | `pages/Home.tsx` (`STEPS`, `AUDIENCE`, preview `figcaption`) | E | Corrected Home wording: removed "حتى ٣٬٠٠٠ حرف" (limit removed) |
| FSEEH-99 | About Faseeh page | AC3 from the header and footer; processing steps; classification and simplification approaches; team and supervisor | Verified | `pages/About.tsx` (`TEAM`, data / classification / simplification cards) | E | None |

### FSEEH-16: Understand Readability Levels (backlog 10)

| Jira key | Subtask | Acceptance criterion / requirement | Status | Evidence | Test | Action |
|---|---|---|---|---|---|---|
| FSEEH-110 | Descriptions of the four levels from the agreed mapping | AC1 distinct label + explanation; AC5 agreed mapping, no unsupported levels | Verified | `shared/levels.ts` · `LEVEL_INFO` (4 levels; mapping documented in the file comment) | L | None |
| FSEEH-111 | Explanations before target selection and with analysis results | AC2 | Verified | Workspace «ما المستويات الأربعة؟» → `LevelGuide`; `AnalysisView` description; `LevelPicker` | L | None |
| FSEEH-112 | Consistent labels and order | AC3 same labels in analysis and target selection; AC4 viewing explanations keeps the text and the selected level | Verified | `LEVEL_INFO` used by `AnalysisView`, `LevelPicker`, `LevelGuide` | L | None |

### FSEEH-52: Get Contextual Help (backlog 11)

| Jira key | Subtask | Acceptance criterion / requirement | Status | Evidence | Test | Action |
|---|---|---|---|---|---|---|
| FSEEH-100 | Nuqta help button and panel | AC1 same corner on every page; AC2 opens; closes with the close button, the help button or Esc | Verified | `components/Assistant.tsx` (rendered by `Layout`) | E | None |
| FSEEH-101 | Predefined page guidance and FAQ | AC3 guidance for each page and state; AC5 expandable FAQ; AC8 predefined, not AI-generated | Verified | `lib/assistant.tsx` · `TIPS`, `FAQ`; `useAssistantTopic` per page | E | Removed the "longer than the allowed limit" wording from the validation tip |
| FSEEH-114 | New-guidance indicator and first-visit greeting | AC4 indicator when the state changes while closed; AC6 greeting disappears within 11 s | **Corrected** | `Assistant.tsx` (nudge; greeting timers) | E | Defect fixed: the "seen" flag was written before the greeting appeared, so a visitor leaving within 3.2 s, or React StrictMode in development, never saw it |
| FSEEH-115 | Keyboard support for the help button and panel | AC7 keyboard operable; opening and closing does not alter text, level or results | **Corrected** | `Assistant.tsx`: focus moves into the panel on open; `aria-controls`; Esc returns focus | E (12 keyboard checks) | Defect fixed: Tab after opening moved away from the panel. The panel comes before the button in the DOM, so its content could only be reached with Shift+Tab. |

---

## 3. Implementation matrix: Sprints 0 and 1 (research)

These items produced research and model artefacts: notebooks, the prepared dataset, the saved model and report text. They are not part of the website, and the Faseeh website code does not contain them.

| Jira key | Summary | Status | Evidence | Action |
|---|---|---|---|---|
| FSEEH-104 | Document the BAREC → four-level mapping (merge 4 and 5) | Verified in code | The mapping is documented in `frontend/src/shared/levels.ts` (Level 1 ← BAREC 1–7 … Level 4 ← 14–19); report §C1 | None |
| FSEEH-105 | Agree the documented mapping with the team | Unable | Team decision; not a code artefact | — |
| FSEEH-106, 107, 108 | Review traditional ML and deep-learning approaches; document candidate models | Unable (report content) | Report chapters 2 and 4.6; About page summarises the approaches | — |
| FSEEH-58, 59, 60, 61 | Load BAREC splits; map labels; normalise; save the prepared dataset | Unable | Research repository, not in this workspace | — |
| FSEEH-62 – 67 | TF-IDF; Decision Tree, RF, Linear SVM, XGBoost; QWK and accuracy | Unable | Report §4.6, Table 10; notebooks not in this workspace | — |
| FSEEH-68 – 72 | AraBERT tokenisation; fine-tuning (weighted CE, CORAL, MSE); dev QWK | Unable | As above | — |
| FSEEH-73 – 76 | Compare seven models; test-set evaluation; save the model; document the selection | Unable | As above. **The model is not connected to the website** (Release 2, story 36) | — |

---

## 4. Release 2 items present in the interface (checked for honest labelling)

| Backlog story | Interface status in Release 1 | Labelling | Verdict |
|---|---|---|---|
| 8 Submit Arabic Text | Text input, counter, Clear, samples, validation (empty, not Arabic) | — | Works. **AC5 (3,000-character limit) removed by your instruction; see §6.** |
| 9 Analyze / 13 Simplify / 14 Compare | Demonstration only (`services/demo/demoService.ts`): heuristic levels or prepared samples | «عيّنة» / «محاكاة» on every result | Honest; no model claimed |
| 12 Select a Target Level | Only easier levels; Level 1 cannot be simplified | — | Works as an interface |
| 15 Save / 16–20 History, Statistics | "حفظ النتائج متاح في الإصدار الثاني"; History and Stats are protected notice pages | Explicit "Release 2" | Honest |
| **21 Rate Simplification Results** | **Not rendered:** `RatingForm` returns `null` while `recordsAvailable` is false; `api.rate` rejects with "available in Release 2". No rating storage, API or new component exists. | Not shown | **Correctly not delivered in Release 1.** Verified by E ("No rating / feedback form is offered"). |
| 22 Download Results | Not built | — | Correct |

---

## 5. Architecture check: separately provided diagrams compared with the code

| Diagram element | Release | In the code | Finding |
|---|---|---|---|
| Account pages → PHP backend → Firebase Authentication | R1 | `services/http.ts` → `/api/auth/*`, `/api/account/*` → `KreaitAuthGateway` | Consistent |
| "PHP backend: handles requests and verifies the user's Firebase session" | R1 | `App::handle`, `AuthController::requireUser` → `verifySessionCookie(…, true)` | Consistent |
| Firebase (Authentication + Cloud Firestore): "accounts and profiles" | R1 | Auth via Admin SDK; profiles via Firestore REST | Consistent. The diagram doesn't say *how* Firestore is reached; the REST API is an implementation detail. |
| C2a: Delete account and Change email transitions | R1 | `AccountController::delete`, `changeEmail` | Consistent. These transitions are in the new image; older report versions lacked them. |
| C2a: "Log out or session expires / Firebase ends session" | R1 | `logout()` revokes; expiry → `session()` returns `expired` | Consistent; corrected UI gap on My Account |
| DFD Level 1, process 1.0 → D1 User Accounts: registration data, updated email, delete account and profile | R1 | Firebase Auth + Firestore profile | Consistent |
| DFD Level 1, process 1.0 → D2/D4: delete saved records; anonymise ratings | R2 | Not implemented | Correctly absent (Release 2) |
| Readability / Simplification components → PHP backend → AI model service | R2 | The Release 1 Workspace calls a **browser-side demonstration service**; there are no backend text endpoints | Expected for Release 1. Inconsistent only if a reader assumes the Workspace already goes through the backend. Labelled on screen. |
| Text preprocessing (validation, normalisation) in the application layer | R2 | Text validation exists only in the browser (`validateArabicText`) | Release 2 must add the server-side text validation the diagram shows |
| C3 activity diagram: empty / valid Arabic checks, **no length check** | R2 interface | `validateArabicText` (empty, not Arabic) | Consistent after the limit was removed |
| C1 part B "classification at runtime" | R2 | Not implemented | Correctly absent |

### Document inconsistencies found (the documents themselves were not modified)

1. **Report §4.3 C3 text** still says the text is checked to be "within the allowed length". The new C3 image has no length check, and the limit has been removed.
2. **Backlog story 8 AC5** still says "Input exceeding the 3,000-character limit is rejected". It conflicts with your instruction to remove the limit and should be reworded or removed.
3. **Backlog story 38 (Performance) AC2** tests "at least one text at the maximum permitted input length". With no maximum, it needs a concrete long-text size instead.
4. **Backlog story 4 (Log Out) user story** says "on the current device", but Firebase revocation ends **all** of the user's sessions (decision D3, unchanged).
5. **Report Figure 13 (site map)** did not show the contextual help or mark the Workspace results as demonstrations. An updated site map is in `docs/sitemap/`.
6. **Older repository docs** (`docs/AUDIT.md`, `DECISIONS.md`, `BACKLOG_UPDATES.md`, `TESTING.md`) use the **old** backlog numbering (PBI 16, items 30/31). Source-code comments now use the final numbering and Jira keys. The older docs were left unchanged as history.

---

## 6. The removed 3,000-character limit

The limit was found and removed in every layer. No other limit replaces it.

| Layer | Before | After |
|---|---|---|
| Shared validation `shared/validation.ts` | `validateArabicText(text, maxChars)` with a `too_long` issue and message | `validateArabicText(text)`: only empty and not-Arabic rules |
| API contract `shared/api.ts` | `AppConfig.maxInputChars` | Removed |
| Demonstration service | `MAX_CHARS = 3000` | Removed |
| Workspace | Counter "N / 3,000 حرف", a fill bar showing progress to the limit, and the error shown even before blur | Counter "N حرف"; the bar was removed because it only displayed the ratio to the limit; the Clear button is unchanged |
| CSS | `.counter__bar`, `[data-over]` styles | Removed |
| Home page | "…حتى ٣٬٠٠٠ حرف." | Sentence ends after the description |
| Help tip | "…أو أطول من الحد المسموح" | Removed |
| Backend | No text endpoint in Release 1 | Nothing to change |
| Tests | No test enforced the limit | New browser checks: a 4,080-character text is accepted, counted and not truncated |

**Technical constraints that remain** (these are not the removed business rule):
- **Release 1:** text never leaves the browser, so the only practical limit is the browser's memory.
- **Release 2:** when text is sent to the backend, PHP's `post_max_size` (8 MB by default) will cap the request size. The classifier's tokenizer, if AraBERT is used, also has a maximum sequence length (typically 512 tokens), which needs chunking or truncation rules. Both must be designed explicitly and must not silently truncate the text.

The 500-character limit on optional written feedback (story 21) was not touched. It exists only in the Release 2 rating form, which is not shown.
